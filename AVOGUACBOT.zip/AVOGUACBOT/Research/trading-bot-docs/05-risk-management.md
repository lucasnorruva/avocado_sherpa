# 05 - Risk Management

> **Position sizing, drawdown control, and risk rules for prop firm trading**

---

## Overview

Risk management is the most critical component of any trading system, especially for prop firm trading where strict drawdown limits exist. This document covers position sizing, risk per trade, drawdown management, and how to implement these rules in your bot.

---

## The Golden Rules

1. **Never risk more than you can afford to lose on a single trade**
2. **Preserve capital first, make profits second**
3. **The market will always be there tomorrow**
4. **Small consistent gains beat occasional big wins**
5. **Know your maximum daily loss before the day starts**

---

## Position Sizing

### Fixed Percentage Risk

The most common approach: risk a fixed percentage of capital per trade.

```python
class PositionSizer:
    """Calculate position size based on risk parameters"""

    def __init__(self, account_balance, risk_per_trade_pct=0.01):
        self.account_balance = account_balance
        self.risk_per_trade_pct = risk_per_trade_pct  # e.g., 1%

    def calculate_position_size(self, entry_price, stop_loss_price):
        """
        Calculate position size based on risk amount and stop loss distance

        Formula:
        Position Size = Risk Amount / Stop Loss Distance

        Example:
        - Account: $100,000
        - Risk per trade: 1% = $1,000
        - Entry: $50,000
        - Stop loss: $49,000
        - Stop distance: $1,000 (2%)
        - Position size: $1,000 / $1,000 = 1 unit
        - Dollar value: 1 × $50,000 = $50,000
        """
        risk_amount = self.account_balance * self.risk_per_trade_pct
        stop_distance = abs(entry_price - stop_loss_price)

        if stop_distance == 0:
            return 0

        # Position size in units (e.g., BTC)
        position_size = risk_amount / stop_distance

        return position_size

    def calculate_with_max_exposure(self, entry_price, stop_loss_price, max_exposure_pct=0.25):
        """
        Calculate position size with maximum exposure limit

        Prevents putting too much capital in a single position
        even if stop loss is very tight
        """
        base_size = self.calculate_position_size(entry_price, stop_loss_price)
        position_value = base_size * entry_price

        max_position_value = self.account_balance * max_exposure_pct

        if position_value > max_position_value:
            # Reduce position to stay within exposure limit
            return max_position_value / entry_price

        return base_size


# Example usage
sizer = PositionSizer(account_balance=100000, risk_per_trade_pct=0.01)

# Calculate for a long trade
entry = 50000  # BTC entry at $50,000
stop = 49000   # Stop loss at $49,000

position_size = sizer.calculate_position_size(entry, stop)
print(f"Position size: {position_size:.4f} BTC")
print(f"Position value: ${position_size * entry:,.2f}")
print(f"Risk amount: ${position_size * (entry - stop):,.2f}")
```

### ATR-Based Position Sizing

Use Average True Range for dynamic stop loss placement:

```python
def atr_position_size(account_balance, risk_pct, current_price, atr, atr_multiplier=2.0):
    """
    Position sizing using ATR for stop loss distance

    ATR represents average volatility, so stop loss adapts to market conditions
    """
    risk_amount = account_balance * risk_pct
    stop_distance = atr * atr_multiplier

    position_size = risk_amount / stop_distance
    position_value = position_size * current_price

    return {
        'position_size': position_size,
        'position_value': position_value,
        'stop_loss_long': current_price - stop_distance,
        'stop_loss_short': current_price + stop_distance,
        'risk_amount': risk_amount
    }


# Example with $50,000 BTC, ATR of $1,000
result = atr_position_size(
    account_balance=100000,
    risk_pct=0.01,
    current_price=50000,
    atr=1000,
    atr_multiplier=2.0
)
# Stop distance = $2,000, Risk = $1,000
# Position size = $1,000 / $2,000 = 0.5 BTC
```

### Kelly Criterion

Mathematically optimal position sizing (use fractional Kelly for safety):

```python
def kelly_criterion(win_rate, avg_win, avg_loss, fraction=0.25):
    """
    Kelly Criterion for optimal position sizing

    Full Kelly is too aggressive - use 1/4 or 1/2 Kelly

    Formula: f* = (p × b - q) / b
    where:
    - p = probability of winning
    - q = probability of losing (1 - p)
    - b = ratio of avg win to avg loss
    """
    if avg_loss == 0:
        return 0

    b = avg_win / avg_loss
    p = win_rate
    q = 1 - p

    kelly_pct = (p * b - q) / b

    # Apply fraction for safety (quarter Kelly is common)
    safe_kelly = kelly_pct * fraction

    # Never risk more than 5% per trade
    return max(0, min(0.05, safe_kelly))


# Example:
# Win rate: 55%, Avg win: $1,500, Avg loss: $1,000
# b = 1.5, kelly = (0.55 × 1.5 - 0.45) / 1.5 = 0.25
# Quarter Kelly = 6.25% → capped at 5%
```

---

## Drawdown Management

### Understanding Drawdown Types

```
Peak Equity: $110,000
Current Equity: $95,000
Starting Equity: $100,000

Current Drawdown: ($110,000 - $95,000) / $110,000 = 13.6%
Drawdown from Start: ($100,000 - $95,000) / $100,000 = 5%
```

### Prop Firm Drawdown Rules

Most prop firms have two types of drawdown limits:

1. **Daily Drawdown** - Maximum loss allowed in a single day
2. **Maximum Drawdown** - Maximum loss allowed overall

```python
class PropFirmDrawdownManager:
    """
    Manages drawdown limits for prop firm compliance

    Typical limits:
    - Daily drawdown: 5%
    - Maximum drawdown: 10%
    """

    def __init__(self, initial_balance, max_daily_dd=0.05, max_total_dd=0.10,
                 trailing_drawdown=False):
        self.initial_balance = initial_balance
        self.max_daily_dd = max_daily_dd
        self.max_total_dd = max_total_dd
        self.trailing_drawdown = trailing_drawdown  # Some firms use trailing DD

        # State tracking
        self.current_balance = initial_balance
        self.high_water_mark = initial_balance
        self.daily_start_balance = initial_balance
        self.current_date = None

    def update(self, new_balance, current_time):
        """Update balances and check limits"""
        # Check for new day
        current_date = current_time.date()
        if self.current_date != current_date:
            self.current_date = current_date
            self.daily_start_balance = self.current_balance

        self.current_balance = new_balance

        # Update high water mark
        if new_balance > self.high_water_mark:
            self.high_water_mark = new_balance

    def get_daily_drawdown(self):
        """Calculate current daily drawdown"""
        if self.daily_start_balance == 0:
            return 0
        dd = (self.daily_start_balance - self.current_balance) / self.daily_start_balance
        return max(0, dd)

    def get_total_drawdown(self):
        """Calculate total drawdown from high water mark or initial"""
        if self.trailing_drawdown:
            # Trailing drawdown - measured from high water mark
            reference = self.high_water_mark
        else:
            # Static drawdown - measured from initial balance
            reference = self.initial_balance

        if reference == 0:
            return 0

        dd = (reference - self.current_balance) / reference
        return max(0, dd)

    def get_remaining_daily_risk(self):
        """How much more can we lose today"""
        max_daily_loss = self.daily_start_balance * self.max_daily_dd
        current_daily_loss = self.daily_start_balance - self.current_balance
        remaining = max_daily_loss - current_daily_loss
        return max(0, remaining)

    def get_remaining_total_risk(self):
        """How much more can we lose overall"""
        if self.trailing_drawdown:
            reference = self.high_water_mark
        else:
            reference = self.initial_balance

        max_total_loss = reference * self.max_total_dd
        current_total_loss = reference - self.current_balance
        remaining = max_total_loss - current_total_loss
        return max(0, remaining)

    def can_trade(self):
        """Check if trading is allowed under current drawdown"""
        return (
            self.get_daily_drawdown() < self.max_daily_dd and
            self.get_total_drawdown() < self.max_total_dd
        )

    def get_max_risk_for_trade(self):
        """Maximum risk allowed for next trade"""
        remaining_daily = self.get_remaining_daily_risk()
        remaining_total = self.get_remaining_total_risk()

        # Use the smaller of the two
        max_risk = min(remaining_daily, remaining_total)

        # Apply safety margin (don't use 100% of remaining)
        safety_margin = 0.5  # Use only 50% of remaining capacity
        return max_risk * safety_margin

    def get_status(self):
        """Get current drawdown status"""
        return {
            'current_balance': self.current_balance,
            'daily_start': self.daily_start_balance,
            'high_water_mark': self.high_water_mark,
            'daily_drawdown': self.get_daily_drawdown(),
            'total_drawdown': self.get_total_drawdown(),
            'daily_dd_remaining': self.max_daily_dd - self.get_daily_drawdown(),
            'total_dd_remaining': self.max_total_dd - self.get_total_drawdown(),
            'can_trade': self.can_trade(),
            'max_risk_next_trade': self.get_max_risk_for_trade()
        }


# Example usage
dd_manager = PropFirmDrawdownManager(
    initial_balance=100000,
    max_daily_dd=0.05,
    max_total_dd=0.10
)

# Simulate some trading
dd_manager.update(99000, datetime(2024, 1, 15, 10, 0))  # Lost $1,000
print(dd_manager.get_status())
```

### Adaptive Risk Based on Drawdown

Reduce risk as drawdown increases:

```python
def adaptive_risk_percentage(base_risk, current_drawdown, max_drawdown):
    """
    Reduce risk as we approach drawdown limit

    Example scaling:
    - 0% drawdown → 100% of base risk
    - 50% of max DD → 75% of base risk
    - 75% of max DD → 25% of base risk
    - 90% of max DD → 10% of base risk (preservation mode)
    """
    if max_drawdown == 0:
        return 0

    dd_ratio = current_drawdown / max_drawdown

    if dd_ratio < 0.5:
        # Normal trading
        scale = 1.0
    elif dd_ratio < 0.75:
        # Reduce risk linearly from 1.0 to 0.25
        scale = 1.0 - (dd_ratio - 0.5) * 3.0
    elif dd_ratio < 0.9:
        # Further reduce from 0.25 to 0.1
        scale = 0.25 - (dd_ratio - 0.75) * 1.0
    else:
        # Preservation mode
        scale = 0.1

    return base_risk * scale


# Example:
# Base risk: 1%, current DD: 3%, max DD: 5%
# dd_ratio = 0.6, scale ≈ 0.7
# Adjusted risk = 0.7%
```

---

## Stop Loss Strategies

### Fixed Stop Loss

```python
def fixed_stop_loss(entry_price, direction, stop_pct=0.02):
    """Simple percentage-based stop loss"""
    if direction == 'long':
        return entry_price * (1 - stop_pct)
    else:
        return entry_price * (1 + stop_pct)
```

### ATR Stop Loss

```python
def atr_stop_loss(entry_price, direction, atr, multiplier=2.0):
    """Volatility-adjusted stop loss"""
    stop_distance = atr * multiplier

    if direction == 'long':
        return entry_price - stop_distance
    else:
        return entry_price + stop_distance
```

### Structure-Based Stop Loss

```python
def structure_stop_loss(entry_price, direction, swing_high, swing_low, buffer_pct=0.002):
    """Place stop beyond recent swing points"""
    if direction == 'long':
        # Stop below recent swing low
        return swing_low * (1 - buffer_pct)
    else:
        # Stop above recent swing high
        return swing_high * (1 + buffer_pct)
```

### Trailing Stop Loss

```python
class TrailingStopLoss:
    """Dynamic stop loss that follows price"""

    def __init__(self, initial_stop, trail_pct=0.02):
        self.current_stop = initial_stop
        self.trail_pct = trail_pct
        self.direction = 'long' if initial_stop < float('inf') else 'short'
        self.highest_price = 0
        self.lowest_price = float('inf')

    def update(self, current_price):
        """Update trailing stop based on price movement"""
        if self.direction == 'long':
            # Track highest price
            if current_price > self.highest_price:
                self.highest_price = current_price
                new_stop = current_price * (1 - self.trail_pct)
                # Only move stop up, never down
                self.current_stop = max(self.current_stop, new_stop)
        else:
            # Track lowest price
            if current_price < self.lowest_price:
                self.lowest_price = current_price
                new_stop = current_price * (1 + self.trail_pct)
                # Only move stop down, never up
                self.current_stop = min(self.current_stop, new_stop)

        return self.current_stop

    def is_triggered(self, current_price):
        """Check if stop loss is hit"""
        if self.direction == 'long':
            return current_price <= self.current_stop
        else:
            return current_price >= self.current_stop
```

---

## Risk/Reward Ratios

### Calculating Risk/Reward

```python
def calculate_risk_reward(entry, stop_loss, take_profit):
    """
    Calculate risk/reward ratio

    R:R of 2:1 means potential profit is 2x potential loss
    """
    risk = abs(entry - stop_loss)
    reward = abs(take_profit - entry)

    if risk == 0:
        return float('inf')

    return reward / risk


def required_win_rate(risk_reward_ratio):
    """
    Calculate break-even win rate for a given R:R

    R:R 1:1 → Need 50% win rate
    R:R 2:1 → Need 33% win rate
    R:R 3:1 → Need 25% win rate
    """
    return 1 / (1 + risk_reward_ratio)


# Example:
# Entry: $50,000, Stop: $49,000, Target: $52,000
# Risk: $1,000, Reward: $2,000
# R:R = 2:1
# Break-even win rate = 33.3%
```

### Minimum R:R Requirements

For prop firm trading, aim for:

| Win Rate | Minimum R:R |
|----------|-------------|
| 40% | 1.5:1 |
| 50% | 1:1 |
| 55% | 0.9:1 |
| 60% | 0.7:1 |

---

## Comprehensive Risk Manager

```python
class RiskManager:
    """
    Complete risk management for prop firm trading

    Combines position sizing, drawdown management, and order validation
    """

    def __init__(self, config):
        self.initial_balance = config['initial_balance']
        self.risk_per_trade = config.get('risk_per_trade', 0.01)
        self.max_daily_dd = config.get('max_daily_dd', 0.05)
        self.max_total_dd = config.get('max_total_dd', 0.10)
        self.max_positions = config.get('max_positions', 3)
        self.max_exposure = config.get('max_exposure', 0.50)
        self.min_rr_ratio = config.get('min_rr_ratio', 1.5)
        self.trailing_dd = config.get('trailing_dd', False)

        self.dd_manager = PropFirmDrawdownManager(
            self.initial_balance,
            self.max_daily_dd,
            self.max_total_dd,
            self.trailing_dd
        )

        self.open_positions = {}
        self.current_exposure = 0

    def validate_trade(self, signal, current_price, current_balance):
        """
        Comprehensive trade validation

        Returns: (approved, reason, adjusted_size)
        """
        # Update drawdown manager
        self.dd_manager.current_balance = current_balance

        # Check 1: Can we trade at all?
        if not self.dd_manager.can_trade():
            return False, "Drawdown limit reached", 0

        # Check 2: Maximum positions
        if len(self.open_positions) >= self.max_positions:
            return False, f"Maximum positions ({self.max_positions}) reached", 0

        # Check 3: Risk/Reward ratio
        if signal.stop_loss and signal.take_profit:
            rr = calculate_risk_reward(current_price, signal.stop_loss, signal.take_profit)
            if rr < self.min_rr_ratio:
                return False, f"R:R ratio {rr:.2f} below minimum {self.min_rr_ratio}", 0

        # Check 4: Calculate position size
        if not signal.stop_loss:
            return False, "No stop loss defined", 0

        # Get maximum allowed risk
        max_risk = self.dd_manager.get_max_risk_for_trade()
        base_risk = current_balance * self.risk_per_trade
        allowed_risk = min(max_risk, base_risk)

        if allowed_risk <= 0:
            return False, "No risk capacity remaining", 0

        # Calculate position size
        stop_distance = abs(current_price - signal.stop_loss)
        position_size = allowed_risk / stop_distance

        # Check 5: Exposure limits
        position_value = position_size * current_price
        new_exposure = self.current_exposure + position_value

        if new_exposure / current_balance > self.max_exposure:
            # Reduce position to fit exposure limit
            available_exposure = (self.max_exposure * current_balance) - self.current_exposure
            if available_exposure <= 0:
                return False, "Exposure limit reached", 0
            position_size = available_exposure / current_price

        return True, "Trade approved", position_size

    def record_position_open(self, symbol, position_size, entry_price):
        """Record a new open position"""
        self.open_positions[symbol] = {
            'size': position_size,
            'entry_price': entry_price,
            'value': position_size * entry_price
        }
        self.current_exposure += position_size * entry_price

    def record_position_close(self, symbol, exit_price):
        """Record position closure"""
        if symbol in self.open_positions:
            position = self.open_positions.pop(symbol)
            self.current_exposure -= position['value']

    def daily_reset(self):
        """Called at start of new trading day"""
        self.dd_manager.daily_start_balance = self.dd_manager.current_balance

    def get_status(self):
        """Get current risk status"""
        return {
            **self.dd_manager.get_status(),
            'open_positions': len(self.open_positions),
            'current_exposure': self.current_exposure,
            'exposure_pct': self.current_exposure / self.dd_manager.current_balance
        }
```

---

## Emergency Procedures

### Automatic Shutdown

```python
class EmergencyManager:
    """Handle emergency situations"""

    def __init__(self, bot, notification_service):
        self.bot = bot
        self.notifier = notification_service
        self.emergency_triggered = False

    def check_emergency_conditions(self, status):
        """Check for emergency conditions"""
        conditions = []

        # Daily drawdown > 80% of limit
        if status['daily_drawdown'] > status['max_daily_dd'] * 0.8:
            conditions.append("Daily drawdown approaching limit")

        # Total drawdown > 80% of limit
        if status['total_drawdown'] > status['max_total_dd'] * 0.8:
            conditions.append("Total drawdown approaching limit")

        # Multiple consecutive losses (e.g., 5)
        # if self.consecutive_losses >= 5:
        #     conditions.append("Multiple consecutive losses")

        return conditions

    async def trigger_emergency(self, reason):
        """Execute emergency shutdown"""
        self.emergency_triggered = True

        # 1. Stop accepting new trades
        self.bot.pause()

        # 2. Close all positions
        await self.bot.close_all_positions()

        # 3. Cancel all pending orders
        await self.bot.cancel_all_orders()

        # 4. Send alerts
        await self.notifier.send_alert(
            level="CRITICAL",
            message=f"Emergency shutdown triggered: {reason}",
            channels=["email", "sms", "telegram"]
        )

        # 5. Log everything
        self.bot.logger.critical(f"EMERGENCY SHUTDOWN: {reason}")
```

---

## Summary

Key risk management principles for prop firm trading:

1. **Never risk more than 1% per trade** (or less)
2. **Track daily and total drawdown constantly**
3. **Reduce position size as drawdown increases**
4. **Always use stop losses**
5. **Maintain minimum R:R ratio of 1.5:1**
6. **Limit total exposure to 50% or less**
7. **Have emergency procedures ready**
8. **When in doubt, don't trade**

---

*Next: [06-prop-firm-rules.md](./06-prop-firm-rules.md) - Understanding and adapting to prop firm constraints*
