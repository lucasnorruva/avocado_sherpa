# Data Engineering and Pipelines

> **Building robust, scalable data infrastructure for trading systems.**

---

## Table of Contents

1. [Data Architecture Overview](#data-architecture-overview)
2. [Data Sources and Ingestion](#data-sources-and-ingestion)
3. [Data Storage Solutions](#data-storage-solutions)
4. [ETL Pipelines](#etl-pipelines)
5. [Real-Time Data Processing](#real-time-data-processing)
6. [Data Quality and Validation](#data-quality-and-validation)
7. [Feature Engineering Pipelines](#feature-engineering-pipelines)
8. [Data Versioning and Lineage](#data-versioning-and-lineage)

---

## Data Architecture Overview

### High-Level Data Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        DATA ARCHITECTURE                                 │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐              │
│  │   Exchange   │    │  Alternative │    │   External   │              │
│  │     APIs     │    │    Data      │    │   Sources    │              │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘              │
│         │                   │                   │                       │
│         └───────────────────┼───────────────────┘                       │
│                             │                                           │
│                    ┌────────▼────────┐                                  │
│                    │    Ingestion    │                                  │
│                    │      Layer      │                                  │
│                    └────────┬────────┘                                  │
│                             │                                           │
│         ┌───────────────────┼───────────────────┐                       │
│         │                   │                   │                       │
│  ┌──────▼───────┐   ┌───────▼───────┐   ┌──────▼───────┐              │
│  │    Redis     │   │   Raw Data    │   │   Message    │              │
│  │   (Cache)    │   │    Store      │   │    Queue     │              │
│  └──────┬───────┘   └───────┬───────┘   └──────┬───────┘              │
│         │                   │                   │                       │
│         └───────────────────┼───────────────────┘                       │
│                             │                                           │
│                    ┌────────▼────────┐                                  │
│                    │       ETL       │                                  │
│                    │    Pipeline     │                                  │
│                    └────────┬────────┘                                  │
│                             │                                           │
│         ┌───────────────────┼───────────────────┐                       │
│         │                   │                   │                       │
│  ┌──────▼───────┐   ┌───────▼───────┐   ┌──────▼───────┐              │
│  │  TimescaleDB │   │    Feature    │   │   Archive    │              │
│  │  (Primary)   │   │    Store      │   │   Storage    │              │
│  └──────────────┘   └───────────────┘   └──────────────┘              │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

### Core Architecture Components

```python
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
from datetime import datetime
import asyncio

class DataSource(Enum):
    EXCHANGE_REST = "exchange_rest"
    EXCHANGE_WS = "exchange_websocket"
    NEWS_FEED = "news_feed"
    SOCIAL_MEDIA = "social_media"
    ON_CHAIN = "on_chain"
    ALTERNATIVE = "alternative"


@dataclass
class DataPipelineConfig:
    """Configuration for data pipeline"""
    # Source configuration
    sources: List[DataSource]
    exchanges: List[str]
    symbols: List[str]

    # Processing configuration
    batch_size: int = 1000
    processing_interval_seconds: int = 60
    max_retry_attempts: int = 3

    # Storage configuration
    primary_db: str = "timescaledb"
    cache_ttl_seconds: int = 300
    archive_after_days: int = 90

    # Quality configuration
    enable_validation: bool = True
    max_missing_data_percent: float = 1.0
    anomaly_detection: bool = True


class DataPipelineOrchestrator:
    """
    Central orchestrator for all data pipelines
    """

    def __init__(self, config: DataPipelineConfig):
        self.config = config
        self.pipelines: Dict[str, 'BasePipeline'] = {}
        self.health_status: Dict[str, bool] = {}
        self.metrics: Dict[str, Any] = {}

    async def initialize(self):
        """Initialize all pipeline components"""
        # Initialize storage connections
        self.storage = await self._init_storage()

        # Initialize cache
        self.cache = await self._init_cache()

        # Initialize message queue
        self.queue = await self._init_queue()

        # Initialize pipelines
        for source in self.config.sources:
            pipeline = await self._create_pipeline(source)
            self.pipelines[source.value] = pipeline

    async def _init_storage(self):
        """Initialize primary storage"""
        from storage import TimescaleDBStorage
        storage = TimescaleDBStorage(
            host=os.getenv('DB_HOST', 'localhost'),
            port=int(os.getenv('DB_PORT', 5432)),
            database=os.getenv('DB_NAME', 'trading'),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD')
        )
        await storage.connect()
        return storage

    async def _init_cache(self):
        """Initialize Redis cache"""
        import aioredis
        return await aioredis.create_redis_pool(
            f"redis://{os.getenv('REDIS_HOST', 'localhost')}:{os.getenv('REDIS_PORT', 6379)}"
        )

    async def _init_queue(self):
        """Initialize message queue"""
        from queue import RedisQueue
        return RedisQueue(self.cache)

    async def start(self):
        """Start all pipelines"""
        tasks = []
        for name, pipeline in self.pipelines.items():
            tasks.append(asyncio.create_task(
                pipeline.run(),
                name=f"pipeline_{name}"
            ))
            self.health_status[name] = True

        # Start health monitoring
        tasks.append(asyncio.create_task(self._monitor_health()))

        await asyncio.gather(*tasks)

    async def _monitor_health(self):
        """Monitor pipeline health"""
        while True:
            for name, pipeline in self.pipelines.items():
                try:
                    is_healthy = await pipeline.health_check()
                    self.health_status[name] = is_healthy

                    if not is_healthy:
                        await self._handle_unhealthy_pipeline(name, pipeline)
                except Exception as e:
                    self.health_status[name] = False
                    logging.error(f"Health check failed for {name}: {e}")

            await asyncio.sleep(30)

    async def _handle_unhealthy_pipeline(self, name: str, pipeline: 'BasePipeline'):
        """Handle unhealthy pipeline"""
        logging.warning(f"Pipeline {name} is unhealthy, attempting restart")
        try:
            await pipeline.restart()
            self.health_status[name] = True
        except Exception as e:
            logging.error(f"Failed to restart pipeline {name}: {e}")
```

---

## Data Sources and Ingestion

### Exchange Data Ingestion

```python
import ccxt.async_support as ccxt
from typing import AsyncGenerator, Dict, List
from datetime import datetime, timedelta
import asyncio
import logging

class ExchangeDataIngester:
    """
    Ingest data from cryptocurrency exchanges
    """

    def __init__(self, exchange_id: str, config: Dict):
        self.exchange_id = exchange_id
        self.config = config
        self.exchange = None
        self.rate_limiter = RateLimiter(
            max_requests=config.get('rate_limit', 10),
            time_window=1.0
        )

    async def initialize(self):
        """Initialize exchange connection"""
        exchange_class = getattr(ccxt, self.exchange_id)
        self.exchange = exchange_class({
            'apiKey': self.config.get('api_key'),
            'secret': self.config.get('api_secret'),
            'enableRateLimit': True,
            'options': {
                'defaultType': self.config.get('market_type', 'spot')
            }
        })
        await self.exchange.load_markets()

    async def fetch_ohlcv(self, symbol: str, timeframe: str,
                          since: Optional[datetime] = None,
                          limit: int = 1000) -> List[Dict]:
        """
        Fetch OHLCV data with rate limiting and error handling
        """
        await self.rate_limiter.acquire()

        try:
            since_ts = int(since.timestamp() * 1000) if since else None
            raw_data = await self.exchange.fetch_ohlcv(
                symbol, timeframe, since=since_ts, limit=limit
            )

            return [
                {
                    'timestamp': datetime.fromtimestamp(candle[0] / 1000),
                    'open': candle[1],
                    'high': candle[2],
                    'low': candle[3],
                    'close': candle[4],
                    'volume': candle[5],
                    'symbol': symbol,
                    'exchange': self.exchange_id,
                    'timeframe': timeframe
                }
                for candle in raw_data
            ]
        except ccxt.RateLimitExceeded:
            logging.warning(f"Rate limit exceeded for {self.exchange_id}")
            await asyncio.sleep(60)
            return await self.fetch_ohlcv(symbol, timeframe, since, limit)
        except ccxt.NetworkError as e:
            logging.error(f"Network error: {e}")
            raise
        except ccxt.ExchangeError as e:
            logging.error(f"Exchange error: {e}")
            raise

    async def fetch_order_book(self, symbol: str, limit: int = 100) -> Dict:
        """
        Fetch order book snapshot
        """
        await self.rate_limiter.acquire()

        try:
            order_book = await self.exchange.fetch_order_book(symbol, limit)

            return {
                'timestamp': datetime.now(),
                'symbol': symbol,
                'exchange': self.exchange_id,
                'bids': order_book['bids'][:limit],
                'asks': order_book['asks'][:limit],
                'bid_total': sum(b[1] for b in order_book['bids'][:limit]),
                'ask_total': sum(a[1] for a in order_book['asks'][:limit])
            }
        except Exception as e:
            logging.error(f"Error fetching order book: {e}")
            raise

    async def fetch_trades(self, symbol: str,
                           since: Optional[datetime] = None,
                           limit: int = 1000) -> List[Dict]:
        """
        Fetch recent trades
        """
        await self.rate_limiter.acquire()

        try:
            since_ts = int(since.timestamp() * 1000) if since else None
            trades = await self.exchange.fetch_trades(
                symbol, since=since_ts, limit=limit
            )

            return [
                {
                    'timestamp': datetime.fromtimestamp(t['timestamp'] / 1000),
                    'symbol': symbol,
                    'exchange': self.exchange_id,
                    'trade_id': t['id'],
                    'price': t['price'],
                    'amount': t['amount'],
                    'side': t['side'],
                    'cost': t['cost']
                }
                for t in trades
            ]
        except Exception as e:
            logging.error(f"Error fetching trades: {e}")
            raise

    async def close(self):
        """Close exchange connection"""
        if self.exchange:
            await self.exchange.close()


class RateLimiter:
    """Token bucket rate limiter"""

    def __init__(self, max_requests: int, time_window: float):
        self.max_requests = max_requests
        self.time_window = time_window
        self.tokens = max_requests
        self.last_update = datetime.now()
        self._lock = asyncio.Lock()

    async def acquire(self):
        async with self._lock:
            now = datetime.now()
            time_passed = (now - self.last_update).total_seconds()

            # Refill tokens
            self.tokens = min(
                self.max_requests,
                self.tokens + time_passed * (self.max_requests / self.time_window)
            )
            self.last_update = now

            if self.tokens < 1:
                wait_time = (1 - self.tokens) * (self.time_window / self.max_requests)
                await asyncio.sleep(wait_time)
                self.tokens = 0
            else:
                self.tokens -= 1
```

### WebSocket Real-Time Ingestion

```python
import websockets
import json
from typing import Callable, Dict, Any
import asyncio

class WebSocketIngester:
    """
    Real-time data ingestion via WebSocket
    """

    def __init__(self, config: Dict):
        self.config = config
        self.connections: Dict[str, websockets.WebSocketClientProtocol] = {}
        self.callbacks: Dict[str, List[Callable]] = {}
        self.reconnect_delay = 5
        self.max_reconnect_attempts = 10

    async def connect(self, exchange: str, url: str):
        """
        Establish WebSocket connection with auto-reconnect
        """
        attempts = 0

        while attempts < self.max_reconnect_attempts:
            try:
                connection = await websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=10,
                    close_timeout=5
                )
                self.connections[exchange] = connection
                logging.info(f"Connected to {exchange} WebSocket")
                return connection
            except Exception as e:
                attempts += 1
                logging.error(f"Connection failed ({attempts}): {e}")
                await asyncio.sleep(self.reconnect_delay * attempts)

        raise ConnectionError(f"Failed to connect to {exchange} after {attempts} attempts")

    async def subscribe(self, exchange: str, channels: List[str]):
        """
        Subscribe to WebSocket channels
        """
        connection = self.connections.get(exchange)
        if not connection:
            raise ValueError(f"No connection for {exchange}")

        # Exchange-specific subscription format
        subscribe_msg = self._format_subscribe_message(exchange, channels)
        await connection.send(json.dumps(subscribe_msg))

    def _format_subscribe_message(self, exchange: str, channels: List[str]) -> Dict:
        """
        Format subscription message for different exchanges
        """
        formats = {
            'binance': {
                'method': 'SUBSCRIBE',
                'params': channels,
                'id': 1
            },
            'bybit': {
                'op': 'subscribe',
                'args': channels
            },
            'okx': {
                'op': 'subscribe',
                'args': [{'channel': c} for c in channels]
            }
        }
        return formats.get(exchange, {'subscribe': channels})

    async def listen(self, exchange: str, callback: Callable):
        """
        Listen for messages and process with callback
        """
        connection = self.connections.get(exchange)
        if not connection:
            raise ValueError(f"No connection for {exchange}")

        while True:
            try:
                message = await connection.recv()
                data = json.loads(message)

                # Process message
                processed = self._process_message(exchange, data)
                if processed:
                    await callback(processed)

            except websockets.ConnectionClosed:
                logging.warning(f"{exchange} connection closed, reconnecting...")
                await self._reconnect(exchange)
            except json.JSONDecodeError as e:
                logging.error(f"JSON decode error: {e}")
            except Exception as e:
                logging.error(f"Error processing message: {e}")

    def _process_message(self, exchange: str, data: Dict) -> Optional[Dict]:
        """
        Process and normalize WebSocket messages
        """
        # Skip heartbeats and system messages
        if self._is_system_message(exchange, data):
            return None

        # Normalize based on message type
        if 'trade' in str(data).lower():
            return self._normalize_trade(exchange, data)
        elif 'depth' in str(data).lower() or 'book' in str(data).lower():
            return self._normalize_orderbook(exchange, data)
        elif 'kline' in str(data).lower() or 'candle' in str(data).lower():
            return self._normalize_candle(exchange, data)

        return data

    def _is_system_message(self, exchange: str, data: Dict) -> bool:
        """Check if message is system/heartbeat"""
        system_indicators = ['ping', 'pong', 'heartbeat', 'subscribe', 'success']
        return any(ind in str(data).lower() for ind in system_indicators)

    def _normalize_trade(self, exchange: str, data: Dict) -> Dict:
        """Normalize trade data across exchanges"""
        normalizers = {
            'binance': lambda d: {
                'timestamp': datetime.fromtimestamp(d['T'] / 1000),
                'price': float(d['p']),
                'amount': float(d['q']),
                'side': 'sell' if d['m'] else 'buy',
                'trade_id': d['t']
            },
            'bybit': lambda d: {
                'timestamp': datetime.fromtimestamp(d['T'] / 1000),
                'price': float(d['p']),
                'amount': float(d['v']),
                'side': d['S'].lower(),
                'trade_id': d['i']
            }
        }

        normalizer = normalizers.get(exchange)
        if normalizer:
            return {**normalizer(data), 'exchange': exchange}
        return data

    async def _reconnect(self, exchange: str):
        """Reconnect to WebSocket"""
        url = self.config.get(f'{exchange}_ws_url')
        if url:
            await asyncio.sleep(self.reconnect_delay)
            await self.connect(exchange, url)


class BinanceWebSocketManager:
    """
    Specialized manager for Binance WebSocket streams
    """

    BASE_URL = "wss://stream.binance.com:9443/ws"
    FUTURES_URL = "wss://fstream.binance.com/ws"

    def __init__(self, use_futures: bool = False):
        self.base_url = self.FUTURES_URL if use_futures else self.BASE_URL
        self.streams: Dict[str, asyncio.Task] = {}
        self.data_queues: Dict[str, asyncio.Queue] = {}

    async def subscribe_trades(self, symbol: str) -> asyncio.Queue:
        """Subscribe to trade stream"""
        stream_name = f"{symbol.lower()}@trade"
        return await self._subscribe_stream(stream_name)

    async def subscribe_klines(self, symbol: str, interval: str) -> asyncio.Queue:
        """Subscribe to kline/candlestick stream"""
        stream_name = f"{symbol.lower()}@kline_{interval}"
        return await self._subscribe_stream(stream_name)

    async def subscribe_depth(self, symbol: str, levels: int = 20) -> asyncio.Queue:
        """Subscribe to order book depth stream"""
        stream_name = f"{symbol.lower()}@depth{levels}@100ms"
        return await self._subscribe_stream(stream_name)

    async def subscribe_agg_trades(self, symbol: str) -> asyncio.Queue:
        """Subscribe to aggregated trade stream"""
        stream_name = f"{symbol.lower()}@aggTrade"
        return await self._subscribe_stream(stream_name)

    async def _subscribe_stream(self, stream_name: str) -> asyncio.Queue:
        """Internal method to subscribe to a stream"""
        if stream_name in self.streams:
            return self.data_queues[stream_name]

        queue = asyncio.Queue(maxsize=10000)
        self.data_queues[stream_name] = queue

        url = f"{self.base_url}/{stream_name}"
        task = asyncio.create_task(self._stream_listener(url, stream_name, queue))
        self.streams[stream_name] = task

        return queue

    async def _stream_listener(self, url: str, stream_name: str, queue: asyncio.Queue):
        """Listen to stream and put data in queue"""
        while True:
            try:
                async with websockets.connect(url) as ws:
                    while True:
                        msg = await ws.recv()
                        data = json.loads(msg)

                        # Don't block if queue is full (drop oldest)
                        if queue.full():
                            try:
                                queue.get_nowait()
                            except asyncio.QueueEmpty:
                                pass

                        await queue.put(data)

            except websockets.ConnectionClosed:
                logging.warning(f"Stream {stream_name} closed, reconnecting...")
                await asyncio.sleep(5)
            except Exception as e:
                logging.error(f"Stream error {stream_name}: {e}")
                await asyncio.sleep(5)
```

---

## Data Storage Solutions

### TimescaleDB for Time-Series Data

```python
import asyncpg
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import pandas as pd

class TimescaleDBStorage:
    """
    TimescaleDB storage for trading data

    Optimized for:
    - High-speed time-series inserts
    - Efficient range queries
    - Automatic data compression
    - Continuous aggregates
    """

    def __init__(self, host: str, port: int, database: str,
                 user: str, password: str):
        self.dsn = f"postgresql://{user}:{password}@{host}:{port}/{database}"
        self.pool = None

    async def connect(self):
        """Initialize connection pool"""
        self.pool = await asyncpg.create_pool(
            self.dsn,
            min_size=5,
            max_size=20,
            command_timeout=60
        )

    async def initialize_schema(self):
        """Create tables and hypertables"""
        async with self.pool.acquire() as conn:
            # OHLCV table
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS ohlcv (
                    time TIMESTAMPTZ NOT NULL,
                    symbol TEXT NOT NULL,
                    exchange TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    open DOUBLE PRECISION,
                    high DOUBLE PRECISION,
                    low DOUBLE PRECISION,
                    close DOUBLE PRECISION,
                    volume DOUBLE PRECISION,
                    trades INTEGER,
                    PRIMARY KEY (time, symbol, exchange, timeframe)
                );

                -- Convert to hypertable
                SELECT create_hypertable('ohlcv', 'time',
                    if_not_exists => TRUE,
                    chunk_time_interval => INTERVAL '1 day'
                );

                -- Create index for common queries
                CREATE INDEX IF NOT EXISTS idx_ohlcv_symbol_time
                ON ohlcv (symbol, time DESC);
            ''')

            # Trades table
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS trades (
                    time TIMESTAMPTZ NOT NULL,
                    symbol TEXT NOT NULL,
                    exchange TEXT NOT NULL,
                    trade_id TEXT,
                    price DOUBLE PRECISION,
                    amount DOUBLE PRECISION,
                    side TEXT,
                    PRIMARY KEY (time, symbol, exchange, trade_id)
                );

                SELECT create_hypertable('trades', 'time',
                    if_not_exists => TRUE,
                    chunk_time_interval => INTERVAL '1 hour'
                );
            ''')

            # Order book snapshots
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS orderbook_snapshots (
                    time TIMESTAMPTZ NOT NULL,
                    symbol TEXT NOT NULL,
                    exchange TEXT NOT NULL,
                    bids JSONB,
                    asks JSONB,
                    spread DOUBLE PRECISION,
                    mid_price DOUBLE PRECISION,
                    PRIMARY KEY (time, symbol, exchange)
                );

                SELECT create_hypertable('orderbook_snapshots', 'time',
                    if_not_exists => TRUE,
                    chunk_time_interval => INTERVAL '1 hour'
                );
            ''')

            # Create continuous aggregates for common timeframes
            await self._create_continuous_aggregates(conn)

    async def _create_continuous_aggregates(self, conn):
        """Create continuous aggregates for efficient queries"""
        # 1-hour aggregate from 1-minute data
        await conn.execute('''
            CREATE MATERIALIZED VIEW IF NOT EXISTS ohlcv_1h
            WITH (timescaledb.continuous) AS
            SELECT
                time_bucket('1 hour', time) AS bucket,
                symbol,
                exchange,
                first(open, time) AS open,
                max(high) AS high,
                min(low) AS low,
                last(close, time) AS close,
                sum(volume) AS volume,
                sum(trades) AS trades
            FROM ohlcv
            WHERE timeframe = '1m'
            GROUP BY bucket, symbol, exchange;

            -- Refresh policy
            SELECT add_continuous_aggregate_policy('ohlcv_1h',
                start_offset => INTERVAL '3 hours',
                end_offset => INTERVAL '1 hour',
                schedule_interval => INTERVAL '1 hour',
                if_not_exists => TRUE
            );
        ''')

        # Daily aggregate
        await conn.execute('''
            CREATE MATERIALIZED VIEW IF NOT EXISTS ohlcv_1d
            WITH (timescaledb.continuous) AS
            SELECT
                time_bucket('1 day', time) AS bucket,
                symbol,
                exchange,
                first(open, time) AS open,
                max(high) AS high,
                min(low) AS low,
                last(close, time) AS close,
                sum(volume) AS volume,
                sum(trades) AS trades
            FROM ohlcv
            WHERE timeframe = '1h'
            GROUP BY bucket, symbol, exchange;

            SELECT add_continuous_aggregate_policy('ohlcv_1d',
                start_offset => INTERVAL '3 days',
                end_offset => INTERVAL '1 day',
                schedule_interval => INTERVAL '1 day',
                if_not_exists => TRUE
            );
        ''')

    async def insert_ohlcv(self, data: List[Dict]):
        """
        Batch insert OHLCV data
        """
        if not data:
            return

        async with self.pool.acquire() as conn:
            await conn.executemany('''
                INSERT INTO ohlcv (time, symbol, exchange, timeframe,
                                   open, high, low, close, volume, trades)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                ON CONFLICT (time, symbol, exchange, timeframe)
                DO UPDATE SET
                    open = EXCLUDED.open,
                    high = EXCLUDED.high,
                    low = EXCLUDED.low,
                    close = EXCLUDED.close,
                    volume = EXCLUDED.volume,
                    trades = EXCLUDED.trades
            ''', [
                (d['timestamp'], d['symbol'], d['exchange'], d['timeframe'],
                 d['open'], d['high'], d['low'], d['close'], d['volume'],
                 d.get('trades', 0))
                for d in data
            ])

    async def insert_trades(self, trades: List[Dict]):
        """Batch insert trades"""
        if not trades:
            return

        async with self.pool.acquire() as conn:
            await conn.executemany('''
                INSERT INTO trades (time, symbol, exchange, trade_id,
                                   price, amount, side)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT DO NOTHING
            ''', [
                (t['timestamp'], t['symbol'], t['exchange'], t['trade_id'],
                 t['price'], t['amount'], t['side'])
                for t in trades
            ])

    async def query_ohlcv(self, symbol: str, exchange: str, timeframe: str,
                          start: datetime, end: datetime) -> pd.DataFrame:
        """
        Query OHLCV data
        """
        async with self.pool.acquire() as conn:
            rows = await conn.fetch('''
                SELECT time, open, high, low, close, volume, trades
                FROM ohlcv
                WHERE symbol = $1
                  AND exchange = $2
                  AND timeframe = $3
                  AND time >= $4
                  AND time <= $5
                ORDER BY time ASC
            ''', symbol, exchange, timeframe, start, end)

            return pd.DataFrame(
                rows,
                columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'trades']
            ).set_index('timestamp')

    async def query_trades(self, symbol: str, exchange: str,
                           start: datetime, end: datetime) -> pd.DataFrame:
        """Query trades"""
        async with self.pool.acquire() as conn:
            rows = await conn.fetch('''
                SELECT time, price, amount, side
                FROM trades
                WHERE symbol = $1
                  AND exchange = $2
                  AND time >= $3
                  AND time <= $4
                ORDER BY time ASC
            ''', symbol, exchange, start, end)

            return pd.DataFrame(
                rows,
                columns=['timestamp', 'price', 'amount', 'side']
            ).set_index('timestamp')

    async def get_latest_timestamp(self, symbol: str, exchange: str,
                                    timeframe: str) -> Optional[datetime]:
        """Get most recent data timestamp"""
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow('''
                SELECT MAX(time) as latest
                FROM ohlcv
                WHERE symbol = $1
                  AND exchange = $2
                  AND timeframe = $3
            ''', symbol, exchange, timeframe)

            return row['latest'] if row else None

    async def setup_compression(self):
        """Setup automatic compression for older data"""
        async with self.pool.acquire() as conn:
            # Enable compression on OHLCV
            await conn.execute('''
                ALTER TABLE ohlcv SET (
                    timescaledb.compress,
                    timescaledb.compress_segmentby = 'symbol, exchange, timeframe'
                );

                -- Compress chunks older than 7 days
                SELECT add_compression_policy('ohlcv',
                    INTERVAL '7 days',
                    if_not_exists => TRUE
                );
            ''')

            # Enable compression on trades
            await conn.execute('''
                ALTER TABLE trades SET (
                    timescaledb.compress,
                    timescaledb.compress_segmentby = 'symbol, exchange'
                );

                SELECT add_compression_policy('trades',
                    INTERVAL '1 day',
                    if_not_exists => TRUE
                );
            ''')

    async def setup_retention(self, retention_days: int = 90):
        """Setup automatic data retention policy"""
        async with self.pool.acquire() as conn:
            # Keep raw data for specified days
            await conn.execute(f'''
                SELECT add_retention_policy('trades',
                    INTERVAL '{retention_days} days',
                    if_not_exists => TRUE
                );
            ''')

    async def close(self):
        """Close connection pool"""
        if self.pool:
            await self.pool.close()
```

### Redis Cache Layer

```python
import aioredis
import json
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import pickle

class RedisCache:
    """
    Redis caching layer for trading data

    Use cases:
    - Latest price cache
    - Order book cache
    - Indicator cache
    - Rate limit state
    """

    def __init__(self, host: str = 'localhost', port: int = 6379,
                 db: int = 0, password: Optional[str] = None):
        self.host = host
        self.port = port
        self.db = db
        self.password = password
        self.redis = None

    async def connect(self):
        """Connect to Redis"""
        self.redis = await aioredis.create_redis_pool(
            f"redis://{self.host}:{self.port}",
            db=self.db,
            password=self.password,
            minsize=5,
            maxsize=20
        )

    async def set_price(self, symbol: str, exchange: str, price: float,
                        ttl: int = 5):
        """Cache latest price"""
        key = f"price:{exchange}:{symbol}"
        await self.redis.setex(key, ttl, str(price))

    async def get_price(self, symbol: str, exchange: str) -> Optional[float]:
        """Get cached price"""
        key = f"price:{exchange}:{symbol}"
        value = await self.redis.get(key)
        return float(value) if value else None

    async def set_orderbook(self, symbol: str, exchange: str,
                            orderbook: Dict, ttl: int = 1):
        """Cache order book"""
        key = f"orderbook:{exchange}:{symbol}"
        await self.redis.setex(key, ttl, json.dumps(orderbook))

    async def get_orderbook(self, symbol: str, exchange: str) -> Optional[Dict]:
        """Get cached order book"""
        key = f"orderbook:{exchange}:{symbol}"
        value = await self.redis.get(key)
        return json.loads(value) if value else None

    async def set_indicator(self, symbol: str, indicator: str,
                            timeframe: str, value: Any, ttl: int = 60):
        """Cache indicator value"""
        key = f"indicator:{symbol}:{indicator}:{timeframe}"
        await self.redis.setex(key, ttl, pickle.dumps(value))

    async def get_indicator(self, symbol: str, indicator: str,
                            timeframe: str) -> Optional[Any]:
        """Get cached indicator"""
        key = f"indicator:{symbol}:{indicator}:{timeframe}"
        value = await self.redis.get(key)
        return pickle.loads(value) if value else None

    async def publish(self, channel: str, message: Dict):
        """Publish message to channel"""
        await self.redis.publish(channel, json.dumps(message))

    async def subscribe(self, channel: str):
        """Subscribe to channel"""
        channels = await self.redis.subscribe(channel)
        return channels[0]

    async def increment_counter(self, key: str, ttl: int = 3600) -> int:
        """Increment counter with TTL"""
        pipe = self.redis.pipeline()
        pipe.incr(key)
        pipe.expire(key, ttl)
        results = await pipe.execute()
        return results[0]

    async def get_rate_limit_remaining(self, key: str, limit: int,
                                        window: int) -> int:
        """Get remaining rate limit"""
        count = await self.redis.get(key)
        current = int(count) if count else 0
        return max(0, limit - current)

    async def close(self):
        """Close Redis connection"""
        if self.redis:
            self.redis.close()
            await self.redis.wait_closed()
```

---

## ETL Pipelines

### Data Transformation Pipeline

```python
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from datetime import datetime
import pandas as pd
import numpy as np

class BasePipeline(ABC):
    """Base class for data pipelines"""

    def __init__(self, name: str, config: Dict):
        self.name = name
        self.config = config
        self.metrics = PipelineMetrics(name)

    @abstractmethod
    async def extract(self) -> Any:
        """Extract data from source"""
        pass

    @abstractmethod
    async def transform(self, data: Any) -> Any:
        """Transform data"""
        pass

    @abstractmethod
    async def load(self, data: Any) -> None:
        """Load data to destination"""
        pass

    async def run(self):
        """Run the ETL pipeline"""
        self.metrics.start_run()

        try:
            # Extract
            raw_data = await self.extract()
            self.metrics.record_extract(len(raw_data) if hasattr(raw_data, '__len__') else 1)

            # Transform
            transformed_data = await self.transform(raw_data)
            self.metrics.record_transform()

            # Load
            await self.load(transformed_data)
            self.metrics.record_load()

            self.metrics.end_run(success=True)

        except Exception as e:
            self.metrics.end_run(success=False, error=str(e))
            raise

    async def health_check(self) -> bool:
        """Check pipeline health"""
        return self.metrics.is_healthy()


class OHLCVPipeline(BasePipeline):
    """
    Pipeline for OHLCV data processing
    """

    def __init__(self, config: Dict, ingester: ExchangeDataIngester,
                 storage: TimescaleDBStorage, cache: RedisCache):
        super().__init__('ohlcv_pipeline', config)
        self.ingester = ingester
        self.storage = storage
        self.cache = cache

    async def extract(self) -> List[Dict]:
        """Extract OHLCV data from exchange"""
        all_data = []

        for symbol in self.config['symbols']:
            for timeframe in self.config['timeframes']:
                # Get latest timestamp from storage
                last_ts = await self.storage.get_latest_timestamp(
                    symbol,
                    self.ingester.exchange_id,
                    timeframe
                )

                # Fetch new data
                data = await self.ingester.fetch_ohlcv(
                    symbol,
                    timeframe,
                    since=last_ts,
                    limit=1000
                )
                all_data.extend(data)

        return all_data

    async def transform(self, data: List[Dict]) -> List[Dict]:
        """Transform and validate OHLCV data"""
        if not data:
            return []

        # Convert to DataFrame for processing
        df = pd.DataFrame(data)

        # Remove duplicates
        df = df.drop_duplicates(subset=['timestamp', 'symbol', 'timeframe'])

        # Validate data
        df = self._validate_ohlcv(df)

        # Fill missing values
        df = self._fill_missing_values(df)

        # Add derived fields
        df = self._add_derived_fields(df)

        return df.to_dict('records')

    def _validate_ohlcv(self, df: pd.DataFrame) -> pd.DataFrame:
        """Validate OHLCV data"""
        # Remove rows with invalid prices
        df = df[df['open'] > 0]
        df = df[df['high'] >= df['low']]
        df = df[df['high'] >= df['open']]
        df = df[df['high'] >= df['close']]
        df = df[df['low'] <= df['open']]
        df = df[df['low'] <= df['close']]

        # Remove extreme outliers (>10 std from mean)
        for col in ['open', 'high', 'low', 'close']:
            mean = df[col].mean()
            std = df[col].std()
            df = df[(df[col] > mean - 10 * std) & (df[col] < mean + 10 * std)]

        return df

    def _fill_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fill missing OHLCV values"""
        # Forward fill missing prices
        for col in ['open', 'high', 'low', 'close']:
            df[col] = df[col].fillna(method='ffill')

        # Fill missing volume with 0
        df['volume'] = df['volume'].fillna(0)

        return df

    def _add_derived_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add derived fields"""
        # True range
        df['tr'] = np.maximum(
            df['high'] - df['low'],
            np.maximum(
                abs(df['high'] - df['close'].shift(1)),
                abs(df['low'] - df['close'].shift(1))
            )
        )

        # Typical price
        df['typical_price'] = (df['high'] + df['low'] + df['close']) / 3

        # VWAP approximation
        df['vwap'] = (df['typical_price'] * df['volume']).cumsum() / df['volume'].cumsum()

        return df

    async def load(self, data: List[Dict]) -> None:
        """Load data to storage and cache"""
        if not data:
            return

        # Batch insert to TimescaleDB
        await self.storage.insert_ohlcv(data)

        # Update cache with latest prices
        latest = {}
        for record in data:
            key = (record['symbol'], record['exchange'])
            if key not in latest or record['timestamp'] > latest[key]['timestamp']:
                latest[key] = record

        for (symbol, exchange), record in latest.items():
            await self.cache.set_price(symbol, exchange, record['close'])


class TradePipeline(BasePipeline):
    """
    Pipeline for trade data processing
    """

    def __init__(self, config: Dict, ingester: ExchangeDataIngester,
                 storage: TimescaleDBStorage):
        super().__init__('trade_pipeline', config)
        self.ingester = ingester
        self.storage = storage
        self.buffer: List[Dict] = []
        self.buffer_size = config.get('buffer_size', 1000)

    async def extract(self) -> List[Dict]:
        """Extract trade data"""
        all_trades = []

        for symbol in self.config['symbols']:
            trades = await self.ingester.fetch_trades(
                symbol,
                limit=1000
            )
            all_trades.extend(trades)

        return all_trades

    async def transform(self, data: List[Dict]) -> Dict:
        """Transform trades and compute aggregations"""
        if not data:
            return {'trades': [], 'aggregates': {}}

        df = pd.DataFrame(data)

        # Remove duplicates
        df = df.drop_duplicates(subset=['trade_id'])

        # Compute aggregates
        aggregates = {}
        for symbol in df['symbol'].unique():
            symbol_df = df[df['symbol'] == symbol]
            aggregates[symbol] = {
                'volume': symbol_df['amount'].sum(),
                'buy_volume': symbol_df[symbol_df['side'] == 'buy']['amount'].sum(),
                'sell_volume': symbol_df[symbol_df['side'] == 'sell']['amount'].sum(),
                'trade_count': len(symbol_df),
                'avg_trade_size': symbol_df['amount'].mean(),
                'vwap': (symbol_df['price'] * symbol_df['amount']).sum() / symbol_df['amount'].sum()
            }

        return {
            'trades': df.to_dict('records'),
            'aggregates': aggregates
        }

    async def load(self, data: Dict) -> None:
        """Load trades and aggregates"""
        if data['trades']:
            await self.storage.insert_trades(data['trades'])


class PipelineMetrics:
    """Track pipeline metrics"""

    def __init__(self, name: str):
        self.name = name
        self.runs = 0
        self.successful_runs = 0
        self.failed_runs = 0
        self.last_run_time = None
        self.last_run_duration = None
        self.last_error = None
        self.records_processed = 0
        self._start_time = None

    def start_run(self):
        self._start_time = datetime.now()
        self.runs += 1

    def record_extract(self, count: int):
        self.records_processed += count

    def record_transform(self):
        pass

    def record_load(self):
        pass

    def end_run(self, success: bool, error: Optional[str] = None):
        self.last_run_time = datetime.now()
        self.last_run_duration = (self.last_run_time - self._start_time).total_seconds()

        if success:
            self.successful_runs += 1
        else:
            self.failed_runs += 1
            self.last_error = error

    def is_healthy(self) -> bool:
        if self.runs == 0:
            return True

        # Unhealthy if last 3 runs failed
        recent_failure_rate = self.failed_runs / self.runs
        return recent_failure_rate < 0.5
```

---

## Real-Time Data Processing

### Stream Processing

```python
import asyncio
from typing import Callable, Dict, List, Any
from collections import deque
from datetime import datetime, timedelta
import numpy as np

class StreamProcessor:
    """
    Real-time stream processing for trading data
    """

    def __init__(self, config: Dict):
        self.config = config
        self.handlers: Dict[str, List[Callable]] = {}
        self.buffers: Dict[str, deque] = {}
        self.aggregators: Dict[str, 'StreamAggregator'] = {}

    def register_handler(self, event_type: str, handler: Callable):
        """Register event handler"""
        if event_type not in self.handlers:
            self.handlers[event_type] = []
        self.handlers[event_type].append(handler)

    async def process(self, event_type: str, data: Dict):
        """Process incoming event"""
        # Add timestamp if missing
        if 'timestamp' not in data:
            data['timestamp'] = datetime.now()

        # Add to buffer
        if event_type not in self.buffers:
            self.buffers[event_type] = deque(maxlen=10000)
        self.buffers[event_type].append(data)

        # Update aggregators
        if event_type in self.aggregators:
            self.aggregators[event_type].update(data)

        # Call handlers
        handlers = self.handlers.get(event_type, [])
        for handler in handlers:
            try:
                await handler(data)
            except Exception as e:
                logging.error(f"Handler error: {e}")

    def create_aggregator(self, name: str, window_seconds: int) -> 'StreamAggregator':
        """Create time-windowed aggregator"""
        aggregator = StreamAggregator(window_seconds)
        self.aggregators[name] = aggregator
        return aggregator


class StreamAggregator:
    """
    Time-windowed stream aggregation
    """

    def __init__(self, window_seconds: int):
        self.window_seconds = window_seconds
        self.data: deque = deque()
        self._lock = asyncio.Lock()

    async def update(self, record: Dict):
        """Add record to window"""
        async with self._lock:
            self.data.append(record)
            self._cleanup()

    def _cleanup(self):
        """Remove old records"""
        cutoff = datetime.now() - timedelta(seconds=self.window_seconds)
        while self.data and self.data[0]['timestamp'] < cutoff:
            self.data.popleft()

    async def get_stats(self, field: str) -> Dict:
        """Get statistics for field over window"""
        async with self._lock:
            if not self.data:
                return {}

            values = [r[field] for r in self.data if field in r]
            if not values:
                return {}

            return {
                'count': len(values),
                'sum': sum(values),
                'mean': np.mean(values),
                'std': np.std(values),
                'min': min(values),
                'max': max(values),
                'last': values[-1]
            }

    async def get_vwap(self, price_field: str, volume_field: str) -> Optional[float]:
        """Calculate VWAP over window"""
        async with self._lock:
            if not self.data:
                return None

            total_value = sum(r[price_field] * r[volume_field]
                            for r in self.data
                            if price_field in r and volume_field in r)
            total_volume = sum(r[volume_field]
                              for r in self.data
                              if volume_field in r)

            return total_value / total_volume if total_volume > 0 else None


class RealTimeFeatureComputer:
    """
    Compute features in real-time from streaming data
    """

    def __init__(self, cache: RedisCache):
        self.cache = cache
        self.feature_buffers: Dict[str, deque] = {}

    async def compute_trade_features(self, symbol: str, trade: Dict) -> Dict:
        """Compute features from trade"""
        # Initialize buffer if needed
        if symbol not in self.feature_buffers:
            self.feature_buffers[symbol] = deque(maxlen=1000)

        buffer = self.feature_buffers[symbol]
        buffer.append(trade)

        if len(buffer) < 10:
            return {}

        # Convert to arrays
        prices = np.array([t['price'] for t in buffer])
        volumes = np.array([t['amount'] for t in buffer])
        sides = np.array([1 if t['side'] == 'buy' else -1 for t in buffer])

        # Compute features
        features = {
            'symbol': symbol,
            'timestamp': trade['timestamp'],

            # Price features
            'price': trade['price'],
            'price_sma_10': np.mean(prices[-10:]),
            'price_sma_50': np.mean(prices[-50:]) if len(prices) >= 50 else np.mean(prices),
            'price_std_10': np.std(prices[-10:]),

            # Volume features
            'volume': trade['amount'],
            'volume_sma_10': np.mean(volumes[-10:]),
            'volume_imbalance': np.sum(volumes[-10:] * sides[-10:]) / np.sum(volumes[-10:]),

            # Trade flow features
            'buy_ratio': np.sum(sides[-10:] == 1) / 10,
            'trade_intensity': len(buffer) / 60,  # trades per second (assuming 1min buffer)

            # Momentum
            'price_change_10': (prices[-1] - prices[-10]) / prices[-10] if len(prices) >= 10 else 0,
            'price_momentum': np.mean(np.diff(prices[-10:])) if len(prices) >= 10 else 0
        }

        # Cache features
        await self.cache.set_indicator(
            symbol, 'trade_features', 'realtime',
            features, ttl=5
        )

        return features

    async def compute_orderbook_features(self, symbol: str, orderbook: Dict) -> Dict:
        """Compute features from order book"""
        bids = orderbook['bids']
        asks = orderbook['asks']

        # Calculate imbalance at different levels
        bid_volume_1 = sum(b[1] for b in bids[:1])
        ask_volume_1 = sum(a[1] for a in asks[:1])
        bid_volume_5 = sum(b[1] for b in bids[:5])
        ask_volume_5 = sum(a[1] for a in asks[:5])
        bid_volume_10 = sum(b[1] for b in bids[:10])
        ask_volume_10 = sum(a[1] for a in asks[:10])

        best_bid = bids[0][0] if bids else 0
        best_ask = asks[0][0] if asks else 0
        mid_price = (best_bid + best_ask) / 2

        features = {
            'symbol': symbol,
            'timestamp': datetime.now(),

            # Spread
            'spread': best_ask - best_bid,
            'spread_bps': (best_ask - best_bid) / mid_price * 10000,

            # Imbalance
            'imbalance_1': (bid_volume_1 - ask_volume_1) / (bid_volume_1 + ask_volume_1 + 1e-10),
            'imbalance_5': (bid_volume_5 - ask_volume_5) / (bid_volume_5 + ask_volume_5 + 1e-10),
            'imbalance_10': (bid_volume_10 - ask_volume_10) / (bid_volume_10 + ask_volume_10 + 1e-10),

            # Depth
            'bid_depth_1': bid_volume_1,
            'ask_depth_1': ask_volume_1,
            'total_depth_10': bid_volume_10 + ask_volume_10,

            # Micro price
            'micro_price': (best_bid * ask_volume_1 + best_ask * bid_volume_1) / (bid_volume_1 + ask_volume_1 + 1e-10),

            # Price levels
            'bid_levels': len(bids),
            'ask_levels': len(asks)
        }

        await self.cache.set_indicator(
            symbol, 'orderbook_features', 'realtime',
            features, ttl=2
        )

        return features
```

---

## Data Quality and Validation

### Data Quality Framework

```python
from dataclasses import dataclass
from typing import List, Dict, Optional, Callable
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from scipy import stats

@dataclass
class QualityCheck:
    name: str
    check_fn: Callable
    severity: str  # 'critical', 'warning', 'info'
    description: str


@dataclass
class QualityReport:
    timestamp: datetime
    dataset: str
    total_records: int
    passed_checks: int
    failed_checks: int
    issues: List[Dict]
    overall_score: float


class DataQualityValidator:
    """
    Comprehensive data quality validation
    """

    def __init__(self):
        self.checks: List[QualityCheck] = []
        self._register_default_checks()

    def _register_default_checks(self):
        """Register default quality checks"""
        # Completeness checks
        self.add_check(QualityCheck(
            name='null_check',
            check_fn=self._check_nulls,
            severity='critical',
            description='Check for null/missing values'
        ))

        # Validity checks
        self.add_check(QualityCheck(
            name='price_validity',
            check_fn=self._check_price_validity,
            severity='critical',
            description='Check price values are valid'
        ))

        self.add_check(QualityCheck(
            name='ohlc_consistency',
            check_fn=self._check_ohlc_consistency,
            severity='critical',
            description='Check OHLC relationship'
        ))

        # Timeliness checks
        self.add_check(QualityCheck(
            name='data_freshness',
            check_fn=self._check_freshness,
            severity='warning',
            description='Check data is recent'
        ))

        self.add_check(QualityCheck(
            name='gap_detection',
            check_fn=self._check_gaps,
            severity='warning',
            description='Check for data gaps'
        ))

        # Accuracy checks
        self.add_check(QualityCheck(
            name='outlier_detection',
            check_fn=self._check_outliers,
            severity='warning',
            description='Check for outliers'
        ))

        self.add_check(QualityCheck(
            name='statistical_consistency',
            check_fn=self._check_statistical_consistency,
            severity='info',
            description='Check statistical properties'
        ))

    def add_check(self, check: QualityCheck):
        """Add quality check"""
        self.checks.append(check)

    def validate(self, df: pd.DataFrame, dataset_name: str) -> QualityReport:
        """Run all quality checks"""
        issues = []
        passed = 0
        failed = 0

        for check in self.checks:
            try:
                result = check.check_fn(df)
                if result['passed']:
                    passed += 1
                else:
                    failed += 1
                    issues.append({
                        'check': check.name,
                        'severity': check.severity,
                        'description': check.description,
                        'details': result.get('details', ''),
                        'affected_rows': result.get('affected_rows', 0)
                    })
            except Exception as e:
                failed += 1
                issues.append({
                    'check': check.name,
                    'severity': 'critical',
                    'description': f'Check failed with error: {str(e)}',
                    'details': str(e)
                })

        # Calculate overall score (0-100)
        total_checks = passed + failed
        critical_failures = sum(1 for i in issues if i['severity'] == 'critical')

        if critical_failures > 0:
            score = max(0, 50 - critical_failures * 10)
        else:
            score = (passed / total_checks * 100) if total_checks > 0 else 100

        return QualityReport(
            timestamp=datetime.now(),
            dataset=dataset_name,
            total_records=len(df),
            passed_checks=passed,
            failed_checks=failed,
            issues=issues,
            overall_score=score
        )

    def _check_nulls(self, df: pd.DataFrame) -> Dict:
        """Check for null values"""
        null_counts = df.isnull().sum()
        total_nulls = null_counts.sum()

        if total_nulls == 0:
            return {'passed': True}

        null_cols = null_counts[null_counts > 0].to_dict()
        return {
            'passed': False,
            'details': f'Found {total_nulls} null values in columns: {null_cols}',
            'affected_rows': int(df.isnull().any(axis=1).sum())
        }

    def _check_price_validity(self, df: pd.DataFrame) -> Dict:
        """Check price values are valid"""
        price_cols = ['open', 'high', 'low', 'close']
        available_cols = [c for c in price_cols if c in df.columns]

        if not available_cols:
            return {'passed': True}

        issues = []
        for col in available_cols:
            # Check for negative prices
            negative = (df[col] < 0).sum()
            if negative > 0:
                issues.append(f'{col} has {negative} negative values')

            # Check for zero prices
            zeros = (df[col] == 0).sum()
            if zeros > 0:
                issues.append(f'{col} has {zeros} zero values')

            # Check for inf values
            infs = np.isinf(df[col]).sum()
            if infs > 0:
                issues.append(f'{col} has {infs} infinite values')

        if issues:
            return {
                'passed': False,
                'details': '; '.join(issues),
                'affected_rows': len(df[(df[available_cols] <= 0).any(axis=1)])
            }

        return {'passed': True}

    def _check_ohlc_consistency(self, df: pd.DataFrame) -> Dict:
        """Check OHLC relationship"""
        required_cols = ['open', 'high', 'low', 'close']
        if not all(c in df.columns for c in required_cols):
            return {'passed': True}

        issues = []

        # High >= Low
        hl_violations = (df['high'] < df['low']).sum()
        if hl_violations > 0:
            issues.append(f'{hl_violations} rows where high < low')

        # High >= Open and Close
        ho_violations = (df['high'] < df['open']).sum()
        hc_violations = (df['high'] < df['close']).sum()
        if ho_violations > 0:
            issues.append(f'{ho_violations} rows where high < open')
        if hc_violations > 0:
            issues.append(f'{hc_violations} rows where high < close')

        # Low <= Open and Close
        lo_violations = (df['low'] > df['open']).sum()
        lc_violations = (df['low'] > df['close']).sum()
        if lo_violations > 0:
            issues.append(f'{lo_violations} rows where low > open')
        if lc_violations > 0:
            issues.append(f'{lc_violations} rows where low > close')

        if issues:
            return {
                'passed': False,
                'details': '; '.join(issues),
                'affected_rows': hl_violations + ho_violations + hc_violations + lo_violations + lc_violations
            }

        return {'passed': True}

    def _check_freshness(self, df: pd.DataFrame, max_age_minutes: int = 60) -> Dict:
        """Check data freshness"""
        if 'timestamp' not in df.columns:
            return {'passed': True}

        latest = df['timestamp'].max()
        if isinstance(latest, str):
            latest = pd.to_datetime(latest)

        age = datetime.now() - latest
        age_minutes = age.total_seconds() / 60

        if age_minutes > max_age_minutes:
            return {
                'passed': False,
                'details': f'Latest data is {age_minutes:.1f} minutes old (max: {max_age_minutes})',
                'affected_rows': 0
            }

        return {'passed': True}

    def _check_gaps(self, df: pd.DataFrame) -> Dict:
        """Check for data gaps"""
        if 'timestamp' not in df.columns or len(df) < 2:
            return {'passed': True}

        df_sorted = df.sort_values('timestamp')
        time_diffs = df_sorted['timestamp'].diff()

        # Calculate expected interval
        median_diff = time_diffs.median()

        # Find gaps (> 3x median interval)
        gaps = time_diffs[time_diffs > median_diff * 3]

        if len(gaps) > 0:
            return {
                'passed': False,
                'details': f'Found {len(gaps)} gaps in data',
                'affected_rows': len(gaps)
            }

        return {'passed': True}

    def _check_outliers(self, df: pd.DataFrame, z_threshold: float = 5.0) -> Dict:
        """Check for outliers using Z-score"""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        outlier_counts = {}

        for col in numeric_cols:
            z_scores = np.abs(stats.zscore(df[col].dropna()))
            outliers = (z_scores > z_threshold).sum()
            if outliers > 0:
                outlier_counts[col] = int(outliers)

        if outlier_counts:
            total = sum(outlier_counts.values())
            return {
                'passed': False,
                'details': f'Found {total} outliers (z > {z_threshold}): {outlier_counts}',
                'affected_rows': total
            }

        return {'passed': True}

    def _check_statistical_consistency(self, df: pd.DataFrame) -> Dict:
        """Check statistical properties"""
        if 'close' not in df.columns or len(df) < 100:
            return {'passed': True}

        returns = df['close'].pct_change().dropna()

        # Check for extreme kurtosis
        kurtosis = stats.kurtosis(returns)
        if kurtosis > 50:
            return {
                'passed': False,
                'details': f'Extremely high kurtosis: {kurtosis:.2f}',
                'affected_rows': 0
            }

        # Check for unit root (data should be non-stationary for prices)
        # But returns should be stationary
        adf_stat, p_value, _, _, _, _ = adfuller(returns)
        if p_value > 0.1:  # Returns should be stationary
            return {
                'passed': False,
                'details': f'Returns may not be stationary (ADF p-value: {p_value:.4f})',
                'affected_rows': 0
            }

        return {'passed': True}


class AnomalyDetector:
    """
    Real-time anomaly detection for streaming data
    """

    def __init__(self, window_size: int = 100, sensitivity: float = 3.0):
        self.window_size = window_size
        self.sensitivity = sensitivity
        self.buffers: Dict[str, deque] = {}

    def detect(self, key: str, value: float) -> Optional[Dict]:
        """
        Detect if value is anomalous
        """
        if key not in self.buffers:
            self.buffers[key] = deque(maxlen=self.window_size)

        buffer = self.buffers[key]

        if len(buffer) < 10:
            buffer.append(value)
            return None

        # Calculate statistics
        values = np.array(buffer)
        mean = np.mean(values)
        std = np.std(values)

        # Z-score
        z_score = (value - mean) / (std + 1e-10)

        # Add to buffer
        buffer.append(value)

        # Check for anomaly
        if abs(z_score) > self.sensitivity:
            return {
                'key': key,
                'value': value,
                'z_score': z_score,
                'mean': mean,
                'std': std,
                'severity': 'high' if abs(z_score) > self.sensitivity * 2 else 'medium'
            }

        return None
```

---

## Feature Engineering Pipelines

### Automated Feature Engineering

```python
from typing import Dict, List, Optional, Callable
import pandas as pd
import numpy as np
from datetime import datetime

class FeatureEngineeringPipeline:
    """
    Automated feature engineering pipeline
    """

    def __init__(self):
        self.feature_generators: List[Callable] = []
        self._register_default_generators()

    def _register_default_generators(self):
        """Register default feature generators"""
        self.feature_generators = [
            self._generate_price_features,
            self._generate_volume_features,
            self._generate_momentum_features,
            self._generate_volatility_features,
            self._generate_microstructure_features,
            self._generate_time_features
        ]

    def generate_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate all features"""
        result = df.copy()

        for generator in self.feature_generators:
            try:
                features = generator(result)
                result = pd.concat([result, features], axis=1)
            except Exception as e:
                logging.warning(f"Feature generator failed: {e}")

        return result

    def _generate_price_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate price-based features"""
        features = pd.DataFrame(index=df.index)

        if 'close' not in df.columns:
            return features

        close = df['close']

        # Moving averages
        for period in [5, 10, 20, 50, 100, 200]:
            features[f'sma_{period}'] = close.rolling(period).mean()
            features[f'ema_{period}'] = close.ewm(span=period).mean()

        # Price relative to MAs
        for period in [20, 50, 200]:
            if f'sma_{period}' in features.columns:
                features[f'price_to_sma_{period}'] = close / features[f'sma_{period}']

        # Price changes
        for period in [1, 5, 10, 20]:
            features[f'return_{period}'] = close.pct_change(period)
            features[f'log_return_{period}'] = np.log(close / close.shift(period))

        # Range features
        if all(c in df.columns for c in ['high', 'low']):
            features['range'] = df['high'] - df['low']
            features['range_pct'] = (df['high'] - df['low']) / close

        return features

    def _generate_volume_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate volume-based features"""
        features = pd.DataFrame(index=df.index)

        if 'volume' not in df.columns:
            return features

        volume = df['volume']

        # Volume MAs
        for period in [5, 10, 20, 50]:
            features[f'volume_sma_{period}'] = volume.rolling(period).mean()

        # Volume ratio
        features['volume_ratio_20'] = volume / volume.rolling(20).mean()

        # Volume trend
        features['volume_trend'] = volume.rolling(10).mean() / volume.rolling(30).mean()

        # On-balance volume
        if 'close' in df.columns:
            obv = (np.sign(df['close'].diff()) * volume).cumsum()
            features['obv'] = obv
            features['obv_sma_20'] = obv.rolling(20).mean()

        # VWAP
        if all(c in df.columns for c in ['high', 'low', 'close']):
            typical_price = (df['high'] + df['low'] + df['close']) / 3
            features['vwap'] = (typical_price * volume).cumsum() / volume.cumsum()

        return features

    def _generate_momentum_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate momentum features"""
        features = pd.DataFrame(index=df.index)

        if 'close' not in df.columns:
            return features

        close = df['close']

        # RSI
        for period in [7, 14, 21]:
            delta = close.diff()
            gain = delta.where(delta > 0, 0).rolling(period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
            rs = gain / (loss + 1e-10)
            features[f'rsi_{period}'] = 100 - (100 / (1 + rs))

        # MACD
        ema_12 = close.ewm(span=12).mean()
        ema_26 = close.ewm(span=26).mean()
        features['macd'] = ema_12 - ema_26
        features['macd_signal'] = features['macd'].ewm(span=9).mean()
        features['macd_hist'] = features['macd'] - features['macd_signal']

        # Stochastic
        if all(c in df.columns for c in ['high', 'low']):
            for period in [14, 21]:
                low_min = df['low'].rolling(period).min()
                high_max = df['high'].rolling(period).max()
                features[f'stoch_k_{period}'] = 100 * (close - low_min) / (high_max - low_min + 1e-10)
                features[f'stoch_d_{period}'] = features[f'stoch_k_{period}'].rolling(3).mean()

        # ROC
        for period in [10, 20]:
            features[f'roc_{period}'] = (close - close.shift(period)) / close.shift(period) * 100

        return features

    def _generate_volatility_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate volatility features"""
        features = pd.DataFrame(index=df.index)

        if 'close' not in df.columns:
            return features

        close = df['close']
        returns = close.pct_change()

        # Historical volatility
        for period in [10, 20, 30]:
            features[f'volatility_{period}'] = returns.rolling(period).std() * np.sqrt(252)

        # ATR
        if all(c in df.columns for c in ['high', 'low']):
            high = df['high']
            low = df['low']

            tr = pd.concat([
                high - low,
                (high - close.shift()).abs(),
                (low - close.shift()).abs()
            ], axis=1).max(axis=1)

            for period in [7, 14, 21]:
                features[f'atr_{period}'] = tr.rolling(period).mean()
                features[f'atr_pct_{period}'] = features[f'atr_{period}'] / close

        # Bollinger Bands
        for period in [20]:
            sma = close.rolling(period).mean()
            std = close.rolling(period).std()
            features['bb_upper'] = sma + 2 * std
            features['bb_lower'] = sma - 2 * std
            features['bb_width'] = (features['bb_upper'] - features['bb_lower']) / sma
            features['bb_position'] = (close - features['bb_lower']) / (features['bb_upper'] - features['bb_lower'])

        return features

    def _generate_microstructure_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate microstructure features"""
        features = pd.DataFrame(index=df.index)

        if 'close' not in df.columns:
            return features

        close = df['close']

        # Realized volatility (high-frequency proxy)
        if all(c in df.columns for c in ['high', 'low']):
            # Garman-Klass volatility
            log_hl = np.log(df['high'] / df['low'])
            log_co = np.log(close / df['open']) if 'open' in df.columns else 0

            features['gk_volatility'] = np.sqrt(
                0.5 * log_hl**2 - (2 * np.log(2) - 1) * log_co**2
            )

            # Parkinson volatility
            features['parkinson_volatility'] = log_hl / (2 * np.sqrt(np.log(2)))

        # Kyle's lambda proxy (price impact)
        if 'volume' in df.columns:
            returns = close.pct_change()
            volume = df['volume']

            for period in [20]:
                cov = returns.rolling(period).cov(volume)
                var = volume.rolling(period).var()
                features[f'kyle_lambda_{period}'] = cov / (var + 1e-10)

        return features

    def _generate_time_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate time-based features"""
        features = pd.DataFrame(index=df.index)

        if not isinstance(df.index, pd.DatetimeIndex):
            return features

        # Time features
        features['hour'] = df.index.hour
        features['day_of_week'] = df.index.dayofweek
        features['day_of_month'] = df.index.day
        features['month'] = df.index.month

        # Cyclical encoding
        features['hour_sin'] = np.sin(2 * np.pi * features['hour'] / 24)
        features['hour_cos'] = np.cos(2 * np.pi * features['hour'] / 24)
        features['dow_sin'] = np.sin(2 * np.pi * features['day_of_week'] / 7)
        features['dow_cos'] = np.cos(2 * np.pi * features['day_of_week'] / 7)

        # Session flags
        features['is_weekend'] = features['day_of_week'].isin([5, 6]).astype(int)
        features['is_us_hours'] = features['hour'].between(13, 21).astype(int)
        features['is_asia_hours'] = features['hour'].between(0, 8).astype(int)
        features['is_europe_hours'] = features['hour'].between(7, 16).astype(int)

        return features
```

---

## Data Versioning and Lineage

### Data Versioning System

```python
import hashlib
import json
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

@dataclass
class DataVersion:
    version_id: str
    dataset_name: str
    created_at: datetime
    schema_hash: str
    row_count: int
    checksum: str
    parent_version: Optional[str]
    metadata: Dict[str, Any]
    lineage: List[str]


class DataVersionManager:
    """
    Manage data versions and lineage
    """

    def __init__(self, storage_path: str):
        self.storage_path = storage_path
        self.versions: Dict[str, DataVersion] = {}

    def create_version(self, df: pd.DataFrame, dataset_name: str,
                       parent_version: Optional[str] = None,
                       metadata: Dict = None) -> DataVersion:
        """Create new data version"""
        # Calculate checksums
        schema_hash = self._hash_schema(df)
        data_checksum = self._hash_data(df)

        # Generate version ID
        version_id = f"{dataset_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{data_checksum[:8]}"

        # Build lineage
        lineage = []
        if parent_version and parent_version in self.versions:
            lineage = self.versions[parent_version].lineage.copy()
            lineage.append(parent_version)

        version = DataVersion(
            version_id=version_id,
            dataset_name=dataset_name,
            created_at=datetime.now(),
            schema_hash=schema_hash,
            row_count=len(df),
            checksum=data_checksum,
            parent_version=parent_version,
            metadata=metadata or {},
            lineage=lineage
        )

        self.versions[version_id] = version
        self._save_version(version, df)

        return version

    def _hash_schema(self, df: pd.DataFrame) -> str:
        """Hash DataFrame schema"""
        schema_str = json.dumps({
            'columns': list(df.columns),
            'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()}
        }, sort_keys=True)
        return hashlib.sha256(schema_str.encode()).hexdigest()

    def _hash_data(self, df: pd.DataFrame) -> str:
        """Hash DataFrame content"""
        return hashlib.sha256(
            pd.util.hash_pandas_object(df).values.tobytes()
        ).hexdigest()

    def _save_version(self, version: DataVersion, df: pd.DataFrame):
        """Save version to storage"""
        import os

        version_dir = os.path.join(self.storage_path, version.version_id)
        os.makedirs(version_dir, exist_ok=True)

        # Save data
        df.to_parquet(os.path.join(version_dir, 'data.parquet'))

        # Save metadata
        with open(os.path.join(version_dir, 'version.json'), 'w') as f:
            json.dump({
                **asdict(version),
                'created_at': version.created_at.isoformat()
            }, f, indent=2)

    def get_version(self, version_id: str) -> Optional[DataVersion]:
        """Get version by ID"""
        return self.versions.get(version_id)

    def load_data(self, version_id: str) -> pd.DataFrame:
        """Load data for version"""
        import os
        data_path = os.path.join(self.storage_path, version_id, 'data.parquet')
        return pd.read_parquet(data_path)

    def get_lineage(self, version_id: str) -> List[DataVersion]:
        """Get full lineage for version"""
        version = self.versions.get(version_id)
        if not version:
            return []

        lineage = []
        for vid in version.lineage:
            if vid in self.versions:
                lineage.append(self.versions[vid])

        lineage.append(version)
        return lineage

    def compare_versions(self, version_id_1: str, version_id_2: str) -> Dict:
        """Compare two versions"""
        v1 = self.versions.get(version_id_1)
        v2 = self.versions.get(version_id_2)

        if not v1 or not v2:
            raise ValueError("Version not found")

        return {
            'schema_changed': v1.schema_hash != v2.schema_hash,
            'row_count_diff': v2.row_count - v1.row_count,
            'time_diff': (v2.created_at - v1.created_at).total_seconds(),
            'same_lineage': v1.version_id in v2.lineage or v2.version_id in v1.lineage
        }


class DataLineageTracker:
    """
    Track data lineage through transformations
    """

    def __init__(self):
        self.operations: List[Dict] = []

    def record_operation(self, operation_type: str, input_datasets: List[str],
                         output_dataset: str, params: Dict = None):
        """Record a data transformation operation"""
        self.operations.append({
            'timestamp': datetime.now().isoformat(),
            'operation': operation_type,
            'inputs': input_datasets,
            'output': output_dataset,
            'params': params or {}
        })

    def get_upstream(self, dataset: str) -> List[str]:
        """Get all upstream datasets"""
        upstream = set()

        for op in self.operations:
            if op['output'] == dataset:
                upstream.update(op['inputs'])
                for inp in op['inputs']:
                    upstream.update(self.get_upstream(inp))

        return list(upstream)

    def get_downstream(self, dataset: str) -> List[str]:
        """Get all downstream datasets"""
        downstream = set()

        for op in self.operations:
            if dataset in op['inputs']:
                downstream.add(op['output'])
                downstream.update(self.get_downstream(op['output']))

        return list(downstream)

    def export_lineage_graph(self) -> Dict:
        """Export lineage as graph structure"""
        nodes = set()
        edges = []

        for op in self.operations:
            nodes.add(op['output'])
            for inp in op['inputs']:
                nodes.add(inp)
                edges.append({
                    'source': inp,
                    'target': op['output'],
                    'operation': op['operation']
                })

        return {
            'nodes': list(nodes),
            'edges': edges
        }
```

---

## Best Practices Summary

### Data Engineering Checklist

```python
data_engineering_checklist = {
    'ingestion': [
        'Implement rate limiting for API calls',
        'Handle connection failures gracefully',
        'Use exponential backoff for retries',
        'Validate data on receipt',
        'Log all data fetches for debugging'
    ],

    'storage': [
        'Use appropriate storage for data type',
        'Implement data compression for older data',
        'Set up retention policies',
        'Create indexes for common queries',
        'Use connection pooling'
    ],

    'processing': [
        'Process data in batches when possible',
        'Use async/await for I/O operations',
        'Implement idempotent operations',
        'Handle late-arriving data',
        'Monitor processing latency'
    ],

    'quality': [
        'Validate data at every stage',
        'Implement anomaly detection',
        'Track data quality metrics',
        'Alert on quality issues',
        'Document data contracts'
    ],

    'versioning': [
        'Version all datasets',
        'Track data lineage',
        'Enable rollback capability',
        'Document transformations',
        'Maintain audit trail'
    ]
}
```

---

*Robust data infrastructure is the foundation of reliable trading systems.*
