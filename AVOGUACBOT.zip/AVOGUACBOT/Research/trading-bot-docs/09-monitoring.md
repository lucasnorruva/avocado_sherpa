# 09 - Monitoring and Alerts

> **Keeping your trading bot healthy and being notified of issues**

---

## Overview

A trading bot running without monitoring is a disaster waiting to happen. This document covers logging, metrics, alerting, and maintenance practices to keep your bot running reliably.

---

## Logging

### Structured Logging

```python
import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging"""

    def format(self, record):
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
        }

        # Add extra fields
        if hasattr(record, 'extra'):
            log_entry.update(record.extra)

        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)

        return json.dumps(log_entry)


def setup_logging(log_level='INFO', log_file='trading_bot.log'):
    """Configure logging for the trading bot"""
    logger = logging.getLogger('trading_bot')
    logger.setLevel(getattr(logging, log_level))

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(
        logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    )
    logger.addHandler(console_handler)

    # File handler with JSON formatting
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(JSONFormatter())
    logger.addHandler(file_handler)

    return logger


# Usage
logger = setup_logging()

# Log with extra context
logger.info("Trade executed", extra={
    'extra': {
        'symbol': 'BTC/USDT',
        'side': 'buy',
        'size': 0.1,
        'price': 50000,
        'order_id': '12345'
    }
})
```

### Log Categories

```python
class TradeLogger:
    """Specialized logger for trading events"""

    def __init__(self):
        self.logger = logging.getLogger('trading_bot.trades')

    def log_signal(self, signal):
        """Log strategy signal"""
        self.logger.info(
            f"Signal: {signal.type.value} {signal.symbol}",
            extra={'extra': {
                'event': 'signal',
                'type': signal.type.value,
                'symbol': signal.symbol,
                'strength': signal.strength,
                'price': signal.price,
            }}
        )

    def log_order_submitted(self, order):
        """Log order submission"""
        self.logger.info(
            f"Order submitted: {order['side']} {order['amount']} {order['symbol']}",
            extra={'extra': {
                'event': 'order_submitted',
                'order_id': order['id'],
                'symbol': order['symbol'],
                'side': order['side'],
                'type': order['type'],
                'amount': order['amount'],
                'price': order.get('price'),
            }}
        )

    def log_order_filled(self, order):
        """Log order fill"""
        self.logger.info(
            f"Order filled: {order['id']}",
            extra={'extra': {
                'event': 'order_filled',
                'order_id': order['id'],
                'symbol': order['symbol'],
                'filled_amount': order['filled'],
                'avg_price': order['average'],
            }}
        )

    def log_position_opened(self, position):
        """Log position opening"""
        self.logger.info(
            f"Position opened: {position['direction']} {position['symbol']}",
            extra={'extra': {
                'event': 'position_opened',
                'symbol': position['symbol'],
                'direction': position['direction'],
                'size': position['size'],
                'entry_price': position['entry_price'],
            }}
        )

    def log_position_closed(self, position, pnl):
        """Log position closure"""
        self.logger.info(
            f"Position closed: {position['symbol']} P&L: {pnl:.2f}",
            extra={'extra': {
                'event': 'position_closed',
                'symbol': position['symbol'],
                'pnl': pnl,
                'pnl_pct': pnl / position['value'] * 100,
            }}
        )

    def log_error(self, error, context=None):
        """Log error with context"""
        self.logger.error(
            f"Error: {error}",
            extra={'extra': {
                'event': 'error',
                'error': str(error),
                'context': context,
            }},
            exc_info=True
        )
```

---

## Metrics Collection

### Prometheus Metrics

```python
from prometheus_client import Counter, Gauge, Histogram, start_http_server

class MetricsCollector:
    """Collect and expose Prometheus metrics"""

    def __init__(self):
        # Counters
        self.trades_total = Counter(
            'trading_bot_trades_total',
            'Total number of trades',
            ['symbol', 'side', 'result']
        )
        self.orders_total = Counter(
            'trading_bot_orders_total',
            'Total number of orders',
            ['symbol', 'type', 'status']
        )
        self.errors_total = Counter(
            'trading_bot_errors_total',
            'Total number of errors',
            ['type']
        )

        # Gauges
        self.account_balance = Gauge(
            'trading_bot_account_balance',
            'Current account balance'
        )
        self.daily_pnl = Gauge(
            'trading_bot_daily_pnl',
            'Daily profit/loss'
        )
        self.daily_drawdown = Gauge(
            'trading_bot_daily_drawdown',
            'Current daily drawdown percentage'
        )
        self.total_drawdown = Gauge(
            'trading_bot_total_drawdown',
            'Current total drawdown percentage'
        )
        self.open_positions = Gauge(
            'trading_bot_open_positions',
            'Number of open positions'
        )
        self.unrealized_pnl = Gauge(
            'trading_bot_unrealized_pnl',
            'Unrealized profit/loss'
        )

        # Histograms
        self.trade_duration = Histogram(
            'trading_bot_trade_duration_seconds',
            'Trade duration in seconds',
            buckets=[60, 300, 900, 1800, 3600, 7200, 14400, 28800, 86400]
        )
        self.trade_pnl = Histogram(
            'trading_bot_trade_pnl',
            'Trade profit/loss',
            buckets=[-1000, -500, -100, -50, 0, 50, 100, 500, 1000, 5000]
        )

    def record_trade(self, symbol, side, result, pnl, duration):
        """Record a completed trade"""
        self.trades_total.labels(
            symbol=symbol,
            side=side,
            result=result  # 'win' or 'loss'
        ).inc()
        self.trade_pnl.observe(pnl)
        self.trade_duration.observe(duration)

    def update_account_metrics(self, balance, daily_pnl, daily_dd, total_dd, positions, unrealized):
        """Update account-level metrics"""
        self.account_balance.set(balance)
        self.daily_pnl.set(daily_pnl)
        self.daily_drawdown.set(daily_dd)
        self.total_drawdown.set(total_dd)
        self.open_positions.set(positions)
        self.unrealized_pnl.set(unrealized)

    def start_server(self, port=9090):
        """Start Prometheus metrics server"""
        start_http_server(port)


# Usage in bot
metrics = MetricsCollector()
metrics.start_server(9090)

# Update metrics periodically
metrics.update_account_metrics(
    balance=100500,
    daily_pnl=500,
    daily_dd=0.02,
    total_dd=0.03,
    positions=2,
    unrealized=150
)
```

---

## Alerting

### Telegram Notifications

```python
import aiohttp
from enum import Enum

class AlertLevel(Enum):
    INFO = "ℹ️"
    WARNING = "⚠️"
    ERROR = "🚨"
    CRITICAL = "🔴"
    SUCCESS = "✅"

class TelegramNotifier:
    """Send alerts via Telegram"""

    def __init__(self, bot_token, chat_id):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{bot_token}"

    async def send_message(self, message, level=AlertLevel.INFO, parse_mode='HTML'):
        """Send a message to Telegram"""
        text = f"{level.value} {message}"

        async with aiohttp.ClientSession() as session:
            try:
                await session.post(
                    f"{self.base_url}/sendMessage",
                    json={
                        'chat_id': self.chat_id,
                        'text': text,
                        'parse_mode': parse_mode,
                    }
                )
            except Exception as e:
                print(f"Failed to send Telegram message: {e}")

    async def send_trade_alert(self, trade):
        """Send trade notification"""
        if trade['pnl'] >= 0:
            level = AlertLevel.SUCCESS
            emoji = "📈"
        else:
            level = AlertLevel.WARNING
            emoji = "📉"

        message = f"""
{emoji} <b>Trade Closed</b>

Symbol: {trade['symbol']}
Direction: {trade['direction']}
Entry: ${trade['entry_price']:,.2f}
Exit: ${trade['exit_price']:,.2f}
P&L: <b>${trade['pnl']:,.2f}</b> ({trade['pnl_pct']:.2f}%)
Duration: {trade['duration']}
"""
        await self.send_message(message, level)

    async def send_daily_summary(self, summary):
        """Send daily trading summary"""
        message = f"""
📊 <b>Daily Summary</b>

Date: {summary['date']}
Trades: {summary['total_trades']}
Win Rate: {summary['win_rate']:.1f}%
Daily P&L: <b>${summary['daily_pnl']:,.2f}</b>
Daily DD: {summary['daily_dd']:.2f}%
Total DD: {summary['total_dd']:.2f}%

Balance: ${summary['balance']:,.2f}
"""
        await self.send_message(message, AlertLevel.INFO)

    async def send_drawdown_warning(self, dd_type, current_dd, max_dd):
        """Send drawdown warning"""
        pct_of_limit = (current_dd / max_dd) * 100

        message = f"""
⚠️ <b>Drawdown Warning</b>

Type: {dd_type}
Current: {current_dd:.2f}%
Limit: {max_dd:.2f}%
Used: {pct_of_limit:.1f}% of limit

{"🛑 Trading paused!" if pct_of_limit > 80 else "⚡ Monitor closely!"}
"""
        level = AlertLevel.CRITICAL if pct_of_limit > 80 else AlertLevel.WARNING
        await self.send_message(message, level)

    async def send_error_alert(self, error, context=None):
        """Send error notification"""
        message = f"""
🚨 <b>Error Alert</b>

Error: {error}
Context: {context or 'N/A'}
Time: {datetime.now().isoformat()}

Check logs for details.
"""
        await self.send_message(message, AlertLevel.ERROR)
```

### Alert Rules

```python
class AlertManager:
    """Manage alert rules and thresholds"""

    def __init__(self, notifier: TelegramNotifier):
        self.notifier = notifier
        self.alert_cooldowns = {}  # Prevent spam

    async def check_drawdown_alerts(self, daily_dd, total_dd, max_daily, max_total):
        """Check and send drawdown alerts"""
        # Daily drawdown warnings
        daily_pct = daily_dd / max_daily

        if daily_pct >= 0.9:
            await self._send_with_cooldown(
                'daily_dd_critical',
                self.notifier.send_drawdown_warning,
                'Daily', daily_dd * 100, max_daily * 100
            )
        elif daily_pct >= 0.7:
            await self._send_with_cooldown(
                'daily_dd_warning',
                self.notifier.send_drawdown_warning,
                'Daily', daily_dd * 100, max_daily * 100
            )

        # Total drawdown warnings
        total_pct = total_dd / max_total

        if total_pct >= 0.9:
            await self._send_with_cooldown(
                'total_dd_critical',
                self.notifier.send_drawdown_warning,
                'Total', total_dd * 100, max_total * 100
            )
        elif total_pct >= 0.7:
            await self._send_with_cooldown(
                'total_dd_warning',
                self.notifier.send_drawdown_warning,
                'Total', total_dd * 100, max_total * 100
            )

    async def _send_with_cooldown(self, alert_id, func, *args, cooldown_minutes=30):
        """Send alert with cooldown to prevent spam"""
        now = datetime.now()
        last_sent = self.alert_cooldowns.get(alert_id)

        if last_sent and (now - last_sent).seconds < cooldown_minutes * 60:
            return  # Still in cooldown

        await func(*args)
        self.alert_cooldowns[alert_id] = now
```

---

## Monitoring Dashboard

### Grafana Dashboard (JSON)

```json
{
  "dashboard": {
    "title": "Trading Bot Dashboard",
    "panels": [
      {
        "title": "Account Balance",
        "type": "stat",
        "targets": [
          {
            "expr": "trading_bot_account_balance",
            "legendFormat": "Balance"
          }
        ]
      },
      {
        "title": "Daily P&L",
        "type": "stat",
        "targets": [
          {
            "expr": "trading_bot_daily_pnl",
            "legendFormat": "Daily P&L"
          }
        ]
      },
      {
        "title": "Drawdown",
        "type": "gauge",
        "targets": [
          {
            "expr": "trading_bot_daily_drawdown * 100",
            "legendFormat": "Daily DD %"
          },
          {
            "expr": "trading_bot_total_drawdown * 100",
            "legendFormat": "Total DD %"
          }
        ]
      },
      {
        "title": "Trades Over Time",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(trading_bot_trades_total[1h])",
            "legendFormat": "Trades/hour"
          }
        ]
      },
      {
        "title": "P&L Distribution",
        "type": "histogram",
        "targets": [
          {
            "expr": "trading_bot_trade_pnl_bucket",
            "legendFormat": "P&L"
          }
        ]
      }
    ]
  }
}
```

---

## Health Monitoring

### Heartbeat System

```python
import asyncio
from datetime import datetime, timedelta

class HeartbeatMonitor:
    """Monitor bot health through heartbeats"""

    def __init__(self, notifier, max_interval_seconds=60):
        self.notifier = notifier
        self.max_interval = max_interval_seconds
        self.last_heartbeat = datetime.now()
        self.components = {}

    def heartbeat(self, component='main'):
        """Record a heartbeat"""
        self.components[component] = datetime.now()
        self.last_heartbeat = datetime.now()

    async def monitor(self):
        """Monitor heartbeats and alert on issues"""
        while True:
            await asyncio.sleep(30)

            now = datetime.now()

            # Check main heartbeat
            if (now - self.last_heartbeat).seconds > self.max_interval:
                await self.notifier.send_message(
                    f"🚨 No heartbeat for {self.max_interval}s! Bot may be stuck.",
                    AlertLevel.CRITICAL
                )

            # Check component heartbeats
            for component, last_beat in self.components.items():
                if (now - last_beat).seconds > self.max_interval * 2:
                    await self.notifier.send_message(
                        f"⚠️ Component '{component}' not responding",
                        AlertLevel.WARNING
                    )

    def get_status(self):
        """Get health status of all components"""
        now = datetime.now()
        status = {}

        for component, last_beat in self.components.items():
            age = (now - last_beat).seconds
            status[component] = {
                'last_heartbeat': last_beat.isoformat(),
                'age_seconds': age,
                'healthy': age < self.max_interval
            }

        return status
```

### System Resource Monitoring

```python
import psutil

class ResourceMonitor:
    """Monitor system resources"""

    def __init__(self, notifier):
        self.notifier = notifier

    async def check_resources(self):
        """Check system resources and alert if needed"""
        # CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        if cpu_percent > 90:
            await self.notifier.send_message(
                f"⚠️ High CPU usage: {cpu_percent}%",
                AlertLevel.WARNING
            )

        # Memory
        memory = psutil.virtual_memory()
        if memory.percent > 90:
            await self.notifier.send_message(
                f"⚠️ High memory usage: {memory.percent}%",
                AlertLevel.WARNING
            )

        # Disk
        disk = psutil.disk_usage('/')
        if disk.percent > 90:
            await self.notifier.send_message(
                f"⚠️ Low disk space: {disk.percent}% used",
                AlertLevel.WARNING
            )

        return {
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'disk_percent': disk.percent
        }
```

---

## Maintenance Tasks

### Scheduled Tasks

```python
import aioschedule as schedule
import asyncio

class MaintenanceScheduler:
    """Schedule maintenance tasks"""

    def __init__(self, bot, notifier):
        self.bot = bot
        self.notifier = notifier

    def setup_schedule(self):
        """Setup scheduled tasks"""
        # Daily summary at end of day
        schedule.every().day.at("23:55").do(self.send_daily_summary)

        # Hourly health check
        schedule.every().hour.do(self.hourly_health_check)

        # Daily database cleanup
        schedule.every().day.at("04:00").do(self.cleanup_old_data)

        # Weekly backup
        schedule.every().sunday.at("03:00").do(self.weekly_backup)

    async def run_scheduler(self):
        """Run the scheduler"""
        while True:
            await schedule.run_pending()
            await asyncio.sleep(60)

    async def send_daily_summary(self):
        """Send daily trading summary"""
        summary = self.bot.get_daily_summary()
        await self.notifier.send_daily_summary(summary)

    async def hourly_health_check(self):
        """Hourly health verification"""
        health = self.bot.get_health_status()
        if not health['healthy']:
            await self.notifier.send_message(
                f"⚠️ Health check failed: {health['issues']}",
                AlertLevel.WARNING
            )

    async def cleanup_old_data(self):
        """Clean up old logs and data"""
        # Delete logs older than 30 days
        # Archive old trade data
        pass

    async def weekly_backup(self):
        """Weekly backup of important data"""
        # Backup database
        # Backup configuration
        # Backup trade history
        pass
```

---

## Troubleshooting Runbook

### Common Issues

| Issue | Symptoms | Resolution |
|-------|----------|------------|
| Connection lost | No trades, heartbeat missing | Check internet, restart bot |
| Rate limited | 429 errors in logs | Reduce request frequency |
| Order rejected | Orders failing | Check balance, position limits |
| High latency | Slow order execution | Check network, consider VPS location |
| Memory leak | Increasing memory usage | Restart bot, check for data accumulation |

### Recovery Procedures

```python
class RecoveryProcedures:
    """Standard recovery procedures"""

    @staticmethod
    async def recover_from_disconnect(bot):
        """Recovery after exchange disconnect"""
        # 1. Wait for reconnection
        # 2. Sync positions with exchange
        # 3. Verify no orphan orders
        # 4. Resume trading
        pass

    @staticmethod
    async def recover_from_crash(bot):
        """Recovery after bot crash"""
        # 1. Load last known state
        # 2. Sync with exchange
        # 3. Check for missed fills
        # 4. Resume trading
        pass

    @staticmethod
    async def emergency_close_all(bot):
        """Emergency: close all positions"""
        # 1. Cancel all orders
        # 2. Close all positions at market
        # 3. Disable trading
        # 4. Alert admin
        pass
```

---

## Summary

Effective monitoring requires:

1. **Comprehensive logging** - Log all important events
2. **Real-time metrics** - Track key performance indicators
3. **Proactive alerting** - Get notified before problems become critical
4. **Health checks** - Continuously verify system health
5. **Regular maintenance** - Clean up, backup, and verify

With proper monitoring, you can catch issues early and maintain confidence in your bot's operation.

---

## Final Notes

Congratulations on completing this documentation! You now have all the knowledge needed to build, test, and deploy a trading bot for prop firm challenges.

**Remember:**
- Start small and scale up gradually
- Test extensively before using real capital
- Respect risk management rules absolutely
- Monitor your bot continuously
- Keep learning and improving

Good luck with your trading journey! 🚀

---

*This concludes the Trading Bot for Prop Firms documentation series.*
