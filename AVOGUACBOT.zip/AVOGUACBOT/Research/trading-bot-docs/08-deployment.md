# 08 - Deployment

> **Running your trading bot in production**

---

## Overview

Deploying a trading bot requires careful consideration of reliability, security, and monitoring. This document covers deployment strategies, infrastructure options, and operational best practices.

---

## Deployment Options

### 1. Local Machine

**Pros:** Simple, no cloud costs, low latency to local exchange
**Cons:** Depends on your internet, power outages, not scalable

**Best for:** Testing, paper trading, initial development

```bash
# Run with nohup to keep running after logout
nohup python trading_bot.py > bot.log 2>&1 &

# Or use screen/tmux
screen -S trading_bot
python trading_bot.py
# Ctrl+A, D to detach
```

### 2. Cloud VPS

**Pros:** Reliable, scalable, geographically flexible
**Cons:** Monthly cost, requires cloud knowledge

**Popular providers:**
- AWS EC2 / Lightsail
- Google Cloud Platform
- DigitalOcean
- Vultr
- Hetzner (good value)

**Recommended specs:**
- 2 vCPUs
- 4GB RAM
- SSD storage
- Location near exchange servers

### 3. Docker Deployment

**Pros:** Consistent environment, easy deployment, portable
**Cons:** Slight overhead, Docker knowledge required

---

## Docker Setup

### Dockerfile

```dockerfile
FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY src/ ./src/
COPY config/ ./config/

# Create non-root user
RUN useradd -m botuser && chown -R botuser:botuser /app
USER botuser

# Environment variables
ENV PYTHONUNBUFFERED=1
ENV PYTHONDONTWRITEBYTECODE=1

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD python -c "import requests; requests.get('http://localhost:8080/health')"

# Run the bot
CMD ["python", "-m", "src.main"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  trading-bot:
    build: .
    container_name: trading-bot
    restart: unless-stopped
    env_file:
      - .env
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    depends_on:
      - redis
      - postgres
    networks:
      - trading-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  redis:
    image: redis:7-alpine
    container_name: trading-redis
    restart: unless-stopped
    volumes:
      - redis-data:/data
    networks:
      - trading-network

  postgres:
    image: timescale/timescaledb:latest-pg14
    container_name: trading-db
    restart: unless-stopped
    environment:
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: trading_bot
    volumes:
      - postgres-data:/var/lib/postgresql/data
    networks:
      - trading-network

  grafana:
    image: grafana/grafana:latest
    container_name: trading-grafana
    restart: unless-stopped
    ports:
      - "3000:3000"
    volumes:
      - grafana-data:/var/lib/grafana
    networks:
      - trading-network

volumes:
  redis-data:
  postgres-data:
  grafana-data:

networks:
  trading-network:
    driver: bridge
```

### Deployment Commands

```bash
# Build and start
docker-compose up -d --build

# View logs
docker-compose logs -f trading-bot

# Stop
docker-compose down

# Update and restart
docker-compose pull
docker-compose up -d --build

# Check status
docker-compose ps
```

---

## Configuration Management

### Environment Variables

```python
# config/settings.py
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Exchange
    EXCHANGE_ID = os.getenv('EXCHANGE_ID', 'binance')
    API_KEY = os.getenv('API_KEY')
    API_SECRET = os.getenv('API_SECRET')
    TESTNET = os.getenv('TESTNET', 'true').lower() == 'true'

    # Trading
    SYMBOLS = os.getenv('SYMBOLS', 'BTC/USDT').split(',')
    TIMEFRAME = os.getenv('TIMEFRAME', '15m')
    RISK_PER_TRADE = float(os.getenv('RISK_PER_TRADE', '0.01'))

    # Prop Firm Rules
    MAX_DAILY_DD = float(os.getenv('MAX_DAILY_DD', '0.05'))
    MAX_TOTAL_DD = float(os.getenv('MAX_TOTAL_DD', '0.10'))
    INITIAL_BALANCE = float(os.getenv('INITIAL_BALANCE', '100000'))

    # Database
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_PORT = int(os.getenv('DB_PORT', '5432'))
    DB_NAME = os.getenv('DB_NAME', 'trading_bot')
    DB_USER = os.getenv('DB_USER', 'postgres')
    DB_PASSWORD = os.getenv('DB_PASSWORD')

    # Notifications
    TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
    TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')

    @classmethod
    def validate(cls):
        """Validate required configuration"""
        required = ['API_KEY', 'API_SECRET']
        missing = [key for key in required if not getattr(cls, key)]
        if missing:
            raise ValueError(f"Missing required config: {missing}")
```

### .env File (Never commit this!)

```bash
# .env
EXCHANGE_ID=binance
API_KEY=your_api_key_here
API_SECRET=your_api_secret_here
TESTNET=true

SYMBOLS=BTC/USDT,ETH/USDT
TIMEFRAME=15m
RISK_PER_TRADE=0.01

MAX_DAILY_DD=0.05
MAX_TOTAL_DD=0.10
INITIAL_BALANCE=100000

DB_HOST=postgres
DB_PORT=5432
DB_NAME=trading_bot
DB_USER=botuser
DB_PASSWORD=secure_password_here

TELEGRAM_TOKEN=your_telegram_bot_token
TELEGRAM_CHAT_ID=your_chat_id
```

---

## Security Best Practices

### API Key Security

```python
# Never hardcode API keys!
# Bad:
API_KEY = "abc123"  # DON'T DO THIS

# Good:
API_KEY = os.getenv('API_KEY')

# Even better - use secrets manager
from aws_secrets import get_secret
API_KEY = get_secret('trading-bot/api-key')
```

### API Key Permissions

Set the minimum permissions needed:
- ✅ Read account balance
- ✅ Place orders
- ✅ Cancel orders
- ❌ Withdraw (NEVER enable this)
- ❌ Transfer between accounts (usually not needed)

### IP Whitelisting

Most exchanges allow IP whitelisting:

```python
# Only allow API access from your server's IP
# Configure in exchange settings:
# Allowed IPs: 123.456.789.0
```

### Secrets in Docker

```yaml
# docker-compose.yml with secrets
services:
  trading-bot:
    secrets:
      - api_key
      - api_secret
    environment:
      - API_KEY_FILE=/run/secrets/api_key
      - API_SECRET_FILE=/run/secrets/api_secret

secrets:
  api_key:
    file: ./secrets/api_key.txt
  api_secret:
    file: ./secrets/api_secret.txt
```

---

## Process Management

### Using Systemd (Linux)

```ini
# /etc/systemd/system/trading-bot.service
[Unit]
Description=Crypto Trading Bot
After=network.target

[Service]
Type=simple
User=botuser
WorkingDirectory=/home/botuser/trading-bot
ExecStart=/home/botuser/trading-bot/venv/bin/python -m src.main
Restart=always
RestartSec=10
StandardOutput=append:/var/log/trading-bot/stdout.log
StandardError=append:/var/log/trading-bot/stderr.log

# Security
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start
sudo systemctl enable trading-bot
sudo systemctl start trading-bot

# Check status
sudo systemctl status trading-bot

# View logs
sudo journalctl -u trading-bot -f
```

### Using Supervisor

```ini
# /etc/supervisor/conf.d/trading-bot.conf
[program:trading-bot]
command=/home/botuser/trading-bot/venv/bin/python -m src.main
directory=/home/botuser/trading-bot
user=botuser
autostart=true
autorestart=true
stderr_logfile=/var/log/trading-bot/err.log
stdout_logfile=/var/log/trading-bot/out.log
environment=PYTHONUNBUFFERED="1"
```

---

## Health Checks

### Application Health Endpoint

```python
from aiohttp import web
import asyncio

class HealthServer:
    """Simple health check server"""

    def __init__(self, bot, port=8080):
        self.bot = bot
        self.port = port
        self.app = web.Application()
        self.app.router.add_get('/health', self.health_check)
        self.app.router.add_get('/status', self.status)

    async def health_check(self, request):
        """Basic health check"""
        checks = {
            'bot_running': self.bot.running,
            'exchange_connected': self.bot.exchange.connected,
            'last_heartbeat': self.bot.last_heartbeat,
        }

        all_healthy = all([
            checks['bot_running'],
            checks['exchange_connected'],
        ])

        status = 200 if all_healthy else 503
        return web.json_response(checks, status=status)

    async def status(self, request):
        """Detailed status"""
        return web.json_response({
            'status': 'running' if self.bot.running else 'stopped',
            'uptime': self.bot.get_uptime(),
            'positions': self.bot.get_open_positions(),
            'daily_pnl': self.bot.get_daily_pnl(),
            'drawdown': self.bot.get_current_drawdown(),
        })

    async def start(self):
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, '0.0.0.0', self.port)
        await site.start()
```

### External Monitoring

Use uptime monitoring services:
- UptimeRobot (free tier available)
- Pingdom
- StatusCake

```bash
# Configure to ping your health endpoint
# Alert if no response within 30 seconds
```

---

## Graceful Shutdown

```python
import signal
import asyncio

class TradingBot:
    def __init__(self):
        self.running = False
        self._setup_signal_handlers()

    def _setup_signal_handlers(self):
        """Handle shutdown signals gracefully"""
        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """Handle shutdown signal"""
        print(f"Received signal {signum}, initiating graceful shutdown...")
        asyncio.create_task(self.shutdown())

    async def shutdown(self):
        """Graceful shutdown procedure"""
        self.running = False

        # 1. Stop accepting new trades
        print("Stopping new trade execution...")

        # 2. Close all open positions (optional - depends on strategy)
        if self.config.close_on_shutdown:
            print("Closing open positions...")
            await self.close_all_positions()

        # 3. Cancel pending orders
        print("Canceling pending orders...")
        await self.cancel_all_orders()

        # 4. Save state
        print("Saving state...")
        await self.save_state()

        # 5. Close connections
        print("Closing connections...")
        await self.exchange.disconnect()

        print("Shutdown complete")
```

---

## Backup and Recovery

### State Backup

```python
import json
from datetime import datetime

class StateManager:
    """Manage bot state persistence"""

    def __init__(self, backup_path='./backups'):
        self.backup_path = backup_path

    def save_state(self, bot):
        """Save current bot state"""
        state = {
            'timestamp': datetime.now().isoformat(),
            'positions': bot.positions,
            'orders': bot.pending_orders,
            'daily_pnl': bot.daily_pnl,
            'total_pnl': bot.total_pnl,
            'trades_today': bot.trades_today,
        }

        filename = f"{self.backup_path}/state_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        with open(filename, 'w') as f:
            json.dump(state, f, indent=2, default=str)

        return filename

    def load_latest_state(self):
        """Load most recent state backup"""
        import glob

        files = sorted(glob.glob(f"{self.backup_path}/state_*.json"))
        if not files:
            return None

        with open(files[-1], 'r') as f:
            return json.load(f)

    def recover_from_crash(self, bot):
        """Recover bot state after crash"""
        state = self.load_latest_state()
        if not state:
            return False

        # Verify state is recent (within 1 hour)
        state_time = datetime.fromisoformat(state['timestamp'])
        if (datetime.now() - state_time).seconds > 3600:
            print("State too old, starting fresh")
            return False

        # Restore state
        bot.positions = state['positions']
        bot.pending_orders = state['orders']
        bot.daily_pnl = state['daily_pnl']

        # Sync with exchange
        await bot.sync_with_exchange()

        return True
```

### Database Backup

```bash
# PostgreSQL backup script
#!/bin/bash
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)

pg_dump -h localhost -U botuser trading_bot > $BACKUP_DIR/db_$DATE.sql
gzip $BACKUP_DIR/db_$DATE.sql

# Keep only last 7 days
find $BACKUP_DIR -name "db_*.sql.gz" -mtime +7 -delete
```

---

## Deployment Checklist

### Before Going Live

- [ ] Tested extensively on testnet
- [ ] Paper traded for minimum 2 weeks
- [ ] All API keys are properly secured
- [ ] IP whitelisting enabled
- [ ] Withdrawal disabled on API keys
- [ ] Monitoring and alerts configured
- [ ] Backup system in place
- [ ] Graceful shutdown tested
- [ ] Recovery procedure tested
- [ ] Documentation updated

### First Live Trading

- [ ] Start with minimum position size
- [ ] Monitor closely for first 24-48 hours
- [ ] Verify all alerts are working
- [ ] Check logs regularly
- [ ] Have manual override ready

---

*Next: [09-monitoring.md](./09-monitoring.md) - Monitoring, alerts, and maintenance*
