# 16 - Market Microstructure

> **Deep dive into how crypto markets work at the micro level**

---

## Overview

Market microstructure studies how markets actually operate - order matching, price formation, and the mechanics of trading. Understanding this helps you build better strategies and avoid common pitfalls.

---

## Order Book Mechanics

### How Order Books Work

```
                    ORDER BOOK
    ┌─────────────────────────────────────────┐
    │           ASKS (Sell Orders)            │
    │  Price     │  Size   │  Total           │
    │  $50,150   │  2.5    │  2.5             │
    │  $50,125   │  1.8    │  4.3             │
    │  $50,100   │  3.2    │  7.5    ← Best Ask│
    ├────────────┴─────────┴──────────────────┤
    │         Spread: $50 (0.1%)              │
    ├────────────┬─────────┬──────────────────┤
    │  $50,050   │  4.1    │  4.1    ← Best Bid│
    │  $50,025   │  2.3    │  6.4             │
    │  $50,000   │  5.0    │  11.4            │
    │           BIDS (Buy Orders)             │
    └─────────────────────────────────────────┘
```

### Order Types Deep Dive

```python
class OrderTypes:
    """
    Comprehensive order type explanations and usage
    """

    @staticmethod
    def market_order():
        """
        MARKET ORDER
        - Executes immediately at best available price
        - Guaranteed execution, not guaranteed price
        - "Crosses the spread" - pays the spread

        Use when:
        - Speed is critical
        - Liquid markets
        - Small orders relative to book depth

        Avoid when:
        - Low liquidity
        - Large orders (will move price)
        - Wide spreads
        """
        pass

    @staticmethod
    def limit_order():
        """
        LIMIT ORDER
        - Specifies maximum buy price or minimum sell price
        - May not execute if price doesn't reach limit
        - "Provides liquidity" - earns the spread

        Use when:
        - Price is more important than speed
        - You can wait for execution
        - You want to avoid slippage

        Avoid when:
        - Need immediate execution
        - Fast-moving markets
        """
        pass

    @staticmethod
    def stop_loss_order():
        """
        STOP LOSS (STOP MARKET)
        - Becomes market order when stop price is reached
        - Used to limit losses

        Risk: In fast markets, execution price can be
        significantly worse than stop price (slippage)

        Example:
        - Long BTC at $50,000
        - Stop loss at $49,000
        - If price gaps to $48,000, you sell at ~$48,000
        """
        pass

    @staticmethod
    def stop_limit_order():
        """
        STOP LIMIT
        - Becomes limit order when stop price is reached
        - Stop price triggers, limit price is worst execution

        Risk: May not execute if price moves too fast

        Example:
        - Stop price: $49,000
        - Limit price: $48,900
        - If price gaps below $48,900, order won't fill
        """
        pass

    @staticmethod
    def post_only_order():
        """
        POST ONLY (MAKER ONLY)
        - Only adds liquidity, never takes
        - Rejected if it would execute immediately
        - Ensures you pay maker fees (usually lower)

        Use when:
        - You want guaranteed maker rebate
        - Building positions slowly
        """
        pass

    @staticmethod
    def fill_or_kill():
        """
        FILL OR KILL (FOK)
        - Execute entire order immediately or cancel
        - No partial fills

        Use when:
        - All-or-nothing execution required
        - Testing liquidity
        """
        pass

    @staticmethod
    def immediate_or_cancel():
        """
        IMMEDIATE OR CANCEL (IOC)
        - Execute as much as possible immediately
        - Cancel any unfilled portion

        Use when:
        - Want immediate liquidity
        - Okay with partial fills
        """
        pass
```

### Spread Analysis

```python
class SpreadAnalyzer:
    """
    Analyze bid-ask spreads
    """

    def __init__(self, orderbook_history: list):
        self.history = orderbook_history

    def calculate_spread(self, orderbook: dict) -> dict:
        """Calculate various spread metrics"""
        best_bid = orderbook['bids'][0][0]
        best_ask = orderbook['asks'][0][0]

        absolute_spread = best_ask - best_bid
        mid_price = (best_bid + best_ask) / 2
        relative_spread = absolute_spread / mid_price

        return {
            'best_bid': best_bid,
            'best_ask': best_ask,
            'mid_price': mid_price,
            'absolute_spread': absolute_spread,
            'relative_spread_bps': relative_spread * 10000,  # Basis points
        }

    def effective_spread(self, trade_price: float, side: str,
                         mid_price: float) -> float:
        """
        Effective spread - what you actually paid

        Effective spread = 2 × |Trade Price - Mid Price|

        Lower is better
        """
        return 2 * abs(trade_price - mid_price)

    def realized_spread(self, trade_price: float, side: str,
                        mid_price_after: float) -> float:
        """
        Realized spread - spread after market impact

        For market makers: revenue after adverse selection

        Realized spread = 2 × (Trade Price - Mid Price After) × side
        where side = 1 for sells, -1 for buys
        """
        sign = 1 if side == 'sell' else -1
        return 2 * (trade_price - mid_price_after) * sign

    def quoted_spread_vs_effective(self, trades: list, orderbooks: list) -> dict:
        """
        Compare quoted spread to what traders actually pay

        If effective >> quoted, there's hidden liquidity issues
        """
        quoted_spreads = []
        effective_spreads = []

        for trade, ob in zip(trades, orderbooks):
            quoted = self.calculate_spread(ob)['relative_spread_bps']
            mid = (ob['bids'][0][0] + ob['asks'][0][0]) / 2
            effective = self.effective_spread(trade['price'], trade['side'], mid) / mid * 10000

            quoted_spreads.append(quoted)
            effective_spreads.append(effective)

        return {
            'avg_quoted_spread_bps': np.mean(quoted_spreads),
            'avg_effective_spread_bps': np.mean(effective_spreads),
            'spread_ratio': np.mean(effective_spreads) / np.mean(quoted_spreads)
        }
```

---

## Price Formation

### How Prices Move

```python
class PriceFormation:
    """
    Understand how prices are determined
    """

    def calculate_weighted_mid_price(self, orderbook: dict) -> float:
        """
        Weighted mid price - better estimate of "fair" price

        Weighted by volume at best bid/ask
        """
        best_bid, bid_vol = orderbook['bids'][0]
        best_ask, ask_vol = orderbook['asks'][0]

        # Volume-weighted mid
        weighted_mid = (best_bid * ask_vol + best_ask * bid_vol) / (bid_vol + ask_vol)

        return weighted_mid

    def micro_price(self, orderbook: dict, levels: int = 5) -> float:
        """
        Micro price - considers multiple levels of order book

        Better predictor of short-term price direction
        """
        bid_pressure = sum(
            price * volume for price, volume in orderbook['bids'][:levels]
        )
        ask_pressure = sum(
            price * volume for price, volume in orderbook['asks'][:levels]
        )

        total_pressure = bid_pressure + ask_pressure
        if total_pressure == 0:
            return (orderbook['bids'][0][0] + orderbook['asks'][0][0]) / 2

        # More bid pressure = price likely to go up
        bid_weight = bid_pressure / total_pressure
        ask_weight = ask_pressure / total_pressure

        micro_price = (
            orderbook['asks'][0][0] * bid_weight +
            orderbook['bids'][0][0] * ask_weight
        )

        return micro_price

    def price_impact_estimation(self, orderbook: dict, order_size: float,
                                 side: str) -> dict:
        """
        Estimate price impact of an order

        Walks through the order book to see where you'd fill
        """
        remaining = order_size
        total_cost = 0
        levels_consumed = 0

        if side == 'buy':
            levels = orderbook['asks']
        else:
            levels = orderbook['bids']

        for price, volume in levels:
            if remaining <= 0:
                break

            fill_amount = min(remaining, volume)
            total_cost += fill_amount * price
            remaining -= fill_amount
            levels_consumed += 1

        if order_size == remaining:
            return {'error': 'Insufficient liquidity'}

        filled_amount = order_size - remaining
        avg_price = total_cost / filled_amount
        best_price = levels[0][0]

        impact = abs(avg_price - best_price) / best_price

        return {
            'avg_fill_price': avg_price,
            'best_price': best_price,
            'price_impact': impact,
            'price_impact_bps': impact * 10000,
            'levels_consumed': levels_consumed,
            'fully_filled': remaining == 0
        }
```

### Adverse Selection

```python
class AdverseSelection:
    """
    Understand adverse selection - trading against informed traders

    When you provide liquidity, you risk trading with someone
    who knows more than you
    """

    def calculate_adverse_selection(self, trades: list,
                                     future_prices: list) -> dict:
        """
        Measure adverse selection by looking at price movement
        after your trades

        If price moves against you after trading,
        you're experiencing adverse selection
        """
        adverse_selection_costs = []

        for i, trade in enumerate(trades):
            if i + 10 >= len(future_prices):
                break

            entry_price = trade['price']
            future_price = future_prices[i + 10]  # Price 10 periods later

            if trade['side'] == 'buy':
                # Bought, hope price goes up
                pnl = future_price - entry_price
            else:
                # Sold, hope price goes down
                pnl = entry_price - future_price

            adverse_selection_costs.append(-pnl if pnl < 0 else 0)

        return {
            'total_adverse_selection': sum(adverse_selection_costs),
            'avg_per_trade': np.mean(adverse_selection_costs),
            'trades_with_adverse_selection': sum(1 for c in adverse_selection_costs if c > 0),
            'percentage_adverse': sum(1 for c in adverse_selection_costs if c > 0) / len(adverse_selection_costs)
        }

    def toxicity_flow_indicator(self, trades: list, volumes: list,
                                 prices: list) -> float:
        """
        VPIN (Volume-synchronized Probability of Informed Trading)

        High VPIN = more toxic/informed flow
        """
        # Classify trades as buy or sell
        buy_volume = 0
        sell_volume = 0

        for trade in trades:
            if trade['side'] == 'buy':
                buy_volume += trade['volume']
            else:
                sell_volume += trade['volume']

        total_volume = buy_volume + sell_volume
        if total_volume == 0:
            return 0

        # Order imbalance
        imbalance = abs(buy_volume - sell_volume)
        vpin = imbalance / total_volume

        return vpin
```

---

## Liquidity Analysis

### Measuring Liquidity

```python
class LiquidityAnalyzer:
    """
    Comprehensive liquidity analysis
    """

    def __init__(self):
        pass

    def kyle_lambda(self, price_changes: list, volume_imbalances: list) -> float:
        """
        Kyle's Lambda - price impact per unit of order flow

        Higher lambda = less liquid market

        Price Change = λ × Order Flow Imbalance
        """
        from sklearn.linear_model import LinearRegression

        X = np.array(volume_imbalances).reshape(-1, 1)
        y = np.array(price_changes)

        model = LinearRegression()
        model.fit(X, y)

        return model.coef_[0]  # Lambda

    def amihud_illiquidity(self, returns: pd.Series,
                           volumes: pd.Series) -> pd.Series:
        """
        Amihud Illiquidity Ratio

        ILLIQ = |Return| / Dollar Volume

        Higher = less liquid
        """
        return returns.abs() / volumes

    def depth_at_levels(self, orderbook: dict,
                        price_levels: list = [0.001, 0.005, 0.01]) -> dict:
        """
        Measure liquidity at various price levels from mid

        How much can you trade within X% of mid price?
        """
        mid = (orderbook['bids'][0][0] + orderbook['asks'][0][0]) / 2
        depth = {}

        for level in price_levels:
            bid_depth = sum(
                vol for price, vol in orderbook['bids']
                if price >= mid * (1 - level)
            )
            ask_depth = sum(
                vol for price, vol in orderbook['asks']
                if price <= mid * (1 + level)
            )

            depth[f'{level*100:.1f}%'] = {
                'bid_depth': bid_depth,
                'ask_depth': ask_depth,
                'total_depth': bid_depth + ask_depth
            }

        return depth

    def resilience(self, orderbook_before: dict, orderbook_after: dict,
                   time_elapsed: float) -> dict:
        """
        Measure market resilience - how fast liquidity recovers

        After a large trade, how quickly does the book refill?
        """
        depth_before = self._total_depth(orderbook_before, 5)
        depth_after = self._total_depth(orderbook_after, 5)

        recovery = depth_after / depth_before if depth_before > 0 else 0
        recovery_rate = (1 - recovery) / time_elapsed if time_elapsed > 0 else 0

        return {
            'depth_before': depth_before,
            'depth_after': depth_after,
            'recovery_ratio': recovery,
            'recovery_rate_per_second': recovery_rate
        }

    def _total_depth(self, orderbook: dict, levels: int) -> float:
        bid_depth = sum(vol for _, vol in orderbook['bids'][:levels])
        ask_depth = sum(vol for _, vol in orderbook['asks'][:levels])
        return bid_depth + ask_depth
```

---

## Latency and Execution

### Understanding Latency

```
Trading Latency Components:

┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   Signal    │───▶│   Decision  │───▶│   Network   │───▶│  Exchange   │
│  Detection  │    │   Making    │    │   Transit   │    │  Matching   │
│   (1-10ms)  │    │   (1-5ms)   │    │  (10-50ms)  │    │   (1-2ms)   │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘

Total: 15-70ms (retail)
HFT firms: <1ms total
```

```python
class LatencyAnalyzer:
    """
    Measure and optimize execution latency
    """

    def __init__(self):
        self.latency_log = []

    def measure_round_trip(self, exchange) -> dict:
        """Measure round-trip latency to exchange"""
        import time

        measurements = []

        for _ in range(10):
            start = time.perf_counter()
            try:
                exchange.fetch_ticker('BTC/USDT')
            except:
                pass
            end = time.perf_counter()

            measurements.append((end - start) * 1000)  # ms
            time.sleep(0.1)

        return {
            'avg_latency_ms': np.mean(measurements),
            'min_latency_ms': np.min(measurements),
            'max_latency_ms': np.max(measurements),
            'std_latency_ms': np.std(measurements)
        }

    def analyze_fill_latency(self, orders: list) -> dict:
        """
        Analyze time from order submission to fill
        """
        fill_latencies = []

        for order in orders:
            if order.get('timestamp') and order.get('lastTradeTimestamp'):
                latency = order['lastTradeTimestamp'] - order['timestamp']
                fill_latencies.append(latency)

        if not fill_latencies:
            return {}

        return {
            'avg_fill_latency_ms': np.mean(fill_latencies),
            'median_fill_latency_ms': np.median(fill_latencies),
            'p95_fill_latency_ms': np.percentile(fill_latencies, 95),
            'p99_fill_latency_ms': np.percentile(fill_latencies, 99)
        }

    def latency_vs_slippage(self, orders: list, expected_prices: list) -> dict:
        """
        Analyze relationship between latency and slippage
        """
        latencies = []
        slippages = []

        for order, expected in zip(orders, expected_prices):
            if order.get('timestamp') and order.get('lastTradeTimestamp'):
                latency = order['lastTradeTimestamp'] - order['timestamp']
                actual = order.get('average', order.get('price'))

                if actual and expected:
                    slippage = abs(actual - expected) / expected
                    latencies.append(latency)
                    slippages.append(slippage)

        if not latencies:
            return {}

        # Correlation
        correlation = np.corrcoef(latencies, slippages)[0, 1]

        return {
            'latency_slippage_correlation': correlation,
            'avg_latency': np.mean(latencies),
            'avg_slippage_bps': np.mean(slippages) * 10000
        }
```

---

## Market Making Economics

### Understanding Market Maker P&L

```python
class MarketMakerEconomics:
    """
    Understand market making profitability
    """

    def calculate_theoretical_pnl(self, spread_bps: float,
                                   volume_traded: float,
                                   adverse_selection_bps: float,
                                   inventory_cost_bps: float) -> dict:
        """
        Theoretical market maker P&L

        Profit = Spread Earned - Adverse Selection - Inventory Cost

        spread_bps: Half-spread you capture
        adverse_selection_bps: Loss to informed traders
        inventory_cost_bps: Cost of holding inventory
        """
        gross_profit = spread_bps * volume_traded / 10000
        adverse_cost = adverse_selection_bps * volume_traded / 10000
        inventory_cost = inventory_cost_bps * volume_traded / 10000

        net_profit = gross_profit - adverse_cost - inventory_cost

        return {
            'gross_profit': gross_profit,
            'adverse_selection_cost': adverse_cost,
            'inventory_cost': inventory_cost,
            'net_profit': net_profit,
            'profit_margin_bps': (net_profit / volume_traded) * 10000 if volume_traded > 0 else 0
        }

    def optimal_spread(self, volatility: float, inventory_risk_aversion: float,
                       order_arrival_rate: float) -> float:
        """
        Avellaneda-Stoikov optimal spread

        Based on market making theory
        """
        # Simplified A-S spread
        optimal = volatility * np.sqrt(inventory_risk_aversion / order_arrival_rate)
        return optimal

    def inventory_skew(self, current_inventory: float,
                       target_inventory: float,
                       skew_factor: float) -> float:
        """
        Calculate quote skew based on inventory

        If long inventory, lower asks to attract sells
        If short inventory, raise bids to attract buys
        """
        inventory_imbalance = current_inventory - target_inventory
        skew = inventory_imbalance * skew_factor

        return skew
```

---

## Flash Crashes and Extreme Events

```python
class ExtremeEventAnalyzer:
    """
    Analyze and prepare for flash crashes
    """

    def detect_flash_crash(self, prices: pd.Series, threshold: float = 0.05,
                           window: int = 5) -> list:
        """
        Detect flash crash events

        Flash crash: Rapid price decline followed by recovery
        """
        events = []

        for i in range(window, len(prices) - window):
            # Check for sudden drop
            recent_max = prices.iloc[i-window:i].max()
            current = prices.iloc[i]
            drop = (recent_max - current) / recent_max

            if drop > threshold:
                # Check for recovery
                future_max = prices.iloc[i:i+window].max()
                recovery = (future_max - current) / current

                if recovery > threshold * 0.5:  # 50% recovery
                    events.append({
                        'index': i,
                        'time': prices.index[i],
                        'drop_pct': drop,
                        'recovery_pct': recovery,
                        'duration_bars': window
                    })

        return events

    def circuit_breaker_simulation(self, prices: pd.Series,
                                    halt_threshold: float = 0.07,
                                    halt_duration: int = 5) -> dict:
        """
        Simulate effect of circuit breakers

        If price drops more than threshold, trading halts
        """
        returns = prices.pct_change()
        halts = 0
        total_halt_bars = 0
        halt_active = 0

        for ret in returns:
            if halt_active > 0:
                halt_active -= 1
                continue

            if abs(ret) > halt_threshold:
                halts += 1
                halt_active = halt_duration
                total_halt_bars += halt_duration

        return {
            'num_halts': halts,
            'total_halt_bars': total_halt_bars,
            'percentage_halted': total_halt_bars / len(prices) * 100
        }

    def tail_risk_metrics(self, returns: pd.Series) -> dict:
        """
        Comprehensive tail risk analysis
        """
        return {
            'skewness': stats.skew(returns),
            'kurtosis': stats.kurtosis(returns),  # Excess kurtosis
            'max_drawdown': (returns.cumsum().cummax() - returns.cumsum()).max(),
            'largest_loss': returns.min(),
            'largest_gain': returns.max(),
            'var_99': np.percentile(returns, 1),
            'var_999': np.percentile(returns, 0.1),
            'expected_shortfall_99': returns[returns <= np.percentile(returns, 1)].mean()
        }
```

---

## Practical Applications

### Execution Quality Analysis

```python
class ExecutionQualityAnalysis:
    """
    Analyze your trading execution quality
    """

    def __init__(self, trades: list, market_data: pd.DataFrame):
        self.trades = trades
        self.market_data = market_data

    def transaction_cost_analysis(self) -> dict:
        """
        Full transaction cost analysis (TCA)
        """
        results = []

        for trade in self.trades:
            timestamp = trade['timestamp']
            symbol = trade['symbol']

            # Find market conditions at trade time
            market_slice = self.market_data[
                self.market_data.index <= timestamp
            ].iloc[-1]

            # Benchmark prices
            arrival_price = market_slice['close']
            vwap = self._calculate_vwap_around(timestamp, symbol)

            # Actual execution
            exec_price = trade['price']
            side_sign = 1 if trade['side'] == 'buy' else -1

            # Calculate costs
            results.append({
                'arrival_cost': (exec_price - arrival_price) * side_sign / arrival_price * 10000,
                'vwap_cost': (exec_price - vwap) * side_sign / vwap * 10000,
                'spread_cost': market_slice.get('spread', 0) / 2 * 10000,
                'market_impact': self._estimate_impact(trade, market_slice)
            })

        return {
            'avg_arrival_cost_bps': np.mean([r['arrival_cost'] for r in results]),
            'avg_vwap_cost_bps': np.mean([r['vwap_cost'] for r in results]),
            'avg_spread_cost_bps': np.mean([r['spread_cost'] for r in results]),
            'total_trades': len(results),
            'detail': results
        }

    def _calculate_vwap_around(self, timestamp, symbol, window_minutes=30):
        """Calculate VWAP around trade time"""
        start = timestamp - pd.Timedelta(minutes=window_minutes)
        end = timestamp + pd.Timedelta(minutes=window_minutes)

        slice_df = self.market_data[
            (self.market_data.index >= start) &
            (self.market_data.index <= end)
        ]

        if len(slice_df) == 0:
            return self.market_data.iloc[-1]['close']

        vwap = (slice_df['close'] * slice_df['volume']).sum() / slice_df['volume'].sum()
        return vwap

    def _estimate_impact(self, trade, market_slice):
        """Estimate market impact"""
        size_ratio = trade['amount'] / market_slice.get('volume', trade['amount'])
        volatility = market_slice.get('volatility', 0.02)

        # Square root impact model
        impact = volatility * np.sqrt(size_ratio) * 10000  # bps
        return impact
```

---

## Summary

Market microstructure knowledge helps you:

1. **Understand price formation** - How your orders affect prices
2. **Measure execution quality** - Are you getting good fills?
3. **Avoid adverse selection** - Don't trade against informed flow
4. **Optimize order types** - Use the right tool for each situation
5. **Manage latency** - Speed matters, especially for HFT
6. **Prepare for extremes** - Flash crashes do happen

Key takeaways for prop firm trading:
- Use limit orders when possible to avoid spread costs
- Monitor your execution quality with TCA
- Be aware of liquidity when sizing positions
- Have circuit breakers for extreme events

---

*Next: [17-performance-attribution.md](./17-performance-attribution.md) - Analyzing what's driving your returns*
