# 07 - Exchange Integration

> **Connecting your trading bot to cryptocurrency exchanges**

---

## Overview

Exchange integration is where your strategy meets the real market. This document covers how to connect to exchanges, handle authentication, execute orders, and manage the various challenges of live trading.

---

## Using CCXT

CCXT (CryptoCurrency eXchange Trading) is the standard library for exchange connectivity, supporting 100+ exchanges with a unified API.

### Installation

```bash
pip install ccxt
# For async/WebSocket support:
pip install ccxt[async]
# or
pip install ccxt-pro  # Professional version with WebSockets
```

### Basic Connection

```python
import ccxt

# Initialize exchange
exchange = ccxt.binance({
    'apiKey': 'YOUR_API_KEY',
    'secret': 'YOUR_SECRET',
    'enableRateLimit': True,  # Respect rate limits
    'options': {
        'defaultType': 'future',  # For futures trading
    }
})

# For testnet/sandbox
exchange.set_sandbox_mode(True)

# Check connection
try:
    balance = exchange.fetch_balance()
    print(f"Connected! USDT Balance: {balance['USDT']['free']}")
except ccxt.AuthenticationError:
    print("Invalid API credentials")
except ccxt.NetworkError as e:
    print(f"Network error: {e}")
```

### Supported Exchanges for Crypto Prop Firms

| Exchange | Spot | Futures | WebSocket | Notes |
|----------|------|---------|-----------|-------|
| Binance | ✅ | ✅ | ✅ | Most liquid |
| Bybit | ✅ | ✅ | ✅ | Popular for futures |
| OKX | ✅ | ✅ | ✅ | Good derivatives |
| Bitget | ✅ | ✅ | ✅ | Growing platform |

---

## Exchange Connector Class

### Complete Implementation

```python
import ccxt.pro as ccxtpro
import ccxt
import asyncio
from typing import Dict, Optional, List
from datetime import datetime
import logging

class ExchangeConnector:
    """
    Unified exchange connector with error handling and retry logic
    """

    def __init__(self, exchange_id: str, config: Dict):
        self.exchange_id = exchange_id
        self.config = config
        self.logger = logging.getLogger(__name__)

        # Initialize exchange
        exchange_class = getattr(ccxtpro, exchange_id, None)
        if not exchange_class:
            exchange_class = getattr(ccxt, exchange_id)

        self.exchange = exchange_class({
            'apiKey': config.get('api_key'),
            'secret': config.get('secret'),
            'password': config.get('password'),  # For exchanges that need it
            'enableRateLimit': True,
            'options': {
                'defaultType': config.get('market_type', 'spot'),
            }
        })

        # Use testnet if configured
        if config.get('testnet', False):
            self.exchange.set_sandbox_mode(True)

        # Connection state
        self.connected = False
        self.last_heartbeat = None

    async def connect(self):
        """Establish connection and verify credentials"""
        try:
            # Test authentication
            balance = await self.exchange.fetch_balance()
            self.connected = True
            self.last_heartbeat = datetime.now()
            self.logger.info(f"Connected to {self.exchange_id}")
            return True
        except ccxt.AuthenticationError as e:
            self.logger.error(f"Authentication failed: {e}")
            raise
        except ccxt.NetworkError as e:
            self.logger.error(f"Network error: {e}")
            raise

    async def disconnect(self):
        """Close connection"""
        await self.exchange.close()
        self.connected = False

    # ==================== Market Data ====================

    async def fetch_ticker(self, symbol: str) -> Dict:
        """Get current price info"""
        return await self._execute_with_retry(
            self.exchange.fetch_ticker, symbol
        )

    async def fetch_ohlcv(self, symbol: str, timeframe: str = '1h',
                          limit: int = 100) -> List:
        """Fetch candlestick data"""
        return await self._execute_with_retry(
            self.exchange.fetch_ohlcv, symbol, timeframe, limit=limit
        )

    async def fetch_orderbook(self, symbol: str, limit: int = 20) -> Dict:
        """Fetch order book"""
        return await self._execute_with_retry(
            self.exchange.fetch_order_book, symbol, limit
        )

    # ==================== Account ====================

    async def fetch_balance(self) -> Dict:
        """Fetch account balance"""
        return await self._execute_with_retry(
            self.exchange.fetch_balance
        )

    async def fetch_positions(self, symbols: List[str] = None) -> List:
        """Fetch open positions (futures)"""
        return await self._execute_with_retry(
            self.exchange.fetch_positions, symbols
        )

    # ==================== Orders ====================

    async def create_market_order(self, symbol: str, side: str, amount: float,
                                   params: Dict = None) -> Dict:
        """Create market order"""
        return await self._execute_with_retry(
            self.exchange.create_order,
            symbol, 'market', side, amount, None, params or {}
        )

    async def create_limit_order(self, symbol: str, side: str, amount: float,
                                  price: float, params: Dict = None) -> Dict:
        """Create limit order"""
        return await self._execute_with_retry(
            self.exchange.create_order,
            symbol, 'limit', side, amount, price, params or {}
        )

    async def create_order_with_sl_tp(self, symbol: str, side: str, amount: float,
                                       entry_price: float, stop_loss: float,
                                       take_profit: float, order_type: str = 'limit') -> Dict:
        """
        Create order with stop loss and take profit

        Different exchanges handle this differently
        """
        params = {}

        # Binance Futures style
        if self.exchange_id == 'binance':
            # Main order
            order = await self.create_limit_order(symbol, side, amount, entry_price)

            # Stop loss order
            sl_side = 'sell' if side == 'buy' else 'buy'
            await self.exchange.create_order(
                symbol, 'STOP_MARKET', sl_side, amount, None,
                {'stopPrice': stop_loss, 'reduceOnly': True}
            )

            # Take profit order
            await self.exchange.create_order(
                symbol, 'TAKE_PROFIT_MARKET', sl_side, amount, None,
                {'stopPrice': take_profit, 'reduceOnly': True}
            )

            return order

        # Bybit style (supports bracket orders)
        elif self.exchange_id == 'bybit':
            params = {
                'stopLoss': {'triggerPrice': stop_loss},
                'takeProfit': {'triggerPrice': take_profit},
            }
            return await self.exchange.create_order(
                symbol, order_type, side, amount, entry_price, params
            )

        else:
            # Fallback: separate orders
            order = await self.create_limit_order(symbol, side, amount, entry_price)
            # Create separate SL/TP orders
            return order

    async def cancel_order(self, order_id: str, symbol: str) -> Dict:
        """Cancel an order"""
        return await self._execute_with_retry(
            self.exchange.cancel_order, order_id, symbol
        )

    async def cancel_all_orders(self, symbol: str = None) -> List:
        """Cancel all open orders"""
        return await self._execute_with_retry(
            self.exchange.cancel_all_orders, symbol
        )

    async def fetch_order(self, order_id: str, symbol: str) -> Dict:
        """Fetch order status"""
        return await self._execute_with_retry(
            self.exchange.fetch_order, order_id, symbol
        )

    async def fetch_open_orders(self, symbol: str = None) -> List:
        """Fetch all open orders"""
        return await self._execute_with_retry(
            self.exchange.fetch_open_orders, symbol
        )

    # ==================== Leverage & Margin ====================

    async def set_leverage(self, symbol: str, leverage: int) -> Dict:
        """Set leverage for futures trading"""
        return await self._execute_with_retry(
            self.exchange.set_leverage, leverage, symbol
        )

    async def set_margin_mode(self, symbol: str, mode: str = 'cross') -> Dict:
        """Set margin mode (cross/isolated)"""
        return await self._execute_with_retry(
            self.exchange.set_margin_mode, mode, symbol
        )

    # ==================== WebSocket Streams ====================

    async def watch_ticker(self, symbol: str):
        """Subscribe to ticker updates"""
        while True:
            try:
                ticker = await self.exchange.watch_ticker(symbol)
                yield ticker
            except Exception as e:
                self.logger.error(f"Ticker stream error: {e}")
                await asyncio.sleep(5)

    async def watch_ohlcv(self, symbol: str, timeframe: str = '1m'):
        """Subscribe to OHLCV updates"""
        while True:
            try:
                ohlcv = await self.exchange.watch_ohlcv(symbol, timeframe)
                yield ohlcv
            except Exception as e:
                self.logger.error(f"OHLCV stream error: {e}")
                await asyncio.sleep(5)

    async def watch_orders(self, symbol: str = None):
        """Subscribe to order updates"""
        while True:
            try:
                orders = await self.exchange.watch_orders(symbol)
                yield orders
            except Exception as e:
                self.logger.error(f"Order stream error: {e}")
                await asyncio.sleep(5)

    # ==================== Utility Methods ====================

    async def _execute_with_retry(self, func, *args, max_retries: int = 3, **kwargs):
        """Execute function with retry logic"""
        last_error = None

        for attempt in range(max_retries):
            try:
                result = await func(*args, **kwargs)
                return result

            except ccxt.RateLimitExceeded:
                wait_time = 2 ** attempt
                self.logger.warning(f"Rate limit hit, waiting {wait_time}s")
                await asyncio.sleep(wait_time)

            except ccxt.NetworkError as e:
                last_error = e
                wait_time = 2 ** attempt
                self.logger.warning(f"Network error, retry {attempt + 1}: {e}")
                await asyncio.sleep(wait_time)

            except ccxt.ExchangeError as e:
                # Don't retry exchange errors (usually our fault)
                self.logger.error(f"Exchange error: {e}")
                raise

        raise last_error or Exception("Max retries exceeded")

    def get_min_order_size(self, symbol: str) -> float:
        """Get minimum order size for symbol"""
        markets = self.exchange.load_markets()
        if symbol in markets:
            return markets[symbol]['limits']['amount']['min']
        return 0

    def get_price_precision(self, symbol: str) -> int:
        """Get price precision for symbol"""
        markets = self.exchange.load_markets()
        if symbol in markets:
            return markets[symbol]['precision']['price']
        return 8

    def round_price(self, price: float, symbol: str) -> float:
        """Round price to exchange precision"""
        precision = self.get_price_precision(symbol)
        return round(price, precision)
```

---

## Order Types

### Market Orders

```python
# Simple market buy
order = await exchange.create_market_order('BTC/USDT', 'buy', 0.001)

# Market sell
order = await exchange.create_market_order('BTC/USDT', 'sell', 0.001)
```

### Limit Orders

```python
# Limit buy at specific price
order = await exchange.create_limit_order('BTC/USDT', 'buy', 0.001, 50000.0)

# Post-only (maker only)
order = await exchange.create_order(
    'BTC/USDT', 'limit', 'buy', 0.001, 50000.0,
    {'postOnly': True}
)
```

### Stop Orders

```python
# Stop loss (market)
order = await exchange.create_order(
    'BTC/USDT', 'STOP_MARKET', 'sell', 0.001, None,
    {'stopPrice': 49000.0, 'reduceOnly': True}
)

# Stop loss (limit)
order = await exchange.create_order(
    'BTC/USDT', 'STOP', 'sell', 0.001, 48900.0,
    {'stopPrice': 49000.0, 'reduceOnly': True}
)

# Take profit
order = await exchange.create_order(
    'BTC/USDT', 'TAKE_PROFIT_MARKET', 'sell', 0.001, None,
    {'stopPrice': 52000.0, 'reduceOnly': True}
)
```

---

## Error Handling

### Common Errors

```python
import ccxt

async def safe_order_execution(exchange, symbol, side, amount, price=None):
    """Execute order with comprehensive error handling"""
    try:
        if price:
            order = await exchange.create_limit_order(symbol, side, amount, price)
        else:
            order = await exchange.create_market_order(symbol, side, amount)
        return order, None

    except ccxt.InsufficientFunds as e:
        return None, f"Insufficient funds: {e}"

    except ccxt.InvalidOrder as e:
        return None, f"Invalid order: {e}"

    except ccxt.OrderNotFound as e:
        return None, f"Order not found: {e}"

    except ccxt.RateLimitExceeded as e:
        return None, f"Rate limit exceeded: {e}"

    except ccxt.NetworkError as e:
        return None, f"Network error: {e}"

    except ccxt.ExchangeError as e:
        return None, f"Exchange error: {e}"

    except Exception as e:
        return None, f"Unexpected error: {e}"
```

### Order State Machine

```python
from enum import Enum

class OrderState(Enum):
    PENDING = "pending"      # Created but not sent
    SUBMITTED = "submitted"  # Sent to exchange
    OPEN = "open"           # On the order book
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELED = "canceled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    FAILED = "failed"


class OrderManager:
    """Manage order lifecycle"""

    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        self.orders = {}  # order_id -> order_info

    async def submit_order(self, order_request):
        """Submit and track order"""
        order_id = self._generate_id()

        self.orders[order_id] = {
            'state': OrderState.PENDING,
            'request': order_request,
            'exchange_order': None,
            'fills': [],
            'created_at': datetime.now(),
        }

        try:
            # Submit to exchange
            result = await self.exchange.create_limit_order(
                order_request['symbol'],
                order_request['side'],
                order_request['amount'],
                order_request['price']
            )

            self.orders[order_id]['state'] = OrderState.SUBMITTED
            self.orders[order_id]['exchange_order'] = result
            self.orders[order_id]['exchange_id'] = result['id']

            return order_id, result

        except Exception as e:
            self.orders[order_id]['state'] = OrderState.FAILED
            self.orders[order_id]['error'] = str(e)
            return order_id, None

    async def check_order_status(self, order_id):
        """Update order status from exchange"""
        order_info = self.orders.get(order_id)
        if not order_info or not order_info.get('exchange_id'):
            return None

        try:
            status = await self.exchange.fetch_order(
                order_info['exchange_id'],
                order_info['request']['symbol']
            )

            # Update state based on exchange status
            exchange_status = status['status']
            if exchange_status == 'open':
                self.orders[order_id]['state'] = OrderState.OPEN
            elif exchange_status == 'closed':
                self.orders[order_id]['state'] = OrderState.FILLED
            elif exchange_status == 'canceled':
                self.orders[order_id]['state'] = OrderState.CANCELED

            self.orders[order_id]['exchange_order'] = status
            return status

        except Exception as e:
            return None
```

---

## Rate Limiting

### Respecting Rate Limits

```python
import time
from collections import deque

class RateLimiter:
    """Token bucket rate limiter"""

    def __init__(self, requests_per_second=10, requests_per_minute=1200):
        self.rps = requests_per_second
        self.rpm = requests_per_minute
        self.request_times = deque()

    async def acquire(self):
        """Wait if necessary to respect rate limits"""
        now = time.time()

        # Clean old requests
        while self.request_times and self.request_times[0] < now - 60:
            self.request_times.popleft()

        # Check per-minute limit
        if len(self.request_times) >= self.rpm:
            wait_time = 60 - (now - self.request_times[0])
            if wait_time > 0:
                await asyncio.sleep(wait_time)

        # Check per-second limit
        recent_requests = sum(1 for t in self.request_times if t > now - 1)
        if recent_requests >= self.rps:
            await asyncio.sleep(1.0 / self.rps)

        self.request_times.append(time.time())
```

---

## Testing & Sandboxes

### Using Testnets

```python
# Binance Testnet
exchange = ccxt.binance({
    'apiKey': 'testnet_api_key',
    'secret': 'testnet_secret',
})
exchange.set_sandbox_mode(True)

# Bybit Testnet
exchange = ccxt.bybit({
    'apiKey': 'testnet_api_key',
    'secret': 'testnet_secret',
})
exchange.set_sandbox_mode(True)
```

### Paper Trading Mode

```python
class PaperTradingExchange:
    """Simulated exchange for testing"""

    def __init__(self, initial_balance=100000):
        self.balance = {'USDT': initial_balance}
        self.positions = {}
        self.orders = []
        self.order_id_counter = 1

    async def create_market_order(self, symbol, side, amount):
        """Simulate market order"""
        # Get "market price" (would need real feed)
        price = self._get_mock_price(symbol)

        order = {
            'id': str(self.order_id_counter),
            'symbol': symbol,
            'side': side,
            'type': 'market',
            'amount': amount,
            'price': price,
            'status': 'closed',
            'filled': amount,
            'timestamp': time.time()
        }
        self.order_id_counter += 1

        # Update balances
        self._process_fill(order)
        self.orders.append(order)

        return order

    def _process_fill(self, order):
        """Update balances based on fill"""
        base, quote = order['symbol'].split('/')
        value = order['amount'] * order['price']

        if order['side'] == 'buy':
            self.balance[quote] = self.balance.get(quote, 0) - value
            self.balance[base] = self.balance.get(base, 0) + order['amount']
        else:
            self.balance[quote] = self.balance.get(quote, 0) + value
            self.balance[base] = self.balance.get(base, 0) - order['amount']
```

---

## Best Practices

1. **Always use testnet first** - Never test with real money
2. **Implement retries** - Network issues are common
3. **Handle all error types** - Each needs different handling
4. **Track orders locally** - Don't rely only on exchange
5. **Use WebSockets** - Lower latency than polling
6. **Respect rate limits** - Or get banned
7. **Log everything** - You'll need it for debugging
8. **Verify balances** - Before and after trades

---

*Next: [08-deployment.md](./08-deployment.md) - Running in production*
