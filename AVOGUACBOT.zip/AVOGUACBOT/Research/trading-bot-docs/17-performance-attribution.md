# 17 - Performance Attribution

> **Understanding what drives your returns and where to improve**

---

## Overview

Performance attribution answers the question: "Why did I make (or lose) money?" Understanding the sources of returns helps you improve strategies and avoid false confidence.

---

## Return Decomposition

### Basic P&L Attribution

```python
import pandas as pd
import numpy as np
from typing import Dict, List
from dataclasses import dataclass

@dataclass
class TradeAttribution:
    """Attribution for a single trade"""
    trade_id: str
    symbol: str
    pnl: float
    pnl_pct: float
    direction: str
    entry_price: float
    exit_price: float
    duration: float
    market_return: float
    alpha: float
    timing_contribution: float
    selection_contribution: float


class PerformanceAttribution:
    """
    Comprehensive performance attribution analysis
    """

    def __init__(self, trades: List[Dict], market_data: pd.DataFrame):
        self.trades = trades
        self.market = market_data

    def basic_attribution(self) -> Dict:
        """
        Basic P&L breakdown
        """
        total_pnl = sum(t['pnl'] for t in self.trades)

        # By direction
        long_pnl = sum(t['pnl'] for t in self.trades if t['direction'] == 'long')
        short_pnl = sum(t['pnl'] for t in self.trades if t['direction'] == 'short')

        # By symbol
        symbol_pnl = {}
        for t in self.trades:
            symbol_pnl[t['symbol']] = symbol_pnl.get(t['symbol'], 0) + t['pnl']

        # By time of day
        hour_pnl = {}
        for t in self.trades:
            hour = t.get('entry_time', pd.Timestamp.now()).hour
            hour_bucket = f"{hour:02d}:00-{(hour+4)%24:02d}:00"
            hour_pnl[hour_bucket] = hour_pnl.get(hour_bucket, 0) + t['pnl']

        # Winners vs losers
        winners = [t for t in self.trades if t['pnl'] > 0]
        losers = [t for t in self.trades if t['pnl'] <= 0]

        return {
            'total_pnl': total_pnl,
            'long_pnl': long_pnl,
            'short_pnl': short_pnl,
            'long_contribution': long_pnl / total_pnl if total_pnl != 0 else 0,
            'short_contribution': short_pnl / total_pnl if total_pnl != 0 else 0,
            'by_symbol': symbol_pnl,
            'by_time': hour_pnl,
            'winner_pnl': sum(t['pnl'] for t in winners),
            'loser_pnl': sum(t['pnl'] for t in losers),
            'num_winners': len(winners),
            'num_losers': len(losers),
            'win_rate': len(winners) / len(self.trades) if self.trades else 0
        }

    def alpha_beta_decomposition(self, benchmark_returns: pd.Series) -> Dict:
        """
        Decompose returns into alpha and beta components

        Return = Alpha + Beta × Market Return + Error
        """
        from sklearn.linear_model import LinearRegression

        # Calculate strategy returns
        strategy_returns = self._calculate_strategy_returns()

        # Align timestamps
        common_idx = strategy_returns.index.intersection(benchmark_returns.index)
        strat = strategy_returns.loc[common_idx]
        bench = benchmark_returns.loc[common_idx]

        if len(strat) < 10:
            return {'error': 'Insufficient data for regression'}

        # Regression: R_strategy = alpha + beta × R_benchmark
        X = bench.values.reshape(-1, 1)
        y = strat.values

        model = LinearRegression()
        model.fit(X, y)

        alpha_daily = model.intercept_
        beta = model.coef_[0]

        # R-squared
        r_squared = model.score(X, y)

        # Annualize alpha
        alpha_annual = alpha_daily * 252

        # Decompose returns
        total_return = strat.sum()
        market_return = bench.sum()
        beta_contribution = beta * market_return
        alpha_contribution = total_return - beta_contribution

        return {
            'alpha_daily': alpha_daily,
            'alpha_annual': alpha_annual,
            'beta': beta,
            'r_squared': r_squared,
            'total_return': total_return,
            'beta_contribution': beta_contribution,
            'alpha_contribution': alpha_contribution,
            'active_return': alpha_contribution,
            'tracking_error': (strat - beta * bench).std() * np.sqrt(252),
            'information_ratio': alpha_annual / ((strat - beta * bench).std() * np.sqrt(252)) if (strat - beta * bench).std() > 0 else 0
        }

    def _calculate_strategy_returns(self) -> pd.Series:
        """Calculate daily strategy returns from trades"""
        returns = {}

        for trade in self.trades:
            exit_date = trade.get('exit_time', pd.Timestamp.now()).date()
            pnl_pct = trade.get('pnl_pct', 0)

            if exit_date not in returns:
                returns[exit_date] = 0
            returns[exit_date] += pnl_pct

        return pd.Series(returns).sort_index()
```

### Brinson Attribution

```python
class BrinsonAttribution:
    """
    Brinson-Fachler attribution model

    Decomposes returns into:
    - Allocation effect (sector/asset weights)
    - Selection effect (picking winners within sectors)
    - Interaction effect
    """

    def __init__(self, portfolio_weights: Dict, portfolio_returns: Dict,
                 benchmark_weights: Dict, benchmark_returns: Dict):
        """
        Args:
            portfolio_weights: {asset: weight}
            portfolio_returns: {asset: return}
            benchmark_weights: {asset: weight}
            benchmark_returns: {asset: return}
        """
        self.port_w = portfolio_weights
        self.port_r = portfolio_returns
        self.bench_w = benchmark_weights
        self.bench_r = benchmark_returns

        self.assets = set(portfolio_weights.keys()) | set(benchmark_weights.keys())

    def calculate(self) -> Dict:
        """Calculate Brinson attribution"""
        allocation_effect = 0
        selection_effect = 0
        interaction_effect = 0

        # Benchmark total return
        bench_total = sum(
            self.bench_w.get(a, 0) * self.bench_r.get(a, 0)
            for a in self.assets
        )

        for asset in self.assets:
            wp = self.port_w.get(asset, 0)
            wb = self.bench_w.get(asset, 0)
            rp = self.port_r.get(asset, 0)
            rb = self.bench_r.get(asset, 0)

            # Allocation: (Portfolio Weight - Benchmark Weight) × (Benchmark Return - Total Benchmark Return)
            allocation_effect += (wp - wb) * (rb - bench_total)

            # Selection: Benchmark Weight × (Portfolio Return - Benchmark Return)
            selection_effect += wb * (rp - rb)

            # Interaction: (Portfolio Weight - Benchmark Weight) × (Portfolio Return - Benchmark Return)
            interaction_effect += (wp - wb) * (rp - rb)

        # Total active return
        port_total = sum(
            self.port_w.get(a, 0) * self.port_r.get(a, 0)
            for a in self.assets
        )
        active_return = port_total - bench_total

        return {
            'allocation_effect': allocation_effect,
            'selection_effect': selection_effect,
            'interaction_effect': interaction_effect,
            'total_active_return': active_return,
            'verification': allocation_effect + selection_effect + interaction_effect,
            'portfolio_return': port_total,
            'benchmark_return': bench_total
        }

    def by_asset(self) -> pd.DataFrame:
        """Attribution breakdown by asset"""
        results = []

        bench_total = sum(
            self.bench_w.get(a, 0) * self.bench_r.get(a, 0)
            for a in self.assets
        )

        for asset in self.assets:
            wp = self.port_w.get(asset, 0)
            wb = self.bench_w.get(asset, 0)
            rp = self.port_r.get(asset, 0)
            rb = self.bench_r.get(asset, 0)

            results.append({
                'asset': asset,
                'port_weight': wp,
                'bench_weight': wb,
                'port_return': rp,
                'bench_return': rb,
                'allocation': (wp - wb) * (rb - bench_total),
                'selection': wb * (rp - rb),
                'interaction': (wp - wb) * (rp - rb),
                'total_contribution': wp * rp - wb * rb
            })

        return pd.DataFrame(results).set_index('asset')
```

---

## Factor Attribution

### Multi-Factor Model

```python
class FactorAttribution:
    """
    Factor-based performance attribution

    Decompose returns into factor exposures
    """

    def __init__(self, strategy_returns: pd.Series, factor_returns: pd.DataFrame):
        """
        Args:
            strategy_returns: Series of strategy returns
            factor_returns: DataFrame with factors as columns
        """
        self.strategy = strategy_returns
        self.factors = factor_returns

    def calculate_exposures(self) -> Dict:
        """
        Calculate factor exposures using regression
        """
        from sklearn.linear_model import LinearRegression

        # Align data
        common_idx = self.strategy.index.intersection(self.factors.index)
        y = self.strategy.loc[common_idx].values
        X = self.factors.loc[common_idx].values

        model = LinearRegression()
        model.fit(X, y)

        exposures = dict(zip(self.factors.columns, model.coef_))
        exposures['alpha'] = model.intercept_

        # Factor contributions
        factor_contributions = {}
        for i, factor in enumerate(self.factors.columns):
            factor_return = self.factors[factor].loc[common_idx].sum()
            contribution = model.coef_[i] * factor_return
            factor_contributions[factor] = contribution

        return {
            'exposures': exposures,
            'contributions': factor_contributions,
            'alpha_contribution': model.intercept_ * len(common_idx),
            'r_squared': model.score(X, y),
            'residual_return': y.sum() - sum(factor_contributions.values()) - model.intercept_ * len(common_idx)
        }

    def rolling_exposures(self, window: int = 60) -> pd.DataFrame:
        """Calculate rolling factor exposures"""
        from sklearn.linear_model import LinearRegression

        exposures = []
        common_idx = self.strategy.index.intersection(self.factors.index)

        for i in range(window, len(common_idx)):
            idx = common_idx[i-window:i]
            y = self.strategy.loc[idx].values
            X = self.factors.loc[idx].values

            model = LinearRegression()
            model.fit(X, y)

            row = {'date': common_idx[i]}
            for j, factor in enumerate(self.factors.columns):
                row[factor] = model.coef_[j]
            row['alpha'] = model.intercept_

            exposures.append(row)

        return pd.DataFrame(exposures).set_index('date')


class CryptoFactors:
    """
    Common crypto market factors
    """

    @staticmethod
    def calculate_factors(price_data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate crypto-specific factors

        Factors:
        - Market (BTC return)
        - Size (large cap vs small cap)
        - Momentum
        - Volatility
        """
        factors = pd.DataFrame(index=price_data.index)

        # Market factor (BTC return)
        if 'BTC' in price_data.columns:
            factors['market'] = price_data['BTC'].pct_change()

        # Momentum factor (past 20-day return, long winners, short losers)
        momentum = price_data.pct_change(20)
        factors['momentum'] = momentum.mean(axis=1)  # Simplified

        # Volatility factor (low vol outperforms high vol)
        volatility = price_data.pct_change().rolling(20).std()
        factors['low_vol'] = -volatility.mean(axis=1)  # Negative = low vol good

        # Mean reversion factor
        zscore = (price_data - price_data.rolling(20).mean()) / price_data.rolling(20).std()
        factors['mean_reversion'] = -zscore.mean(axis=1)

        return factors.dropna()
```

---

## Trade-Level Analysis

### Individual Trade Attribution

```python
class TradeAnalyzer:
    """
    Deep analysis of individual trades
    """

    def __init__(self, trades: List[Dict], market_data: pd.DataFrame):
        self.trades = trades
        self.market = market_data

    def analyze_trade(self, trade: Dict) -> TradeAttribution:
        """
        Detailed analysis of a single trade
        """
        entry_time = trade['entry_time']
        exit_time = trade['exit_time']
        symbol = trade['symbol']

        # Market return during trade
        market_slice = self.market[
            (self.market.index >= entry_time) &
            (self.market.index <= exit_time)
        ]

        if len(market_slice) > 0:
            market_return = (market_slice['close'].iloc[-1] / market_slice['close'].iloc[0]) - 1
        else:
            market_return = 0

        # Trade return
        trade_return = trade['pnl_pct']

        # Alpha = Trade return - Beta × Market return (assuming beta = 1 for simplicity)
        alpha = trade_return - market_return

        # Timing contribution (did you enter at a good time?)
        timing = self._calculate_timing_contribution(trade, market_slice)

        # Selection contribution (did you pick a good setup?)
        selection = trade_return - timing

        return TradeAttribution(
            trade_id=trade.get('id', ''),
            symbol=symbol,
            pnl=trade['pnl'],
            pnl_pct=trade_return,
            direction=trade['direction'],
            entry_price=trade['entry_price'],
            exit_price=trade['exit_price'],
            duration=(exit_time - entry_time).total_seconds() / 3600,  # hours
            market_return=market_return,
            alpha=alpha,
            timing_contribution=timing,
            selection_contribution=selection
        )

    def _calculate_timing_contribution(self, trade: Dict,
                                        market_slice: pd.DataFrame) -> float:
        """
        Calculate timing contribution

        Compare entry/exit to optimal entry/exit in the period
        """
        if len(market_slice) < 2:
            return 0

        if trade['direction'] == 'long':
            # Optimal: buy at low, sell at high
            optimal_entry = market_slice['low'].min()
            optimal_exit = market_slice['high'].max()
            actual_entry = trade['entry_price']
            actual_exit = trade['exit_price']

            # Entry timing (lower = better for longs)
            entry_quality = (market_slice['close'].iloc[0] - actual_entry) / market_slice['close'].iloc[0]

            # Exit timing (higher = better for longs)
            exit_quality = (actual_exit - market_slice['close'].iloc[-1]) / market_slice['close'].iloc[-1]

            return entry_quality + exit_quality
        else:
            # Short: opposite logic
            entry_quality = (trade['entry_price'] - market_slice['close'].iloc[0]) / market_slice['close'].iloc[0]
            exit_quality = (market_slice['close'].iloc[-1] - trade['exit_price']) / market_slice['close'].iloc[-1]

            return entry_quality + exit_quality

    def trade_quality_metrics(self) -> pd.DataFrame:
        """
        Calculate quality metrics for all trades
        """
        results = []

        for trade in self.trades:
            attr = self.analyze_trade(trade)

            # MAE (Maximum Adverse Excursion)
            mae = self._calculate_mae(trade)

            # MFE (Maximum Favorable Excursion)
            mfe = self._calculate_mfe(trade)

            # Edge ratio = MFE / MAE
            edge_ratio = mfe / mae if mae > 0 else float('inf')

            # Capture ratio = Actual P&L / MFE
            capture_ratio = trade['pnl_pct'] / mfe if mfe > 0 else 0

            results.append({
                'trade_id': attr.trade_id,
                'symbol': attr.symbol,
                'pnl': attr.pnl,
                'pnl_pct': attr.pnl_pct,
                'duration_hours': attr.duration,
                'alpha': attr.alpha,
                'mae': mae,
                'mfe': mfe,
                'edge_ratio': edge_ratio,
                'capture_ratio': capture_ratio,
                'timing_score': attr.timing_contribution
            })

        return pd.DataFrame(results)

    def _calculate_mae(self, trade: Dict) -> float:
        """Maximum Adverse Excursion - worst drawdown during trade"""
        entry_time = trade['entry_time']
        exit_time = trade['exit_time']

        market_slice = self.market[
            (self.market.index >= entry_time) &
            (self.market.index <= exit_time)
        ]

        if len(market_slice) == 0:
            return 0

        entry_price = trade['entry_price']

        if trade['direction'] == 'long':
            worst_price = market_slice['low'].min()
            mae = (entry_price - worst_price) / entry_price
        else:
            worst_price = market_slice['high'].max()
            mae = (worst_price - entry_price) / entry_price

        return max(0, mae)

    def _calculate_mfe(self, trade: Dict) -> float:
        """Maximum Favorable Excursion - best potential during trade"""
        entry_time = trade['entry_time']
        exit_time = trade['exit_time']

        market_slice = self.market[
            (self.market.index >= entry_time) &
            (self.market.index <= exit_time)
        ]

        if len(market_slice) == 0:
            return 0

        entry_price = trade['entry_price']

        if trade['direction'] == 'long':
            best_price = market_slice['high'].max()
            mfe = (best_price - entry_price) / entry_price
        else:
            best_price = market_slice['low'].min()
            mfe = (entry_price - best_price) / entry_price

        return max(0, mfe)
```

---

## Strategy Diagnostics

### Identifying Problems

```python
class StrategyDiagnostics:
    """
    Diagnose strategy issues
    """

    def __init__(self, trades: List[Dict], equity_curve: pd.Series):
        self.trades = trades
        self.equity = equity_curve

    def identify_issues(self) -> List[str]:
        """
        Identify potential strategy issues
        """
        issues = []
        metrics = self._calculate_metrics()

        # Win rate issues
        if metrics['win_rate'] < 0.35:
            issues.append("Low win rate - consider tighter entry criteria or wider stops")
        if metrics['win_rate'] > 0.70 and metrics['profit_factor'] < 1.5:
            issues.append("High win rate but low profit factor - you may be cutting winners too early")

        # Risk/reward issues
        if metrics['avg_win'] < metrics['avg_loss']:
            issues.append("Average win smaller than average loss - improve R:R or exits")

        # Consistency issues
        if metrics['largest_loss'] > 3 * metrics['avg_loss']:
            issues.append("Outsized losses detected - check stop loss execution")

        # Drawdown issues
        if metrics['max_drawdown'] > 0.15:
            issues.append("Large drawdown - reduce position sizes or improve risk management")

        if metrics['avg_drawdown_duration'] > 20:
            issues.append("Long recovery times - strategy may struggle in certain conditions")

        # Time-based issues
        if metrics.get('monday_pnl', 0) < metrics.get('friday_pnl', 0) * 0.5:
            issues.append("Significant weekday performance variation - investigate")

        # Regime issues
        if metrics.get('bull_pnl', 0) > 0 and metrics.get('bear_pnl', 0) < 0:
            issues.append("Strategy only works in bull markets - add short capability or filters")

        return issues

    def _calculate_metrics(self) -> Dict:
        """Calculate comprehensive metrics"""
        wins = [t for t in self.trades if t['pnl'] > 0]
        losses = [t for t in self.trades if t['pnl'] <= 0]

        # Basic metrics
        win_rate = len(wins) / len(self.trades) if self.trades else 0
        avg_win = np.mean([t['pnl'] for t in wins]) if wins else 0
        avg_loss = abs(np.mean([t['pnl'] for t in losses])) if losses else 0
        profit_factor = sum(t['pnl'] for t in wins) / abs(sum(t['pnl'] for t in losses)) if losses else float('inf')
        largest_loss = min(t['pnl'] for t in self.trades) if self.trades else 0

        # Drawdown metrics
        running_max = self.equity.cummax()
        drawdown = (running_max - self.equity) / running_max
        max_drawdown = drawdown.max()

        # Drawdown duration
        in_drawdown = drawdown > 0
        drawdown_periods = []
        current_period = 0
        for dd in in_drawdown:
            if dd:
                current_period += 1
            else:
                if current_period > 0:
                    drawdown_periods.append(current_period)
                current_period = 0
        avg_drawdown_duration = np.mean(drawdown_periods) if drawdown_periods else 0

        return {
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'largest_loss': largest_loss,
            'max_drawdown': max_drawdown,
            'avg_drawdown_duration': avg_drawdown_duration
        }

    def improvement_recommendations(self) -> List[Dict]:
        """
        Generate specific improvement recommendations
        """
        recommendations = []
        quality = TradeAnalyzer(self.trades, pd.DataFrame()).trade_quality_metrics()

        # Analyze capture ratio
        avg_capture = quality['capture_ratio'].mean()
        if avg_capture < 0.5:
            recommendations.append({
                'area': 'Exit Strategy',
                'issue': f'Only capturing {avg_capture:.1%} of favorable moves',
                'suggestion': 'Consider trailing stops or scaling out of positions'
            })

        # Analyze edge ratio
        avg_edge = quality['edge_ratio'].mean()
        if avg_edge < 1.5:
            recommendations.append({
                'area': 'Entry Strategy',
                'issue': f'Edge ratio of {avg_edge:.2f} indicates poor entries',
                'suggestion': 'Wait for better entry signals or use limit orders'
            })

        # Analyze timing
        avg_timing = quality['timing_score'].mean()
        if avg_timing < 0:
            recommendations.append({
                'area': 'Timing',
                'issue': 'Entering/exiting at suboptimal times',
                'suggestion': 'Add time-of-day filters or use multi-timeframe confirmation'
            })

        # Analyze by symbol
        symbol_pnl = quality.groupby('symbol')['pnl'].sum()
        losing_symbols = symbol_pnl[symbol_pnl < 0]
        if len(losing_symbols) > 0:
            recommendations.append({
                'area': 'Asset Selection',
                'issue': f'Losing money on: {", ".join(losing_symbols.index)}',
                'suggestion': 'Consider removing these symbols or using different parameters'
            })

        return recommendations
```

---

## Attribution Report

```python
class AttributionReport:
    """
    Generate comprehensive attribution report
    """

    def __init__(self, trades: List[Dict], market_data: pd.DataFrame,
                 benchmark_returns: pd.Series):
        self.trades = trades
        self.market = market_data
        self.benchmark = benchmark_returns

        self.performance = PerformanceAttribution(trades, market_data)
        self.diagnostics = StrategyDiagnostics(trades,
            pd.Series([t['pnl'] for t in trades]).cumsum() + 100000)

    def generate(self) -> Dict:
        """Generate full attribution report"""
        basic = self.performance.basic_attribution()
        alpha_beta = self.performance.alpha_beta_decomposition(self.benchmark)
        issues = self.diagnostics.identify_issues()
        recommendations = self.diagnostics.improvement_recommendations()

        return {
            'summary': {
                'total_pnl': basic['total_pnl'],
                'num_trades': len(self.trades),
                'win_rate': basic['win_rate'],
                'alpha_annual': alpha_beta.get('alpha_annual', 0),
                'beta': alpha_beta.get('beta', 0),
                'information_ratio': alpha_beta.get('information_ratio', 0)
            },
            'decomposition': {
                'by_direction': {
                    'long': basic['long_pnl'],
                    'short': basic['short_pnl']
                },
                'by_symbol': basic['by_symbol'],
                'by_time': basic['by_time'],
                'alpha_contribution': alpha_beta.get('alpha_contribution', 0),
                'beta_contribution': alpha_beta.get('beta_contribution', 0)
            },
            'diagnostics': {
                'issues': issues,
                'recommendations': recommendations
            }
        }

    def print_report(self):
        """Print formatted report"""
        report = self.generate()

        print("=" * 60)
        print("PERFORMANCE ATTRIBUTION REPORT")
        print("=" * 60)

        print("\n📊 SUMMARY")
        print("-" * 40)
        for key, value in report['summary'].items():
            if isinstance(value, float):
                print(f"  {key}: {value:.4f}")
            else:
                print(f"  {key}: {value}")

        print("\n📈 RETURN DECOMPOSITION")
        print("-" * 40)
        print("  By Direction:")
        for direction, pnl in report['decomposition']['by_direction'].items():
            print(f"    {direction}: ${pnl:,.2f}")

        print("\n  Top Symbols:")
        sorted_symbols = sorted(report['decomposition']['by_symbol'].items(),
                               key=lambda x: abs(x[1]), reverse=True)[:5]
        for symbol, pnl in sorted_symbols:
            print(f"    {symbol}: ${pnl:,.2f}")

        print("\n⚠️ ISSUES DETECTED")
        print("-" * 40)
        for issue in report['diagnostics']['issues']:
            print(f"  • {issue}")

        print("\n💡 RECOMMENDATIONS")
        print("-" * 40)
        for rec in report['diagnostics']['recommendations']:
            print(f"  [{rec['area']}]")
            print(f"    Issue: {rec['issue']}")
            print(f"    Action: {rec['suggestion']}")

        print("\n" + "=" * 60)
```

---

## Summary

Performance attribution helps you:

1. **Understand return sources** - Alpha vs beta, factor exposures
2. **Identify strengths** - What's working and why
3. **Diagnose problems** - What needs improvement
4. **Make better decisions** - Data-driven strategy refinement

Key metrics to track:
- Alpha (skill-based return)
- Capture ratio (are you getting full value from moves?)
- Edge ratio (entry quality)
- Factor exposures (what risks are you taking?)

Regular attribution analysis is essential for continuous improvement.

---

*Next: [18-case-studies.md](./18-case-studies.md) - Real-world strategy examples with full analysis*
