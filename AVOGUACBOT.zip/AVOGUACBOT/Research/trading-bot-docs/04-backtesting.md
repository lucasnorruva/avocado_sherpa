# 04 - Backtesting

> **Testing trading strategies on historical data to evaluate performance**

---

## Overview

Backtesting is the process of testing a trading strategy on historical data to see how it would have performed. While past performance doesn't guarantee future results, backtesting helps identify strategies that have no edge and shouldn't be traded.

---

## Backtesting Fundamentals

### What Backtesting Can Tell You

- Historical win rate
- Historical risk/reward ratio
- Maximum drawdown
- Strategy behavior in different market conditions
- Parameter sensitivity

### What Backtesting Cannot Tell You

- Future performance
- How you'll react emotionally
- Execution quality in live markets
- Impact of slippage and fees at scale
- Black swan event survival

### Common Pitfalls

1. **Look-ahead bias** - Using future data in decisions
2. **Survivorship bias** - Only testing on assets that still exist
3. **Overfitting** - Curve-fitting to historical data
4. **Ignoring costs** - Not accounting for fees, slippage, spread
5. **Data quality** - Using bad or incomplete data

---

## Backtesting Frameworks

### Using Backtrader

Backtrader is a full-featured Python backtesting framework:

```python
import backtrader as bt
import pandas as pd

class MACrossStrategy(bt.Strategy):
    params = (
        ('fast_period', 10),
        ('slow_period', 30),
    )

    def __init__(self):
        self.fast_ma = bt.indicators.EMA(self.data.close, period=self.params.fast_period)
        self.slow_ma = bt.indicators.EMA(self.data.close, period=self.params.slow_period)
        self.crossover = bt.indicators.CrossOver(self.fast_ma, self.slow_ma)

    def next(self):
        if not self.position:
            if self.crossover > 0:  # Fast crosses above slow
                self.buy()
        else:
            if self.crossover < 0:  # Fast crosses below slow
                self.close()


def run_backtest(data_df, strategy_class, cash=100000, commission=0.001):
    """Run a backtest with Backtrader"""
    cerebro = bt.Cerebro()

    # Add strategy
    cerebro.addstrategy(strategy_class)

    # Create data feed
    data = bt.feeds.PandasData(dataname=data_df)
    cerebro.adddata(data)

    # Set broker parameters
    cerebro.broker.setcash(cash)
    cerebro.broker.setcommission(commission=commission)

    # Add analyzers
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
    cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')

    # Run backtest
    print(f'Starting Portfolio Value: {cerebro.broker.getvalue():.2f}')
    results = cerebro.run()
    print(f'Final Portfolio Value: {cerebro.broker.getvalue():.2f}')

    # Extract results
    strat = results[0]
    return {
        'final_value': cerebro.broker.getvalue(),
        'sharpe': strat.analyzers.sharpe.get_analysis(),
        'drawdown': strat.analyzers.drawdown.get_analysis(),
        'trades': strat.analyzers.trades.get_analysis(),
        'returns': strat.analyzers.returns.get_analysis(),
    }


# Example usage
# results = run_backtest(btc_data, MACrossStrategy)
```

### Using Vectorbt

Vectorbt is faster for parameter optimization:

```python
import vectorbt as vbt
import numpy as np

def vectorized_ma_backtest(df, fast_periods, slow_periods):
    """
    Vectorized backtest of MA crossover strategy
    Tests all parameter combinations simultaneously
    """
    price = df['close']

    # Create parameter combinations
    fast_ma, slow_ma = vbt.MA.run_combs(
        price,
        window=fast_periods,
        r=2,  # 2 windows for crossover
        short_names=['fast', 'slow']
    )

    # Generate entry/exit signals
    entries = fast_ma.ma_crossed_above(slow_ma)
    exits = fast_ma.ma_crossed_below(slow_ma)

    # Run portfolio simulation
    portfolio = vbt.Portfolio.from_signals(
        price,
        entries,
        exits,
        init_cash=100000,
        fees=0.001
    )

    return portfolio


def analyze_vbt_results(portfolio):
    """Analyze vectorbt portfolio results"""
    stats = portfolio.stats()

    # Get best parameters
    best_params = portfolio.total_return().idxmax()

    return {
        'stats': stats,
        'best_params': best_params,
        'total_return': portfolio.total_return(),
        'sharpe_ratio': portfolio.sharpe_ratio(),
        'max_drawdown': portfolio.max_drawdown(),
    }
```

### Custom Backtester

For prop-firm specific requirements, a custom backtester gives more control:

```python
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime
import pandas as pd

@dataclass
class Trade:
    entry_time: datetime
    entry_price: float
    direction: str  # 'long' or 'short'
    size: float
    exit_time: Optional[datetime] = None
    exit_price: Optional[float] = None
    pnl: Optional[float] = None
    pnl_pct: Optional[float] = None

@dataclass
class BacktestResult:
    trades: List[Trade]
    equity_curve: pd.Series
    initial_capital: float
    final_capital: float
    total_return: float
    max_drawdown: float
    max_daily_drawdown: float
    win_rate: float
    profit_factor: float
    sharpe_ratio: float
    total_trades: int
    winning_trades: int
    losing_trades: int


class PropFirmBacktester:
    """
    Custom backtester with prop firm rules built in
    """

    def __init__(self, initial_capital=100000, commission_pct=0.001,
                 slippage_pct=0.0005, max_daily_dd=0.05, max_total_dd=0.10):
        self.initial_capital = initial_capital
        self.commission_pct = commission_pct
        self.slippage_pct = slippage_pct
        self.max_daily_dd = max_daily_dd
        self.max_total_dd = max_total_dd

        self.reset()

    def reset(self):
        """Reset backtester state"""
        self.capital = self.initial_capital
        self.equity_curve = []
        self.trades = []
        self.current_position = None
        self.daily_pnl = 0
        self.daily_start_capital = self.initial_capital
        self.current_date = None
        self.stopped_out = False

    def run(self, df: pd.DataFrame, strategy) -> BacktestResult:
        """Run backtest"""
        self.reset()

        for i in range(strategy.get_required_history(), len(df)):
            current_bar = df.iloc[i]
            history = df.iloc[:i+1]
            current_time = df.index[i]

            # Check for new day
            self._check_new_day(current_time)

            # Check if stopped due to drawdown
            if self.stopped_out:
                break

            # Update unrealized P&L
            if self.current_position:
                self._update_unrealized_pnl(current_bar['close'])

            # Check prop firm rules before allowing new trades
            if not self._check_drawdown_rules():
                self.stopped_out = True
                if self.current_position:
                    self._close_position(current_bar, "Drawdown limit hit")
                break

            # Check for exit conditions on current position
            if self.current_position:
                should_exit, reason = self._check_exit_conditions(
                    current_bar, self.current_position
                )
                if should_exit:
                    self._close_position(current_bar, reason)
                    continue

            # Generate signal
            position_type = self.current_position['direction'] if self.current_position else None
            signal = strategy.generate_signal(history, position_type)

            # Execute signal
            if signal.type != SignalType.NONE:
                self._execute_signal(signal, current_bar)

            # Record equity
            self.equity_curve.append({
                'time': current_time,
                'equity': self._get_equity(current_bar['close'])
            })

        # Close any remaining position
        if self.current_position:
            self._close_position(df.iloc[-1], "End of backtest")

        return self._generate_results()

    def _check_new_day(self, current_time):
        """Handle daily reset"""
        current_date = current_time.date()
        if self.current_date != current_date:
            self.current_date = current_date
            self.daily_start_capital = self.capital
            self.daily_pnl = 0

    def _check_drawdown_rules(self) -> bool:
        """Check if prop firm drawdown rules are violated"""
        # Daily drawdown
        daily_dd = (self.daily_start_capital - self.capital) / self.daily_start_capital
        if daily_dd > self.max_daily_dd:
            return False

        # Total drawdown
        total_dd = (self.initial_capital - self.capital) / self.initial_capital
        if total_dd > self.max_total_dd:
            return False

        return True

    def _check_exit_conditions(self, bar, position):
        """Check stop loss and take profit"""
        current_price = bar['close']

        if position['direction'] == 'long':
            if position.get('stop_loss') and current_price <= position['stop_loss']:
                return True, "Stop loss hit"
            if position.get('take_profit') and current_price >= position['take_profit']:
                return True, "Take profit hit"
        else:  # short
            if position.get('stop_loss') and current_price >= position['stop_loss']:
                return True, "Stop loss hit"
            if position.get('take_profit') and current_price <= position['take_profit']:
                return True, "Take profit hit"

        return False, None

    def _execute_signal(self, signal, bar):
        """Execute a trading signal"""
        if signal.type == SignalType.BUY and not self.current_position:
            self._open_position('long', bar, signal)
        elif signal.type == SignalType.SELL and not self.current_position:
            self._open_position('short', bar, signal)
        elif signal.type == SignalType.CLOSE and self.current_position:
            self._close_position(bar, "Signal close")

    def _open_position(self, direction, bar, signal):
        """Open a new position"""
        entry_price = bar['close']

        # Apply slippage
        if direction == 'long':
            entry_price *= (1 + self.slippage_pct)
        else:
            entry_price *= (1 - self.slippage_pct)

        # Calculate position size (simplified - use risk management in practice)
        size = self.capital * 0.02 / entry_price  # 2% risk per trade

        self.current_position = {
            'direction': direction,
            'entry_price': entry_price,
            'entry_time': bar.name,
            'size': size,
            'stop_loss': signal.stop_loss,
            'take_profit': signal.take_profit
        }

        # Deduct commission
        commission = entry_price * size * self.commission_pct
        self.capital -= commission

    def _close_position(self, bar, reason):
        """Close current position"""
        if not self.current_position:
            return

        exit_price = bar['close']

        # Apply slippage
        if self.current_position['direction'] == 'long':
            exit_price *= (1 - self.slippage_pct)
        else:
            exit_price *= (1 + self.slippage_pct)

        # Calculate P&L
        if self.current_position['direction'] == 'long':
            pnl = (exit_price - self.current_position['entry_price']) * self.current_position['size']
        else:
            pnl = (self.current_position['entry_price'] - exit_price) * self.current_position['size']

        # Deduct commission
        commission = exit_price * self.current_position['size'] * self.commission_pct
        pnl -= commission

        # Record trade
        trade = Trade(
            entry_time=self.current_position['entry_time'],
            entry_price=self.current_position['entry_price'],
            direction=self.current_position['direction'],
            size=self.current_position['size'],
            exit_time=bar.name,
            exit_price=exit_price,
            pnl=pnl,
            pnl_pct=pnl / self.capital * 100
        )
        self.trades.append(trade)

        # Update capital
        self.capital += pnl
        self.daily_pnl += pnl

        self.current_position = None

    def _update_unrealized_pnl(self, current_price):
        """Update unrealized P&L for current position"""
        if not self.current_position:
            return 0

        if self.current_position['direction'] == 'long':
            return (current_price - self.current_position['entry_price']) * self.current_position['size']
        else:
            return (self.current_position['entry_price'] - current_price) * self.current_position['size']

    def _get_equity(self, current_price):
        """Get current equity including unrealized P&L"""
        unrealized = self._update_unrealized_pnl(current_price)
        return self.capital + unrealized

    def _generate_results(self) -> BacktestResult:
        """Generate final backtest results"""
        equity_df = pd.DataFrame(self.equity_curve).set_index('time')

        # Calculate metrics
        winning_trades = [t for t in self.trades if t.pnl > 0]
        losing_trades = [t for t in self.trades if t.pnl <= 0]

        gross_profit = sum(t.pnl for t in winning_trades) if winning_trades else 0
        gross_loss = abs(sum(t.pnl for t in losing_trades)) if losing_trades else 1

        # Maximum drawdown
        equity_series = equity_df['equity']
        running_max = equity_series.cummax()
        drawdown = (running_max - equity_series) / running_max
        max_dd = drawdown.max()

        # Daily drawdowns
        daily_equity = equity_df.resample('D').last().ffill()
        daily_returns = daily_equity.pct_change()
        max_daily_dd = daily_returns.min() if len(daily_returns) > 0 else 0

        # Sharpe ratio (simplified)
        returns = equity_df['equity'].pct_change().dropna()
        sharpe = (returns.mean() / returns.std() * np.sqrt(252)) if returns.std() > 0 else 0

        return BacktestResult(
            trades=self.trades,
            equity_curve=equity_df['equity'],
            initial_capital=self.initial_capital,
            final_capital=self.capital,
            total_return=(self.capital - self.initial_capital) / self.initial_capital,
            max_drawdown=max_dd,
            max_daily_drawdown=abs(max_daily_dd) if max_daily_dd else 0,
            win_rate=len(winning_trades) / len(self.trades) if self.trades else 0,
            profit_factor=gross_profit / gross_loss if gross_loss > 0 else 0,
            sharpe_ratio=sharpe,
            total_trades=len(self.trades),
            winning_trades=len(winning_trades),
            losing_trades=len(losing_trades)
        )
```

---

## Performance Metrics

### Essential Metrics

```python
def calculate_metrics(equity_curve: pd.Series, trades: List[Trade], risk_free_rate=0.02):
    """Calculate comprehensive performance metrics"""
    returns = equity_curve.pct_change().dropna()

    # Basic returns
    total_return = (equity_curve.iloc[-1] - equity_curve.iloc[0]) / equity_curve.iloc[0]
    cagr = (equity_curve.iloc[-1] / equity_curve.iloc[0]) ** (252 / len(equity_curve)) - 1

    # Risk metrics
    volatility = returns.std() * np.sqrt(252)
    sharpe_ratio = (returns.mean() * 252 - risk_free_rate) / volatility if volatility > 0 else 0

    # Sortino ratio (downside risk only)
    downside_returns = returns[returns < 0]
    downside_std = downside_returns.std() * np.sqrt(252)
    sortino_ratio = (returns.mean() * 252 - risk_free_rate) / downside_std if downside_std > 0 else 0

    # Drawdown analysis
    running_max = equity_curve.cummax()
    drawdown = (running_max - equity_curve) / running_max
    max_drawdown = drawdown.max()

    # Calmar ratio
    calmar_ratio = cagr / max_drawdown if max_drawdown > 0 else 0

    # Trade statistics
    pnls = [t.pnl for t in trades]
    winning_trades = [p for p in pnls if p > 0]
    losing_trades = [p for p in pnls if p <= 0]

    win_rate = len(winning_trades) / len(trades) if trades else 0
    avg_win = np.mean(winning_trades) if winning_trades else 0
    avg_loss = abs(np.mean(losing_trades)) if losing_trades else 0
    expectancy = (win_rate * avg_win) - ((1 - win_rate) * avg_loss)

    profit_factor = sum(winning_trades) / abs(sum(losing_trades)) if losing_trades else float('inf')

    return {
        'total_return': total_return,
        'cagr': cagr,
        'volatility': volatility,
        'sharpe_ratio': sharpe_ratio,
        'sortino_ratio': sortino_ratio,
        'max_drawdown': max_drawdown,
        'calmar_ratio': calmar_ratio,
        'win_rate': win_rate,
        'avg_win': avg_win,
        'avg_loss': avg_loss,
        'expectancy': expectancy,
        'profit_factor': profit_factor,
        'total_trades': len(trades),
    }
```

### Metric Benchmarks for Prop Firms

| Metric | Minimum | Good | Excellent |
|--------|---------|------|-----------|
| Win Rate | 40% | 50% | 60%+ |
| Profit Factor | 1.2 | 1.5 | 2.0+ |
| Sharpe Ratio | 1.0 | 1.5 | 2.0+ |
| Max Drawdown | <10% | <7% | <5% |
| Daily DD | <5% | <3% | <2% |

---

## Avoiding Overfitting

### Out-of-Sample Testing

```python
def split_data(df, train_pct=0.7):
    """Split data into train and test sets"""
    split_idx = int(len(df) * train_pct)
    train = df.iloc[:split_idx]
    test = df.iloc[split_idx:]
    return train, test


def cross_validate(df, strategy_class, n_folds=5):
    """K-fold cross-validation for strategies"""
    fold_size = len(df) // n_folds
    results = []

    for i in range(n_folds):
        start = i * fold_size
        end = start + fold_size

        # Use fold i as test, rest as train
        test_fold = df.iloc[start:end]
        train_folds = pd.concat([df.iloc[:start], df.iloc[end:]])

        # Optimize on train, test on test
        best_params = optimize_on_data(strategy_class, train_folds)
        strategy = strategy_class(**best_params)
        performance = backtest(strategy, test_fold)

        results.append({
            'fold': i,
            'params': best_params,
            'performance': performance
        })

    return results
```

### Parameter Stability Analysis

```python
def parameter_sensitivity(df, strategy_class, base_params, param_name, variations):
    """
    Test how sensitive strategy is to parameter changes
    Stable strategies show gradual performance changes
    """
    results = []

    for variation in variations:
        params = base_params.copy()
        params[param_name] = variation

        strategy = strategy_class(**params)
        performance = backtest(strategy, df)

        results.append({
            param_name: variation,
            'sharpe': performance['sharpe_ratio'],
            'return': performance['total_return'],
            'drawdown': performance['max_drawdown']
        })

    return pd.DataFrame(results)
```

### Monte Carlo Simulation

```python
def monte_carlo_analysis(trades: List[Trade], n_simulations=1000, initial_capital=100000):
    """
    Randomize trade order to see range of possible outcomes
    """
    pnls = [t.pnl for t in trades]
    results = []

    for _ in range(n_simulations):
        # Shuffle trade order
        shuffled_pnls = np.random.permutation(pnls)

        # Calculate equity curve
        equity = [initial_capital]
        for pnl in shuffled_pnls:
            equity.append(equity[-1] + pnl)

        equity = pd.Series(equity)
        running_max = equity.cummax()
        max_dd = ((running_max - equity) / running_max).max()

        results.append({
            'final_equity': equity.iloc[-1],
            'max_drawdown': max_dd,
            'total_return': (equity.iloc[-1] - initial_capital) / initial_capital
        })

    results_df = pd.DataFrame(results)

    return {
        'median_return': results_df['total_return'].median(),
        'worst_return': results_df['total_return'].quantile(0.05),
        'best_return': results_df['total_return'].quantile(0.95),
        'median_drawdown': results_df['max_drawdown'].median(),
        'worst_drawdown': results_df['max_drawdown'].quantile(0.95),
    }
```

---

## Reporting

### Generate Backtest Report

```python
def generate_report(result: BacktestResult, output_path='backtest_report.html'):
    """Generate HTML backtest report"""
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots

    # Create figure with subplots
    fig = make_subplots(
        rows=3, cols=2,
        subplot_titles=(
            'Equity Curve', 'Drawdown',
            'Trade Distribution', 'Monthly Returns',
            'Win Rate by Month', 'Trade Duration'
        )
    )

    # Equity curve
    fig.add_trace(
        go.Scatter(x=result.equity_curve.index, y=result.equity_curve.values,
                   name='Equity', line=dict(color='blue')),
        row=1, col=1
    )

    # Drawdown
    running_max = result.equity_curve.cummax()
    drawdown = (running_max - result.equity_curve) / running_max * 100
    fig.add_trace(
        go.Scatter(x=drawdown.index, y=drawdown.values,
                   name='Drawdown %', fill='tozeroy', line=dict(color='red')),
        row=1, col=2
    )

    # Trade P&L distribution
    pnls = [t.pnl for t in result.trades]
    fig.add_trace(
        go.Histogram(x=pnls, name='Trade P&L'),
        row=2, col=1
    )

    fig.update_layout(height=900, title_text="Backtest Report")
    fig.write_html(output_path)

    # Print summary
    print("=" * 50)
    print("BACKTEST SUMMARY")
    print("=" * 50)
    print(f"Total Return: {result.total_return:.2%}")
    print(f"Max Drawdown: {result.max_drawdown:.2%}")
    print(f"Max Daily DD: {result.max_daily_drawdown:.2%}")
    print(f"Sharpe Ratio: {result.sharpe_ratio:.2f}")
    print(f"Win Rate: {result.win_rate:.2%}")
    print(f"Profit Factor: {result.profit_factor:.2f}")
    print(f"Total Trades: {result.total_trades}")
    print("=" * 50)
```

---

## Checklist Before Going Live

After backtesting, verify:

- [ ] Positive expectancy (profit factor > 1.2)
- [ ] Acceptable drawdown (< prop firm limits)
- [ ] Sufficient sample size (100+ trades minimum)
- [ ] Tested on multiple market conditions
- [ ] Out-of-sample results acceptable
- [ ] Parameter stability verified
- [ ] Monte Carlo analysis shows robustness
- [ ] Realistic costs included (spread, slippage, fees)
- [ ] No look-ahead bias
- [ ] Results make logical sense

---

*Next: [05-risk-management.md](./05-risk-management.md) - Position sizing, drawdown control, risk rules*
