# 01 - Trading Bot Architecture

> **System design principles and component architecture for a robust crypto trading bot**

---

## Overview

A well-designed trading bot architecture separates concerns into distinct, modular components that can be developed, tested, and maintained independently. This document outlines the architectural patterns and design decisions that lead to a reliable, scalable trading system.

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         TRADING BOT SYSTEM                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────┐ │
│  │   Market    │    │   Trading   │    │      Risk Manager       │ │
│  │  Data Feed  │───▶│   Engine    │◀──▶│  (Prop Firm Rules)      │ │
│  └─────────────┘    └──────┬──────┘    └─────────────────────────┘ │
│         │                  │                       │                │
│         ▼                  ▼                       ▼                │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────┐ │
│  │  Indicator  │    │  Strategy   │    │    Position Manager     │ │
│  │  Calculator │───▶│   Manager   │───▶│                         │ │
│  └─────────────┘    └─────────────┘    └─────────────────────────┘ │
│                            │                       │                │
│                            ▼                       ▼                │
│                     ┌─────────────┐    ┌─────────────────────────┐ │
│                     │    Order    │───▶│   Exchange Connector    │ │
│                     │   Manager   │◀───│      (CCXT)             │ │
│                     └─────────────┘    └─────────────────────────┘ │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────┐ │
│  │   Logger    │    │  Database   │    │   Notification Service  │ │
│  └─────────────┘    └─────────────┘    └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. Market Data Feed

The market data feed is responsible for obtaining real-time and historical price data.

**Responsibilities:**
- Connect to exchange WebSocket streams
- Maintain OHLCV (Open, High, Low, Close, Volume) data
- Handle reconnection and data gaps
- Normalize data across different exchanges

**Key Considerations:**
- Use WebSocket for real-time data (lower latency than REST polling)
- Implement heartbeat monitoring
- Buffer data to handle brief disconnections
- Consider multiple data sources for redundancy

```python
# Conceptual structure
class MarketDataFeed:
    def __init__(self, exchange, symbols):
        self.exchange = exchange
        self.symbols = symbols
        self.ohlcv_data = {}
        self.orderbook = {}

    async def connect(self):
        """Establish WebSocket connection"""
        pass

    async def on_trade(self, trade):
        """Handle incoming trade data"""
        pass

    async def on_orderbook(self, orderbook):
        """Handle orderbook updates"""
        pass

    def get_candles(self, symbol, timeframe, limit):
        """Return recent candles"""
        pass
```

### 2. Trading Engine

The central coordinator that orchestrates all other components.

**Responsibilities:**
- Initialize and manage all components
- Coordinate data flow between components
- Handle system state (running, paused, stopped)
- Manage the main event loop

**Design Pattern:** Event-driven architecture

```python
class TradingEngine:
    def __init__(self, config):
        self.config = config
        self.data_feed = None
        self.strategy_manager = None
        self.risk_manager = None
        self.order_manager = None
        self.running = False

    async def start(self):
        """Initialize components and start trading loop"""
        self.running = True
        await self.initialize_components()
        await self.run_loop()

    async def run_loop(self):
        """Main trading loop"""
        while self.running:
            # 1. Get latest market data
            # 2. Calculate indicators
            # 3. Generate signals from strategy
            # 4. Validate with risk manager
            # 5. Execute approved orders
            # 6. Update positions
            await asyncio.sleep(self.config.loop_interval)
```

### 3. Strategy Manager

Manages one or more trading strategies and aggregates their signals.

**Responsibilities:**
- Load and initialize strategies
- Feed market data to strategies
- Collect and aggregate trading signals
- Handle strategy lifecycle (enable/disable)

```python
class StrategyManager:
    def __init__(self):
        self.strategies = {}
        self.active_strategies = set()

    def register_strategy(self, name, strategy):
        """Add a strategy to the manager"""
        self.strategies[name] = strategy

    def enable_strategy(self, name):
        """Activate a strategy for trading"""
        self.active_strategies.add(name)

    def process_data(self, market_data):
        """Feed data to strategies and collect signals"""
        signals = []
        for name in self.active_strategies:
            strategy = self.strategies[name]
            signal = strategy.generate_signal(market_data)
            if signal:
                signals.append(signal)
        return signals
```

### 4. Risk Manager

**Critical component for prop firm trading.** Enforces all risk rules and position limits.

**Responsibilities:**
- Validate orders against risk rules
- Track daily and total drawdown
- Enforce position size limits
- Monitor prop firm rule compliance
- Emergency stop functionality

```python
class RiskManager:
    def __init__(self, config):
        self.max_daily_drawdown = config.max_daily_drawdown
        self.max_total_drawdown = config.max_total_drawdown
        self.max_position_size = config.max_position_size
        self.daily_pnl = 0
        self.total_pnl = 0
        self.starting_balance = config.starting_balance

    def validate_order(self, order, current_positions):
        """Check if order complies with all risk rules"""
        checks = [
            self.check_position_size(order),
            self.check_daily_drawdown(),
            self.check_total_drawdown(),
            self.check_exposure_limits(order, current_positions),
        ]
        return all(checks)

    def check_daily_drawdown(self):
        """Ensure daily drawdown limit not exceeded"""
        daily_drawdown_pct = abs(min(0, self.daily_pnl)) / self.starting_balance
        return daily_drawdown_pct < self.max_daily_drawdown
```

### 5. Position Manager

Tracks all open positions and their current state.

**Responsibilities:**
- Track open positions
- Calculate unrealized P&L
- Manage position lifecycle
- Track entry/exit prices and times

```python
class PositionManager:
    def __init__(self):
        self.positions = {}  # symbol -> Position

    def open_position(self, symbol, side, size, entry_price):
        """Record a new position"""
        position = Position(
            symbol=symbol,
            side=side,
            size=size,
            entry_price=entry_price,
            entry_time=datetime.now()
        )
        self.positions[symbol] = position

    def close_position(self, symbol, exit_price):
        """Close and record P&L for a position"""
        position = self.positions.pop(symbol)
        pnl = position.calculate_pnl(exit_price)
        return pnl

    def get_unrealized_pnl(self, current_prices):
        """Calculate total unrealized P&L"""
        total_pnl = 0
        for symbol, position in self.positions.items():
            current_price = current_prices[symbol]
            total_pnl += position.calculate_pnl(current_price)
        return total_pnl
```

### 6. Order Manager

Handles all order operations with the exchange.

**Responsibilities:**
- Create and submit orders
- Track order status
- Handle order fills and partial fills
- Manage order cancellation
- Retry logic for failed orders

```python
class OrderManager:
    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        self.pending_orders = {}
        self.filled_orders = []

    async def submit_order(self, order):
        """Submit order to exchange"""
        try:
            result = await self.exchange.create_order(
                symbol=order.symbol,
                type=order.order_type,
                side=order.side,
                amount=order.size,
                price=order.price
            )
            self.pending_orders[result['id']] = order
            return result
        except Exception as e:
            self.handle_order_error(order, e)

    async def check_order_status(self, order_id):
        """Update order status from exchange"""
        status = await self.exchange.fetch_order(order_id)
        return status
```

### 7. Exchange Connector

Provides a unified interface to interact with exchanges.

**Responsibilities:**
- Authenticate with exchange
- Execute API calls
- Handle rate limiting
- Normalize exchange responses

```python
class ExchangeConnector:
    def __init__(self, exchange_id, credentials):
        self.exchange = ccxt.pro[exchange_id]({
            'apiKey': credentials['api_key'],
            'secret': credentials['secret'],
            'enableRateLimit': True,
        })

    async def create_order(self, symbol, type, side, amount, price=None):
        """Create an order on the exchange"""
        return await self.exchange.create_order(
            symbol, type, side, amount, price
        )

    async def fetch_balance(self):
        """Get account balance"""
        return await self.exchange.fetch_balance()
```

---

## Data Flow

### Order Flow (Signal to Execution)

```
Strategy Signal
      │
      ▼
┌─────────────────┐
│ Risk Validation │──── REJECT ────▶ Log & Notify
└────────┬────────┘
         │ APPROVE
         ▼
┌─────────────────┐
│ Position Sizer  │ Calculate appropriate size
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Order Manager   │ Create order object
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Exchange        │ Submit to exchange
│ Connector       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Confirmation    │ Update positions, P&L
└─────────────────┘
```

### Market Data Flow

```
Exchange WebSocket
      │
      ▼
┌─────────────────┐
│ Data Feed       │ Receive & normalize
└────────┬────────┘
         │
         ├────────────────┐
         ▼                ▼
┌─────────────┐    ┌─────────────┐
│  Indicator  │    │   Storage   │
│  Calculator │    │  (Database) │
└──────┬──────┘    └─────────────┘
       │
       ▼
┌─────────────────┐
│ Strategy        │ Analyze & generate signals
└─────────────────┘
```

---

## Design Principles

### 1. Separation of Concerns
Each component has a single responsibility. This makes testing easier and reduces coupling.

### 2. Event-Driven Architecture
Components communicate through events/messages rather than direct calls where possible.

### 3. Fail-Safe Design
When in doubt, do nothing. Failed components should not cause unintended trades.

```python
# Example: Fail-safe pattern
class SafeOrderManager:
    async def submit_order(self, order):
        try:
            # Pre-submission validation
            if not self.validate_order(order):
                raise ValidationError("Order validation failed")

            # Submit with timeout
            result = await asyncio.wait_for(
                self.exchange.create_order(order),
                timeout=10.0
            )
            return result

        except asyncio.TimeoutError:
            # Don't retry automatically - could cause duplicate orders
            self.log.error("Order timeout - manual review required")
            self.alert_user("Order timeout", order)
            return None

        except Exception as e:
            self.log.error(f"Order failed: {e}")
            return None
```

### 4. Idempotency
Operations should be safe to retry. Use unique order IDs to prevent duplicates.

### 5. Configuration-Driven
All parameters should be configurable without code changes.

```yaml
# config/settings.yaml
trading:
  symbols:
    - BTC/USDT
    - ETH/USDT
  timeframe: 15m

risk:
  max_daily_drawdown: 0.05  # 5%
  max_total_drawdown: 0.10  # 10%
  max_position_size: 0.02   # 2% of account

strategy:
  name: momentum
  params:
    fast_period: 10
    slow_period: 20
```

---

## State Management

### Bot States

```python
class BotState(Enum):
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"      # No new trades, manage existing
    STOPPED = "stopped"    # Complete shutdown
    EMERGENCY = "emergency" # Close all positions
```

### State Transitions

```
INITIALIZING ──▶ RUNNING ◀──▶ PAUSED
                    │
                    ▼
              EMERGENCY ──▶ STOPPED
```

### Persistence
Critical state should be persisted to survive restarts:
- Open positions
- Pending orders
- Daily P&L
- Configuration

---

## Error Handling Strategy

### Error Categories

| Category | Examples | Action |
|----------|----------|--------|
| **Transient** | Network timeout, rate limit | Retry with backoff |
| **Data** | Invalid price, missing data | Skip cycle, alert |
| **Exchange** | Order rejected, insufficient balance | Log, notify, no retry |
| **Critical** | API key invalid, account suspended | Stop bot, alert immediately |

### Circuit Breaker Pattern

```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, reset_timeout=60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN

    def call(self, func, *args, **kwargs):
        if self.state == "OPEN":
            if self.should_attempt_reset():
                self.state = "HALF_OPEN"
            else:
                raise CircuitOpenError()

        try:
            result = func(*args, **kwargs)
            self.on_success()
            return result
        except Exception as e:
            self.on_failure()
            raise
```

---

## Scaling Considerations

### Single-Symbol Bot
- Simpler architecture
- Easier to monitor and debug
- Suitable for most prop firm challenges

### Multi-Symbol Bot
- Shared data feed infrastructure
- Strategy instances per symbol
- Aggregated risk management
- More complex position tracking

### Multi-Strategy Bot
- Strategy manager becomes critical
- Signal aggregation logic needed
- Resource allocation between strategies

---

## Testing Architecture

### Unit Tests
Test individual components in isolation.

### Integration Tests
Test component interactions.

### Backtest Environment
Simulate historical trading.

### Paper Trading
Live data, simulated execution.

### Production
Real money, full monitoring.

```
Unit Tests ──▶ Integration ──▶ Backtest ──▶ Paper ──▶ Production
                                              │
                                              ▼
                                    Minimum 2-4 weeks
                                    before going live
```

---

## Summary

A well-architected trading bot:
1. Has clear separation between components
2. Prioritizes risk management
3. Fails safely
4. Is thoroughly tested
5. Is configurable and maintainable
6. Logs extensively for debugging
7. Alerts on critical issues

The architecture presented here provides a solid foundation for building a prop firm compatible trading bot. The following documents will dive deeper into each component.

---

*Next: [02-market-data.md](./02-market-data.md) - Obtaining and processing market data*
