# 15 - Advanced Risk Models

> **Value at Risk, Expected Shortfall, correlation analysis, and portfolio optimization**

---

## Overview

Basic risk management (position sizing, stop losses) is necessary but not sufficient. Advanced risk models help you understand tail risks, portfolio effects, and optimize capital allocation.

---

## Value at Risk (VaR)

VaR answers: "What's the maximum I could lose with X% confidence over Y time period?"

### Historical VaR

```python
import numpy as np
import pandas as pd
from scipy import stats

class ValueAtRisk:
    """
    Value at Risk calculations using multiple methods
    """

    def __init__(self, returns: pd.Series):
        """
        Args:
            returns: Series of historical returns (daily)
        """
        self.returns = returns.dropna()

    def historical_var(self, confidence: float = 0.95, horizon_days: int = 1) -> float:
        """
        Historical VaR - uses actual return distribution

        Simple and non-parametric, but assumes past = future
        """
        # Scale for time horizon (square root of time)
        scaled_returns = self.returns * np.sqrt(horizon_days)

        # VaR is the percentile of losses
        var = np.percentile(scaled_returns, (1 - confidence) * 100)

        return abs(var)

    def parametric_var(self, confidence: float = 0.95, horizon_days: int = 1) -> float:
        """
        Parametric VaR - assumes normal distribution

        Fast but assumes normality (crypto is NOT normal!)
        """
        mean = self.returns.mean() * horizon_days
        std = self.returns.std() * np.sqrt(horizon_days)

        # Z-score for confidence level
        z_score = stats.norm.ppf(1 - confidence)

        var = -(mean + z_score * std)
        return max(0, var)

    def cornish_fisher_var(self, confidence: float = 0.95, horizon_days: int = 1) -> float:
        """
        Cornish-Fisher VaR - adjusts for skewness and kurtosis

        Better for non-normal distributions like crypto
        """
        mean = self.returns.mean() * horizon_days
        std = self.returns.std() * np.sqrt(horizon_days)
        skew = stats.skew(self.returns)
        kurt = stats.kurtosis(self.returns)

        z = stats.norm.ppf(1 - confidence)

        # Cornish-Fisher expansion
        z_cf = (z +
                (z**2 - 1) * skew / 6 +
                (z**3 - 3*z) * (kurt - 3) / 24 -
                (2*z**3 - 5*z) * (skew**2) / 36)

        var = -(mean + z_cf * std)
        return max(0, var)

    def monte_carlo_var(self, confidence: float = 0.95, horizon_days: int = 1,
                        n_simulations: int = 10000) -> float:
        """
        Monte Carlo VaR - simulates many possible paths

        Most flexible, can model complex distributions
        """
        mean = self.returns.mean()
        std = self.returns.std()
        skew = stats.skew(self.returns)
        kurt = stats.kurtosis(self.returns)

        # Generate random returns using Johnson SU distribution
        # (handles skewness and kurtosis better than normal)
        simulated_returns = []

        for _ in range(n_simulations):
            # Simple: use historical bootstrap
            path_returns = np.random.choice(self.returns, size=horizon_days, replace=True)
            total_return = (1 + path_returns).prod() - 1
            simulated_returns.append(total_return)

        var = np.percentile(simulated_returns, (1 - confidence) * 100)
        return abs(var)

    def calculate_all(self, confidence: float = 0.95, horizon_days: int = 1) -> dict:
        """Calculate VaR using all methods"""
        return {
            'historical': self.historical_var(confidence, horizon_days),
            'parametric': self.parametric_var(confidence, horizon_days),
            'cornish_fisher': self.cornish_fisher_var(confidence, horizon_days),
            'monte_carlo': self.monte_carlo_var(confidence, horizon_days),
        }


# Example usage
# returns = df['close'].pct_change().dropna()
# var_calc = ValueAtRisk(returns)
# print(f"95% 1-day VaR: {var_calc.historical_var(0.95, 1):.2%}")
# print(f"99% 1-day VaR: {var_calc.historical_var(0.99, 1):.2%}")
```

### VaR for Portfolio

```python
class PortfolioVaR:
    """
    Portfolio VaR considering correlations between assets
    """

    def __init__(self, returns_df: pd.DataFrame, weights: dict):
        """
        Args:
            returns_df: DataFrame with asset returns as columns
            weights: Dict of {asset: weight}
        """
        self.returns = returns_df
        self.weights = weights
        self.assets = list(weights.keys())

    def calculate_portfolio_returns(self) -> pd.Series:
        """Calculate portfolio returns based on weights"""
        portfolio_returns = pd.Series(0, index=self.returns.index)

        for asset, weight in self.weights.items():
            if asset in self.returns.columns:
                portfolio_returns += self.returns[asset] * weight

        return portfolio_returns

    def variance_covariance_var(self, confidence: float = 0.95) -> float:
        """
        Variance-Covariance (Parametric) Portfolio VaR

        Considers correlations between assets
        """
        # Calculate covariance matrix
        cov_matrix = self.returns[self.assets].cov()

        # Convert weights to array
        weights_array = np.array([self.weights[a] for a in self.assets])

        # Portfolio variance = w' * Σ * w
        portfolio_variance = np.dot(weights_array.T, np.dot(cov_matrix, weights_array))
        portfolio_std = np.sqrt(portfolio_variance)

        # Portfolio mean
        means = self.returns[self.assets].mean()
        portfolio_mean = sum(self.weights[a] * means[a] for a in self.assets)

        # VaR
        z_score = stats.norm.ppf(1 - confidence)
        var = -(portfolio_mean + z_score * portfolio_std)

        return max(0, var)

    def marginal_var(self, confidence: float = 0.95) -> dict:
        """
        Marginal VaR - contribution of each asset to total VaR

        Useful for understanding which positions contribute most to risk
        """
        base_var = self.variance_covariance_var(confidence)

        marginal = {}
        delta = 0.01  # 1% change in weight

        for asset in self.assets:
            # Increase weight slightly
            modified_weights = self.weights.copy()
            modified_weights[asset] += delta

            # Normalize
            total = sum(modified_weights.values())
            modified_weights = {k: v/total for k, v in modified_weights.items()}

            # Calculate new VaR
            temp_var = PortfolioVaR(self.returns, modified_weights)
            new_var = temp_var.variance_covariance_var(confidence)

            # Marginal VaR
            marginal[asset] = (new_var - base_var) / delta

        return marginal

    def component_var(self, confidence: float = 0.95) -> dict:
        """
        Component VaR - how much each asset contributes to total VaR

        Sum of component VaRs = Total VaR
        """
        marginal = self.marginal_var(confidence)
        component = {
            asset: marginal[asset] * self.weights[asset]
            for asset in self.assets
        }
        return component
```

---

## Expected Shortfall (CVaR)

Expected Shortfall answers: "Given that losses exceed VaR, what's the expected loss?"

```python
class ExpectedShortfall:
    """
    Expected Shortfall (Conditional VaR)

    More coherent risk measure than VaR - considers tail shape
    """

    def __init__(self, returns: pd.Series):
        self.returns = returns.dropna()

    def calculate(self, confidence: float = 0.95) -> float:
        """
        Calculate Expected Shortfall

        ES = E[Loss | Loss > VaR]
        """
        var = np.percentile(self.returns, (1 - confidence) * 100)

        # Average of returns worse than VaR
        tail_returns = self.returns[self.returns <= var]

        if len(tail_returns) == 0:
            return abs(var)

        es = abs(tail_returns.mean())
        return es

    def calculate_parametric(self, confidence: float = 0.95) -> float:
        """
        Parametric ES assuming normal distribution
        """
        mean = self.returns.mean()
        std = self.returns.std()

        z = stats.norm.ppf(1 - confidence)
        es = -mean + std * stats.norm.pdf(z) / (1 - confidence)

        return es

    def tail_analysis(self, confidence: float = 0.95) -> dict:
        """
        Comprehensive tail risk analysis
        """
        var = np.percentile(self.returns, (1 - confidence) * 100)
        tail_returns = self.returns[self.returns <= var]

        return {
            'var': abs(var),
            'expected_shortfall': abs(tail_returns.mean()) if len(tail_returns) > 0 else abs(var),
            'worst_loss': abs(self.returns.min()),
            'tail_count': len(tail_returns),
            'tail_std': tail_returns.std() if len(tail_returns) > 1 else 0,
            'var_breaches_expected': int(len(self.returns) * (1 - confidence)),
            'var_breaches_actual': len(tail_returns)
        }
```

---

## Correlation Analysis

Understanding correlations is crucial for portfolio risk.

```python
class CorrelationAnalyzer:
    """
    Analyze correlations between assets and with market
    """

    def __init__(self, returns_df: pd.DataFrame):
        self.returns = returns_df

    def correlation_matrix(self) -> pd.DataFrame:
        """Calculate correlation matrix"""
        return self.returns.corr()

    def rolling_correlation(self, asset1: str, asset2: str,
                           window: int = 30) -> pd.Series:
        """Calculate rolling correlation between two assets"""
        return self.returns[asset1].rolling(window).corr(self.returns[asset2])

    def correlation_during_stress(self, threshold: float = -0.02) -> pd.DataFrame:
        """
        Calculate correlations during market stress periods

        Correlations often increase during crashes (correlation breakdown)
        """
        # Identify stress periods (market down more than threshold)
        if 'BTC' in self.returns.columns:
            market_proxy = 'BTC'
        else:
            market_proxy = self.returns.columns[0]

        stress_mask = self.returns[market_proxy] < threshold
        stress_returns = self.returns[stress_mask]

        return stress_returns.corr()

    def correlation_regime_analysis(self) -> dict:
        """
        Analyze how correlations change across market regimes
        """
        if 'BTC' in self.returns.columns:
            market = self.returns['BTC']
        else:
            market = self.returns.iloc[:, 0]

        # Define regimes
        bull_mask = market > market.quantile(0.7)
        bear_mask = market < market.quantile(0.3)
        normal_mask = ~bull_mask & ~bear_mask

        return {
            'bull_market_correlation': self.returns[bull_mask].corr(),
            'bear_market_correlation': self.returns[bear_mask].corr(),
            'normal_correlation': self.returns[normal_mask].corr(),
        }

    def diversification_ratio(self, weights: dict) -> float:
        """
        Calculate diversification ratio

        DR > 1 means portfolio is diversified
        DR = 1 means no diversification benefit
        """
        assets = list(weights.keys())
        w = np.array([weights[a] for a in assets])

        # Individual volatilities
        vols = self.returns[assets].std()
        weighted_avg_vol = sum(w * vols)

        # Portfolio volatility
        cov_matrix = self.returns[assets].cov()
        port_var = np.dot(w.T, np.dot(cov_matrix, w))
        port_vol = np.sqrt(port_var)

        return weighted_avg_vol / port_vol if port_vol > 0 else 1


class DynamicCorrelation:
    """
    Dynamic Conditional Correlation (DCC) model

    Captures time-varying correlations
    """

    def __init__(self, returns_df: pd.DataFrame):
        self.returns = returns_df

    def ewma_correlation(self, decay: float = 0.94) -> pd.DataFrame:
        """
        Exponentially Weighted Moving Average correlation

        Simple dynamic correlation model
        """
        correlations = []

        for i in range(len(self.returns)):
            if i < 30:  # Minimum history
                correlations.append(self.returns.iloc[:i+1].corr() if i > 0 else None)
            else:
                # EWMA weights
                weights = np.array([(1-decay) * decay**j for j in range(i+1)])
                weights = weights[::-1]
                weights /= weights.sum()

                # Weighted correlation (simplified)
                weighted_returns = self.returns.iloc[:i+1] * weights.reshape(-1, 1)
                correlations.append(self.returns.iloc[:i+1].corr())

        return correlations[-1] if correlations else None
```

---

## Portfolio Optimization

Optimize position weights for best risk-adjusted returns.

```python
from scipy.optimize import minimize

class PortfolioOptimizer:
    """
    Portfolio optimization using Modern Portfolio Theory and extensions
    """

    def __init__(self, returns_df: pd.DataFrame):
        self.returns = returns_df
        self.assets = returns_df.columns.tolist()
        self.n_assets = len(self.assets)

    def mean_variance_optimize(self, target_return: float = None,
                                risk_free_rate: float = 0.02) -> dict:
        """
        Classic Markowitz mean-variance optimization

        Maximize Sharpe ratio or minimize variance for target return
        """
        mean_returns = self.returns.mean() * 252  # Annualized
        cov_matrix = self.returns.cov() * 252

        def neg_sharpe(weights):
            port_return = np.dot(weights, mean_returns)
            port_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
            return -(port_return - risk_free_rate) / port_vol

        def portfolio_variance(weights):
            return np.dot(weights.T, np.dot(cov_matrix, weights))

        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda x: np.sum(x) - 1}  # Weights sum to 1
        ]

        if target_return is not None:
            constraints.append({
                'type': 'eq',
                'fun': lambda x: np.dot(x, mean_returns) - target_return
            })

        # Bounds (no short selling)
        bounds = tuple((0, 1) for _ in range(self.n_assets))

        # Initial guess
        init_weights = np.array([1/self.n_assets] * self.n_assets)

        # Optimize
        if target_return is None:
            # Maximize Sharpe
            result = minimize(neg_sharpe, init_weights,
                            method='SLSQP', bounds=bounds, constraints=constraints)
        else:
            # Minimize variance for target return
            result = minimize(portfolio_variance, init_weights,
                            method='SLSQP', bounds=bounds, constraints=constraints)

        opt_weights = result.x
        opt_return = np.dot(opt_weights, mean_returns)
        opt_vol = np.sqrt(np.dot(opt_weights.T, np.dot(cov_matrix, opt_weights)))
        opt_sharpe = (opt_return - risk_free_rate) / opt_vol

        return {
            'weights': dict(zip(self.assets, opt_weights)),
            'expected_return': opt_return,
            'volatility': opt_vol,
            'sharpe_ratio': opt_sharpe
        }

    def minimum_variance_portfolio(self) -> dict:
        """Find the minimum variance portfolio"""
        cov_matrix = self.returns.cov() * 252

        def portfolio_variance(weights):
            return np.dot(weights.T, np.dot(cov_matrix, weights))

        constraints = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1}]
        bounds = tuple((0, 1) for _ in range(self.n_assets))
        init_weights = np.array([1/self.n_assets] * self.n_assets)

        result = minimize(portfolio_variance, init_weights,
                         method='SLSQP', bounds=bounds, constraints=constraints)

        return {
            'weights': dict(zip(self.assets, result.x)),
            'volatility': np.sqrt(result.fun)
        }

    def risk_parity_portfolio(self) -> dict:
        """
        Risk Parity - equal risk contribution from each asset

        Popular in institutional investing
        """
        cov_matrix = self.returns.cov() * 252

        def risk_contribution(weights):
            port_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
            marginal_contrib = np.dot(cov_matrix, weights) / port_vol
            risk_contrib = weights * marginal_contrib
            return risk_contrib

        def objective(weights):
            rc = risk_contribution(weights)
            target_rc = np.ones(self.n_assets) / self.n_assets
            return np.sum((rc - target_rc)**2)

        constraints = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1}]
        bounds = tuple((0.01, 1) for _ in range(self.n_assets))  # Minimum 1%
        init_weights = np.array([1/self.n_assets] * self.n_assets)

        result = minimize(objective, init_weights,
                         method='SLSQP', bounds=bounds, constraints=constraints)

        opt_weights = result.x
        risk_contribs = risk_contribution(opt_weights)

        return {
            'weights': dict(zip(self.assets, opt_weights)),
            'risk_contributions': dict(zip(self.assets, risk_contribs))
        }

    def black_litterman(self, views: dict, view_confidences: dict,
                        market_weights: dict, risk_aversion: float = 2.5) -> dict:
        """
        Black-Litterman model - combines market equilibrium with investor views

        Args:
            views: Dict of {asset: expected_return_view}
            view_confidences: Dict of {asset: confidence} (0-1)
            market_weights: Dict of {asset: market_cap_weight}
            risk_aversion: Risk aversion parameter
        """
        # Market equilibrium returns
        cov_matrix = self.returns.cov() * 252
        w_mkt = np.array([market_weights.get(a, 1/self.n_assets) for a in self.assets])
        pi = risk_aversion * np.dot(cov_matrix, w_mkt)  # Equilibrium returns

        # Views matrix
        P = np.eye(self.n_assets)  # Simplified: one view per asset
        Q = np.array([views.get(a, pi[i]) for i, a in enumerate(self.assets)])

        # Confidence matrix (Omega)
        tau = 0.05  # Scaling factor
        omega_diag = [
            (1 - view_confidences.get(a, 0)) * cov_matrix.iloc[i, i]
            for i, a in enumerate(self.assets)
        ]
        Omega = np.diag(omega_diag)

        # Black-Litterman formula
        tau_cov = tau * cov_matrix
        M_inv = np.linalg.inv(np.linalg.inv(tau_cov) + np.dot(P.T, np.dot(np.linalg.inv(Omega), P)))
        bl_returns = np.dot(M_inv, np.dot(np.linalg.inv(tau_cov), pi) + np.dot(P.T, np.dot(np.linalg.inv(Omega), Q)))

        # Optimize with BL returns
        def neg_sharpe_bl(weights):
            port_return = np.dot(weights, bl_returns)
            port_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
            return -port_return / port_vol if port_vol > 0 else 0

        constraints = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1}]
        bounds = tuple((0, 1) for _ in range(self.n_assets))

        result = minimize(neg_sharpe_bl, w_mkt,
                         method='SLSQP', bounds=bounds, constraints=constraints)

        return {
            'weights': dict(zip(self.assets, result.x)),
            'bl_expected_returns': dict(zip(self.assets, bl_returns)),
            'equilibrium_returns': dict(zip(self.assets, pi))
        }

    def efficient_frontier(self, n_points: int = 50) -> pd.DataFrame:
        """Generate the efficient frontier"""
        mean_returns = self.returns.mean() * 252

        # Find return range
        min_ret = mean_returns.min()
        max_ret = mean_returns.max()

        target_returns = np.linspace(min_ret, max_ret, n_points)
        frontier = []

        for target in target_returns:
            try:
                result = self.mean_variance_optimize(target_return=target)
                frontier.append({
                    'return': result['expected_return'],
                    'volatility': result['volatility'],
                    'sharpe': result['sharpe_ratio'],
                    'weights': result['weights']
                })
            except:
                continue

        return pd.DataFrame(frontier)
```

---

## Risk Budgeting

Allocate risk rather than capital.

```python
class RiskBudgeting:
    """
    Risk budgeting for trading strategies

    Allocate risk budget across strategies or assets
    """

    def __init__(self, total_risk_budget: float = 0.10):
        """
        Args:
            total_risk_budget: Total portfolio risk (e.g., 10% max DD)
        """
        self.total_budget = total_risk_budget
        self.allocations = {}

    def allocate_by_sharpe(self, strategy_stats: dict) -> dict:
        """
        Allocate risk budget proportional to Sharpe ratio

        Better strategies get more risk budget
        """
        total_sharpe = sum(max(0, s['sharpe']) for s in strategy_stats.values())

        if total_sharpe == 0:
            # Equal allocation if no positive Sharpe
            n = len(strategy_stats)
            return {name: self.total_budget / n for name in strategy_stats}

        allocations = {}
        for name, stats in strategy_stats.items():
            sharpe_contrib = max(0, stats['sharpe']) / total_sharpe
            allocations[name] = self.total_budget * sharpe_contrib

        return allocations

    def allocate_by_volatility(self, strategy_stats: dict) -> dict:
        """
        Inverse volatility allocation

        Lower vol strategies get larger allocation
        """
        inv_vols = {name: 1/stats['volatility'] for name, stats in strategy_stats.items()
                   if stats['volatility'] > 0}

        total_inv_vol = sum(inv_vols.values())

        return {
            name: self.total_budget * (iv / total_inv_vol)
            for name, iv in inv_vols.items()
        }

    def kelly_allocation(self, strategy_stats: dict, fraction: float = 0.25) -> dict:
        """
        Kelly-based risk allocation

        Uses fractional Kelly for safety
        """
        allocations = {}

        for name, stats in strategy_stats.items():
            win_rate = stats.get('win_rate', 0.5)
            avg_win = stats.get('avg_win', 1)
            avg_loss = stats.get('avg_loss', 1)

            if avg_loss == 0:
                kelly = 0
            else:
                b = avg_win / avg_loss
                kelly = (win_rate * b - (1 - win_rate)) / b

            # Fractional Kelly and cap
            kelly = max(0, min(0.25, kelly * fraction))
            allocations[name] = self.total_budget * kelly

        # Normalize to total budget
        total_alloc = sum(allocations.values())
        if total_alloc > self.total_budget:
            scale = self.total_budget / total_alloc
            allocations = {k: v * scale for k, v in allocations.items()}

        return allocations
```

---

## Real-Time Risk Monitoring

```python
class RealTimeRiskMonitor:
    """
    Real-time risk monitoring for live trading
    """

    def __init__(self, config: dict):
        self.var_limit = config.get('var_limit', 0.05)
        self.es_limit = config.get('es_limit', 0.08)
        self.correlation_threshold = config.get('correlation_threshold', 0.8)
        self.drawdown_limit = config.get('drawdown_limit', 0.10)

        self.alerts = []

    def check_var_breach(self, current_var: float) -> bool:
        """Check if VaR exceeds limit"""
        if current_var > self.var_limit:
            self.alerts.append({
                'type': 'VAR_BREACH',
                'message': f'VaR {current_var:.2%} exceeds limit {self.var_limit:.2%}',
                'severity': 'HIGH'
            })
            return True
        return False

    def check_correlation_breakdown(self, current_corr: float,
                                     historical_corr: float) -> bool:
        """Check for correlation regime change"""
        if abs(current_corr - historical_corr) > 0.3:
            self.alerts.append({
                'type': 'CORRELATION_CHANGE',
                'message': f'Correlation changed from {historical_corr:.2f} to {current_corr:.2f}',
                'severity': 'MEDIUM'
            })
            return True
        return False

    def check_concentration(self, position_weights: dict,
                           max_concentration: float = 0.30) -> bool:
        """Check for position concentration risk"""
        for asset, weight in position_weights.items():
            if abs(weight) > max_concentration:
                self.alerts.append({
                    'type': 'CONCENTRATION',
                    'message': f'{asset} weight {weight:.2%} exceeds limit {max_concentration:.2%}',
                    'severity': 'MEDIUM'
                })
                return True
        return False

    def calculate_real_time_var(self, positions: dict, prices: dict,
                                returns_history: pd.DataFrame) -> float:
        """Calculate real-time portfolio VaR"""
        # Calculate position values
        total_value = sum(
            positions.get(asset, 0) * prices.get(asset, 0)
            for asset in positions
        )

        if total_value == 0:
            return 0

        # Calculate weights
        weights = {
            asset: (positions.get(asset, 0) * prices.get(asset, 0)) / total_value
            for asset in positions
        }

        # Portfolio VaR
        port_var = PortfolioVaR(returns_history, weights)
        return port_var.variance_covariance_var(0.95)

    def generate_risk_report(self) -> dict:
        """Generate comprehensive risk report"""
        return {
            'alerts': self.alerts,
            'alert_count': len(self.alerts),
            'high_severity': sum(1 for a in self.alerts if a['severity'] == 'HIGH'),
            'timestamp': pd.Timestamp.now()
        }
```

---

## Integration with Trading Bot

```python
class RiskIntegration:
    """
    Integrate advanced risk models with trading engine
    """

    def __init__(self, engine, risk_config: dict):
        self.engine = engine
        self.config = risk_config

        # Initialize risk components
        self.var_calculator = None
        self.portfolio_optimizer = None
        self.risk_monitor = RealTimeRiskMonitor(risk_config)

    async def daily_risk_update(self, returns_history: pd.DataFrame):
        """Daily risk recalculation"""
        # Update VaR
        self.var_calculator = ValueAtRisk(returns_history.sum(axis=1))
        var_metrics = self.var_calculator.calculate_all(0.95, 1)

        # Check limits
        self.risk_monitor.check_var_breach(var_metrics['historical'])

        # Update optimal weights if multiple assets
        if len(returns_history.columns) > 1:
            self.portfolio_optimizer = PortfolioOptimizer(returns_history)
            optimal = self.portfolio_optimizer.mean_variance_optimize()

            return {
                'var_metrics': var_metrics,
                'optimal_weights': optimal['weights'],
                'current_sharpe': optimal['sharpe_ratio']
            }

        return {'var_metrics': var_metrics}

    def pre_trade_risk_check(self, signal, current_positions: dict,
                             prices: dict) -> tuple:
        """Pre-trade risk validation"""
        # Check concentration
        new_positions = current_positions.copy()
        new_positions[signal.symbol] = new_positions.get(signal.symbol, 0) + signal.size

        total_value = sum(abs(pos * prices.get(sym, 0))
                         for sym, pos in new_positions.items())

        if total_value == 0:
            return True, "OK"

        weights = {
            sym: abs(pos * prices.get(sym, 0)) / total_value
            for sym, pos in new_positions.items()
        }

        # Check concentration
        if self.risk_monitor.check_concentration(weights):
            return False, "Concentration limit exceeded"

        return True, "OK"
```

---

## Summary

Advanced risk models provide:

1. **VaR** - Maximum expected loss at confidence level
2. **Expected Shortfall** - Average loss in tail events
3. **Correlation Analysis** - Understand diversification
4. **Portfolio Optimization** - Optimal asset allocation
5. **Risk Budgeting** - Allocate risk, not just capital
6. **Real-Time Monitoring** - Continuous risk tracking

For prop firm trading, focus on:
- Daily VaR should be < daily drawdown limit
- Monitor correlation changes during volatility
- Use risk parity for multi-strategy allocation
- Implement real-time risk monitoring

---

*Next: [16-market-microstructure.md](./16-market-microstructure.md) - Deep dive into how markets work*
