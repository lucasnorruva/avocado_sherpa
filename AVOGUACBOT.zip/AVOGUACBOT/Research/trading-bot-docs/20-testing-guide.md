# Comprehensive Testing Guide

> **Testing strategies for trading bot development: unit tests, integration tests, and end-to-end validation.**

---

## Table of Contents

1. [Testing Philosophy](#testing-philosophy)
2. [Unit Testing](#unit-testing)
3. [Integration Testing](#integration-testing)
4. [End-to-End Testing](#end-to-end-testing)
5. [Backtesting as Testing](#backtesting-as-testing)
6. [Performance Testing](#performance-testing)
7. [Chaos Engineering](#chaos-engineering)
8. [Continuous Integration](#continuous-integration)

---

## Testing Philosophy

### Why Testing Matters in Trading

```python
"""
Trading bot testing is critical because:
1. Bugs cost real money
2. Edge cases happen in production
3. Market conditions change
4. Confidence enables better decisions

Testing pyramid for trading bots:
                    ┌───────────┐
                    │   E2E     │  (Few, expensive)
                   ─┼───────────┼─
                  / │Integration│ \
                 /  └───────────┘  \
                /                   \
               /  ┌───────────────┐  \
              /   │  Unit Tests   │   \  (Many, fast)
             /    └───────────────┘    \
            ─────────────────────────────
"""

# Test coverage goals
COVERAGE_TARGETS = {
    'core_engine': 95,      # Critical path - highest coverage
    'risk_management': 95,  # Safety critical
    'order_execution': 90,  # Money at risk
    'strategies': 85,       # Business logic
    'data_handling': 80,    # Data processing
    'utilities': 70,        # Helper functions
    'monitoring': 60        # Observability
}
```

### Test Configuration

```python
# conftest.py - Shared pytest fixtures

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock
from typing import Dict, List

@pytest.fixture
def sample_ohlcv_data() -> pd.DataFrame:
    """Generate sample OHLCV data for testing"""
    np.random.seed(42)
    dates = pd.date_range(start='2025-01-01', periods=1000, freq='1H')

    # Generate realistic price movement
    price = 50000  # Starting price (BTC-like)
    prices = [price]

    for _ in range(999):
        change = np.random.normal(0, 0.002)  # 0.2% std
        price = price * (1 + change)
        prices.append(price)

    prices = np.array(prices)

    return pd.DataFrame({
        'timestamp': dates,
        'open': prices * (1 + np.random.uniform(-0.001, 0.001, 1000)),
        'high': prices * (1 + np.random.uniform(0, 0.01, 1000)),
        'low': prices * (1 - np.random.uniform(0, 0.01, 1000)),
        'close': prices,
        'volume': np.random.uniform(100, 1000, 1000)
    }).set_index('timestamp')


@pytest.fixture
def sample_trades() -> List[Dict]:
    """Generate sample trade data"""
    return [
        {'timestamp': datetime.now() - timedelta(hours=i),
         'price': 50000 + np.random.uniform(-100, 100),
         'amount': np.random.uniform(0.1, 2.0),
         'side': np.random.choice(['buy', 'sell']),
         'trade_id': f'trade_{i}'}
        for i in range(100)
    ]


@pytest.fixture
def mock_exchange():
    """Mock exchange for testing"""
    exchange = AsyncMock()

    # Default responses
    exchange.fetch_ticker.return_value = {
        'symbol': 'BTC/USDT',
        'last': 50000,
        'bid': 49999,
        'ask': 50001,
        'volume': 1000000
    }

    exchange.fetch_balance.return_value = {
        'total': {'USDT': 100000, 'BTC': 0},
        'free': {'USDT': 100000, 'BTC': 0},
        'used': {'USDT': 0, 'BTC': 0}
    }

    exchange.create_order.return_value = {
        'id': 'order_123',
        'symbol': 'BTC/USDT',
        'status': 'open',
        'price': 50000,
        'amount': 1.0,
        'filled': 0
    }

    return exchange


@pytest.fixture
def risk_config() -> Dict:
    """Risk management configuration for testing"""
    return {
        'max_position_size': 0.1,  # 10% of account
        'max_daily_loss': 0.02,    # 2% daily loss
        'max_total_drawdown': 0.05,  # 5% total drawdown
        'risk_per_trade': 0.005,   # 0.5% per trade
        'max_open_positions': 3
    }


@pytest.fixture
def prop_firm_rules() -> Dict:
    """Prop firm rules for testing"""
    return {
        'daily_drawdown_limit': 0.05,  # 5%
        'total_drawdown_limit': 0.10,  # 10%
        'profit_target': 0.10,          # 10%
        'min_trading_days': 5,
        'max_position_size': 0.10
    }
```

---

## Unit Testing

### Testing Trading Strategies

```python
# tests/unit/test_strategies.py

import pytest
import pandas as pd
import numpy as np
from datetime import datetime
from strategies.momentum import MomentumStrategy
from strategies.mean_reversion import MeanReversionStrategy
from core.signals import Signal, SignalType


class TestMomentumStrategy:
    """Unit tests for momentum strategy"""

    @pytest.fixture
    def strategy(self):
        """Create strategy instance"""
        config = {
            'fast_period': 10,
            'slow_period': 20,
            'signal_threshold': 0.02
        }
        return MomentumStrategy(config)

    def test_initialization(self, strategy):
        """Test strategy initializes correctly"""
        assert strategy.fast_period == 10
        assert strategy.slow_period == 20
        assert strategy.signal_threshold == 0.02

    def test_requires_minimum_data(self, strategy, sample_ohlcv_data):
        """Test strategy requires minimum data for signals"""
        # Too few bars
        short_data = sample_ohlcv_data.head(10)
        signal = strategy.generate_signal(short_data)
        assert signal is None

    def test_generates_long_signal_on_bullish_crossover(self, strategy):
        """Test long signal generation on bullish crossover"""
        # Create data with clear bullish crossover
        data = self._create_bullish_crossover_data()
        signal = strategy.generate_signal(data)

        assert signal is not None
        assert signal.signal_type == SignalType.LONG
        assert signal.strength > 0

    def test_generates_short_signal_on_bearish_crossover(self, strategy):
        """Test short signal generation on bearish crossover"""
        data = self._create_bearish_crossover_data()
        signal = strategy.generate_signal(data)

        assert signal is not None
        assert signal.signal_type == SignalType.SHORT
        assert signal.strength > 0

    def test_no_signal_in_ranging_market(self, strategy):
        """Test no signal when MAs are flat"""
        data = self._create_ranging_data()
        signal = strategy.generate_signal(data)

        assert signal is None or signal.signal_type == SignalType.FLAT

    def test_signal_includes_required_fields(self, strategy):
        """Test signal has all required fields"""
        data = self._create_bullish_crossover_data()
        signal = strategy.generate_signal(data)

        assert hasattr(signal, 'signal_type')
        assert hasattr(signal, 'entry_price')
        assert hasattr(signal, 'stop_loss')
        assert hasattr(signal, 'take_profit')
        assert hasattr(signal, 'timestamp')

    def test_stop_loss_below_entry_for_long(self, strategy):
        """Test stop loss is below entry for long signals"""
        data = self._create_bullish_crossover_data()
        signal = strategy.generate_signal(data)

        if signal and signal.signal_type == SignalType.LONG:
            assert signal.stop_loss < signal.entry_price

    def test_stop_loss_above_entry_for_short(self, strategy):
        """Test stop loss is above entry for short signals"""
        data = self._create_bearish_crossover_data()
        signal = strategy.generate_signal(data)

        if signal and signal.signal_type == SignalType.SHORT:
            assert signal.stop_loss > signal.entry_price

    @pytest.mark.parametrize("fast,slow", [
        (5, 10), (10, 20), (20, 50), (50, 200)
    ])
    def test_different_period_combinations(self, fast, slow, sample_ohlcv_data):
        """Test strategy works with different period combinations"""
        config = {'fast_period': fast, 'slow_period': slow}
        strategy = MomentumStrategy(config)

        # Should not raise exception
        signal = strategy.generate_signal(sample_ohlcv_data)

        # Signal should be valid or None
        assert signal is None or isinstance(signal, Signal)

    def _create_bullish_crossover_data(self) -> pd.DataFrame:
        """Create data with bullish MA crossover"""
        dates = pd.date_range(start='2025-01-01', periods=50, freq='1H')
        # Price trending up
        prices = np.linspace(45000, 55000, 50) + np.random.normal(0, 100, 50)

        return pd.DataFrame({
            'open': prices * 0.999,
            'high': prices * 1.005,
            'low': prices * 0.995,
            'close': prices,
            'volume': np.random.uniform(100, 1000, 50)
        }, index=dates)

    def _create_bearish_crossover_data(self) -> pd.DataFrame:
        """Create data with bearish MA crossover"""
        dates = pd.date_range(start='2025-01-01', periods=50, freq='1H')
        # Price trending down
        prices = np.linspace(55000, 45000, 50) + np.random.normal(0, 100, 50)

        return pd.DataFrame({
            'open': prices * 1.001,
            'high': prices * 1.005,
            'low': prices * 0.995,
            'close': prices,
            'volume': np.random.uniform(100, 1000, 50)
        }, index=dates)

    def _create_ranging_data(self) -> pd.DataFrame:
        """Create ranging market data"""
        dates = pd.date_range(start='2025-01-01', periods=50, freq='1H')
        # Price oscillating around mean
        base_price = 50000
        prices = base_price + np.sin(np.linspace(0, 6*np.pi, 50)) * 500

        return pd.DataFrame({
            'open': prices * 0.999,
            'high': prices * 1.003,
            'low': prices * 0.997,
            'close': prices,
            'volume': np.random.uniform(100, 1000, 50)
        }, index=dates)


class TestMeanReversionStrategy:
    """Unit tests for mean reversion strategy"""

    @pytest.fixture
    def strategy(self):
        config = {
            'rsi_period': 14,
            'rsi_oversold': 30,
            'rsi_overbought': 70,
            'lookback_period': 20
        }
        return MeanReversionStrategy(config)

    def test_generates_long_on_oversold(self, strategy):
        """Test long signal when RSI oversold"""
        data = self._create_oversold_data()
        signal = strategy.generate_signal(data)

        assert signal is not None
        assert signal.signal_type == SignalType.LONG

    def test_generates_short_on_overbought(self, strategy):
        """Test short signal when RSI overbought"""
        data = self._create_overbought_data()
        signal = strategy.generate_signal(data)

        assert signal is not None
        assert signal.signal_type == SignalType.SHORT

    def test_no_signal_in_neutral_zone(self, strategy):
        """Test no signal when RSI in neutral zone"""
        data = self._create_neutral_rsi_data()
        signal = strategy.generate_signal(data)

        assert signal is None or signal.signal_type == SignalType.FLAT

    def _create_oversold_data(self) -> pd.DataFrame:
        """Create oversold condition (RSI < 30)"""
        dates = pd.date_range(start='2025-01-01', periods=50, freq='1H')
        # Strong downtrend
        prices = np.linspace(55000, 45000, 50)

        return pd.DataFrame({
            'open': prices * 1.001,
            'high': prices * 1.003,
            'low': prices * 0.995,
            'close': prices,
            'volume': np.random.uniform(100, 1000, 50)
        }, index=dates)

    def _create_overbought_data(self) -> pd.DataFrame:
        """Create overbought condition (RSI > 70)"""
        dates = pd.date_range(start='2025-01-01', periods=50, freq='1H')
        # Strong uptrend
        prices = np.linspace(45000, 55000, 50)

        return pd.DataFrame({
            'open': prices * 0.999,
            'high': prices * 1.005,
            'low': prices * 0.997,
            'close': prices,
            'volume': np.random.uniform(100, 1000, 50)
        }, index=dates)

    def _create_neutral_rsi_data(self) -> pd.DataFrame:
        """Create neutral RSI condition"""
        dates = pd.date_range(start='2025-01-01', periods=50, freq='1H')
        # Sideways movement
        prices = 50000 + np.random.normal(0, 200, 50)

        return pd.DataFrame({
            'open': prices * 0.999,
            'high': prices * 1.002,
            'low': prices * 0.998,
            'close': prices,
            'volume': np.random.uniform(100, 1000, 50)
        }, index=dates)
```

### Testing Risk Management

```python
# tests/unit/test_risk_management.py

import pytest
from decimal import Decimal
from risk.manager import RiskManager
from risk.position_sizer import PositionSizer
from risk.prop_firm_rules import PropFirmRulesEngine


class TestRiskManager:
    """Unit tests for risk manager"""

    @pytest.fixture
    def risk_manager(self, risk_config):
        return RiskManager(risk_config)

    def test_allows_trade_within_limits(self, risk_manager):
        """Test trade allowed when within risk limits"""
        can_trade = risk_manager.can_open_position(
            symbol='BTC/USDT',
            size=0.05,  # 5% of account
            account_balance=100000
        )
        assert can_trade is True

    def test_blocks_oversized_position(self, risk_manager):
        """Test trade blocked when position too large"""
        can_trade = risk_manager.can_open_position(
            symbol='BTC/USDT',
            size=0.15,  # 15% of account, exceeds 10% limit
            account_balance=100000
        )
        assert can_trade is False

    def test_blocks_after_daily_loss_limit(self, risk_manager):
        """Test trading blocked after hitting daily loss"""
        # Simulate hitting daily loss
        risk_manager.record_loss(2500)  # 2.5% loss

        can_trade = risk_manager.can_open_position(
            symbol='BTC/USDT',
            size=0.05,
            account_balance=100000
        )
        assert can_trade is False

    def test_tracks_drawdown_correctly(self, risk_manager):
        """Test drawdown calculation"""
        initial_balance = 100000
        risk_manager.set_high_water_mark(initial_balance)

        # Simulate losses
        risk_manager.update_equity(98000)  # 2% down
        assert risk_manager.current_drawdown == pytest.approx(0.02)

        risk_manager.update_equity(95000)  # 5% down
        assert risk_manager.current_drawdown == pytest.approx(0.05)

    def test_resets_daily_loss_on_new_day(self, risk_manager):
        """Test daily loss resets at day boundary"""
        risk_manager.record_loss(1000)
        assert risk_manager.daily_loss > 0

        risk_manager.reset_daily_stats()
        assert risk_manager.daily_loss == 0

    def test_max_positions_enforced(self, risk_manager):
        """Test maximum concurrent positions enforced"""
        # Open max positions
        for i in range(3):
            risk_manager.record_position_open(f'symbol_{i}')

        can_trade = risk_manager.can_open_position(
            symbol='NEW/USDT',
            size=0.05,
            account_balance=100000
        )
        assert can_trade is False

    def test_allows_position_close_when_blocked(self, risk_manager):
        """Test can still close positions when blocked"""
        risk_manager.record_loss(3000)  # Block new trades

        can_close = risk_manager.can_close_position('BTC/USDT')
        assert can_close is True


class TestPositionSizer:
    """Unit tests for position sizing"""

    @pytest.fixture
    def sizer(self, risk_config):
        return PositionSizer(risk_config)

    def test_fixed_risk_sizing(self, sizer):
        """Test fixed risk position sizing"""
        size = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            stop_loss=49000,
            method='fixed_risk'
        )

        # Risk per trade is 0.5% = $500
        # Risk per unit = $1000
        # Expected size = 0.5 units
        assert size == pytest.approx(0.5, rel=0.01)

    def test_atr_based_sizing(self, sizer, sample_ohlcv_data):
        """Test ATR-based position sizing"""
        size = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            atr=500,
            atr_multiplier=2.0,
            method='atr'
        )

        # Should adjust based on ATR
        assert size > 0
        assert size < 0.1 * 100000 / 50000  # Below max position

    def test_kelly_criterion_sizing(self, sizer):
        """Test Kelly criterion position sizing"""
        size = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            win_rate=0.55,
            avg_win_loss_ratio=1.5,
            method='kelly'
        )

        # Kelly should give reasonable position
        assert 0 < size < 0.5  # Between 0 and 50%

    def test_fractional_kelly(self, sizer):
        """Test fractional Kelly for safety"""
        full_kelly = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            win_rate=0.55,
            avg_win_loss_ratio=1.5,
            method='kelly',
            kelly_fraction=1.0
        )

        half_kelly = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            win_rate=0.55,
            avg_win_loss_ratio=1.5,
            method='kelly',
            kelly_fraction=0.5
        )

        assert half_kelly == pytest.approx(full_kelly * 0.5, rel=0.01)

    def test_respects_maximum_position(self, sizer):
        """Test position size respects maximum"""
        size = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            stop_loss=30000,  # Very wide stop would give huge position
            method='fixed_risk'
        )

        max_position = 0.1 * 100000 / 50000  # 10% of account
        assert size <= max_position

    def test_returns_zero_for_invalid_stop(self, sizer):
        """Test returns zero when stop loss invalid"""
        # Stop above entry for long
        size = sizer.calculate_position_size(
            account_balance=100000,
            entry_price=50000,
            stop_loss=51000,  # Invalid for long
            method='fixed_risk',
            direction='long'
        )
        assert size == 0


class TestPropFirmRulesEngine:
    """Unit tests for prop firm rules"""

    @pytest.fixture
    def rules_engine(self, prop_firm_rules):
        return PropFirmRulesEngine(prop_firm_rules)

    def test_tracks_daily_drawdown(self, rules_engine):
        """Test daily drawdown tracking"""
        rules_engine.update_balance(100000)  # Starting balance
        rules_engine.start_new_day()

        rules_engine.update_balance(97000)  # 3% down

        assert rules_engine.daily_drawdown == pytest.approx(0.03)
        assert rules_engine.is_daily_limit_breached() is False

    def test_detects_daily_limit_breach(self, rules_engine):
        """Test detection of daily limit breach"""
        rules_engine.update_balance(100000)
        rules_engine.start_new_day()

        rules_engine.update_balance(94500)  # 5.5% down

        assert rules_engine.is_daily_limit_breached() is True

    def test_tracks_total_drawdown(self, rules_engine):
        """Test total drawdown from high water mark"""
        rules_engine.set_initial_balance(100000)

        # Simulate equity curve
        rules_engine.update_balance(105000)  # New HWM
        rules_engine.update_balance(98000)   # Down from HWM

        expected_drawdown = (105000 - 98000) / 105000
        assert rules_engine.total_drawdown == pytest.approx(expected_drawdown)

    def test_detects_total_limit_breach(self, rules_engine):
        """Test detection of total drawdown limit breach"""
        rules_engine.set_initial_balance(100000)

        rules_engine.update_balance(89000)  # 11% down

        assert rules_engine.is_total_limit_breached() is True

    def test_tracks_profit_target(self, rules_engine):
        """Test profit target tracking"""
        rules_engine.set_initial_balance(100000)

        rules_engine.update_balance(108000)
        assert rules_engine.is_profit_target_reached() is False

        rules_engine.update_balance(111000)  # 11% profit
        assert rules_engine.is_profit_target_reached() is True

    def test_tracks_trading_days(self, rules_engine):
        """Test minimum trading days tracking"""
        rules_engine.set_initial_balance(100000)

        for i in range(5):
            rules_engine.record_trading_day()

        assert rules_engine.trading_days >= 5
        assert rules_engine.has_minimum_trading_days() is True

    def test_overall_status_check(self, rules_engine):
        """Test overall challenge status"""
        rules_engine.set_initial_balance(100000)

        status = rules_engine.get_challenge_status()

        assert 'daily_drawdown' in status
        assert 'total_drawdown' in status
        assert 'profit' in status
        assert 'trading_days' in status
        assert 'can_trade' in status
```

### Testing Order Execution

```python
# tests/unit/test_order_execution.py

import pytest
from unittest.mock import AsyncMock, patch
from datetime import datetime
from core.order_manager import OrderManager
from core.orders import Order, OrderType, OrderSide, OrderStatus


class TestOrderManager:
    """Unit tests for order manager"""

    @pytest.fixture
    def order_manager(self, mock_exchange):
        return OrderManager(mock_exchange)

    @pytest.mark.asyncio
    async def test_creates_market_order(self, order_manager, mock_exchange):
        """Test market order creation"""
        order = await order_manager.create_order(
            symbol='BTC/USDT',
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            amount=1.0
        )

        mock_exchange.create_order.assert_called_once()
        assert order is not None
        assert order.order_id == 'order_123'

    @pytest.mark.asyncio
    async def test_creates_limit_order(self, order_manager, mock_exchange):
        """Test limit order creation"""
        order = await order_manager.create_order(
            symbol='BTC/USDT',
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            amount=1.0,
            price=49000
        )

        args, kwargs = mock_exchange.create_order.call_args
        assert kwargs.get('price') == 49000 or args[4] == 49000

    @pytest.mark.asyncio
    async def test_handles_order_rejection(self, order_manager, mock_exchange):
        """Test handling of order rejection"""
        mock_exchange.create_order.side_effect = Exception("Insufficient balance")

        with pytest.raises(Exception) as exc_info:
            await order_manager.create_order(
                symbol='BTC/USDT',
                side=OrderSide.BUY,
                order_type=OrderType.MARKET,
                amount=100.0
            )

        assert "Insufficient balance" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_cancels_order(self, order_manager, mock_exchange):
        """Test order cancellation"""
        mock_exchange.cancel_order.return_value = {'status': 'canceled'}

        result = await order_manager.cancel_order('order_123', 'BTC/USDT')

        mock_exchange.cancel_order.assert_called_once_with('order_123', 'BTC/USDT')
        assert result['status'] == 'canceled'

    @pytest.mark.asyncio
    async def test_fetches_order_status(self, order_manager, mock_exchange):
        """Test fetching order status"""
        mock_exchange.fetch_order.return_value = {
            'id': 'order_123',
            'status': 'filled',
            'filled': 1.0
        }

        status = await order_manager.get_order_status('order_123', 'BTC/USDT')

        assert status['status'] == 'filled'
        assert status['filled'] == 1.0

    @pytest.mark.asyncio
    async def test_tracks_open_orders(self, order_manager, mock_exchange):
        """Test tracking of open orders"""
        await order_manager.create_order(
            symbol='BTC/USDT',
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            amount=1.0,
            price=49000
        )

        open_orders = order_manager.get_open_orders('BTC/USDT')
        assert len(open_orders) == 1

    @pytest.mark.asyncio
    async def test_validates_order_parameters(self, order_manager):
        """Test order parameter validation"""
        # Negative amount
        with pytest.raises(ValueError):
            await order_manager.create_order(
                symbol='BTC/USDT',
                side=OrderSide.BUY,
                order_type=OrderType.MARKET,
                amount=-1.0
            )

        # Missing price for limit order
        with pytest.raises(ValueError):
            await order_manager.create_order(
                symbol='BTC/USDT',
                side=OrderSide.BUY,
                order_type=OrderType.LIMIT,
                amount=1.0
                # price missing
            )

    @pytest.mark.asyncio
    async def test_retry_on_transient_error(self, order_manager, mock_exchange):
        """Test retry logic on transient errors"""
        # Fail twice, succeed third time
        mock_exchange.create_order.side_effect = [
            Exception("Network error"),
            Exception("Timeout"),
            {'id': 'order_123', 'status': 'open'}
        ]

        order = await order_manager.create_order(
            symbol='BTC/USDT',
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            amount=1.0,
            max_retries=3
        )

        assert order is not None
        assert mock_exchange.create_order.call_count == 3
```

---

## Integration Testing

### Exchange Integration Tests

```python
# tests/integration/test_exchange_integration.py

import pytest
import asyncio
from datetime import datetime, timedelta
from exchange.connector import ExchangeConnector


@pytest.mark.integration
class TestExchangeIntegration:
    """Integration tests with exchange testnet"""

    @pytest.fixture
    async def exchange(self):
        """Create exchange connection to testnet"""
        connector = ExchangeConnector(
            exchange_id='binance',
            testnet=True,
            api_key='testnet_api_key',
            api_secret='testnet_api_secret'
        )
        await connector.connect()
        yield connector
        await connector.close()

    @pytest.mark.asyncio
    async def test_fetches_markets(self, exchange):
        """Test fetching market list"""
        markets = await exchange.fetch_markets()

        assert len(markets) > 0
        assert 'BTC/USDT' in [m['symbol'] for m in markets]

    @pytest.mark.asyncio
    async def test_fetches_ticker(self, exchange):
        """Test fetching ticker data"""
        ticker = await exchange.fetch_ticker('BTC/USDT')

        assert 'last' in ticker
        assert 'bid' in ticker
        assert 'ask' in ticker
        assert ticker['last'] > 0

    @pytest.mark.asyncio
    async def test_fetches_ohlcv(self, exchange):
        """Test fetching OHLCV data"""
        ohlcv = await exchange.fetch_ohlcv(
            'BTC/USDT',
            timeframe='1h',
            limit=100
        )

        assert len(ohlcv) == 100
        for candle in ohlcv:
            assert len(candle) == 6  # OHLCV + timestamp
            assert candle[2] >= candle[3]  # High >= Low

    @pytest.mark.asyncio
    async def test_fetches_order_book(self, exchange):
        """Test fetching order book"""
        orderbook = await exchange.fetch_order_book('BTC/USDT', limit=10)

        assert 'bids' in orderbook
        assert 'asks' in orderbook
        assert len(orderbook['bids']) <= 10
        assert len(orderbook['asks']) <= 10

        # Bids should be below asks
        if orderbook['bids'] and orderbook['asks']:
            assert orderbook['bids'][0][0] < orderbook['asks'][0][0]

    @pytest.mark.asyncio
    async def test_fetches_balance(self, exchange):
        """Test fetching account balance"""
        balance = await exchange.fetch_balance()

        assert 'total' in balance
        assert 'free' in balance
        assert 'USDT' in balance['total']

    @pytest.mark.asyncio
    async def test_creates_and_cancels_order(self, exchange):
        """Test order lifecycle on testnet"""
        # Create limit order far from market
        ticker = await exchange.fetch_ticker('BTC/USDT')
        limit_price = ticker['bid'] * 0.9  # 10% below market

        order = await exchange.create_order(
            symbol='BTC/USDT',
            type='limit',
            side='buy',
            amount=0.001,
            price=limit_price
        )

        assert order['status'] == 'open'
        order_id = order['id']

        # Cancel order
        await asyncio.sleep(1)
        cancel_result = await exchange.cancel_order(order_id, 'BTC/USDT')

        assert cancel_result is not None

        # Verify canceled
        order_status = await exchange.fetch_order(order_id, 'BTC/USDT')
        assert order_status['status'] == 'canceled'

    @pytest.mark.asyncio
    async def test_handles_rate_limiting(self, exchange):
        """Test rate limiting handling"""
        # Make many requests quickly
        tasks = []
        for _ in range(20):
            tasks.append(exchange.fetch_ticker('BTC/USDT'))

        # Should complete without rate limit errors
        results = await asyncio.gather(*tasks, return_exceptions=True)

        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0


@pytest.mark.integration
class TestDatabaseIntegration:
    """Integration tests with database"""

    @pytest.fixture
    async def db(self):
        """Create database connection"""
        from storage.timescale import TimescaleDBStorage

        db = TimescaleDBStorage(
            host='localhost',
            port=5432,
            database='trading_test',
            user='test_user',
            password='test_password'
        )
        await db.connect()
        await db.initialize_schema()
        yield db
        await db.cleanup_test_data()
        await db.close()

    @pytest.mark.asyncio
    async def test_inserts_ohlcv(self, db, sample_ohlcv_data):
        """Test OHLCV insertion"""
        data = sample_ohlcv_data.reset_index().to_dict('records')

        await db.insert_ohlcv(data[:100])

        # Verify inserted
        result = await db.query_ohlcv(
            symbol='BTC/USDT',
            exchange='test',
            timeframe='1h',
            start=data[0]['timestamp'],
            end=data[99]['timestamp']
        )

        assert len(result) == 100

    @pytest.mark.asyncio
    async def test_queries_time_range(self, db, sample_ohlcv_data):
        """Test time range queries"""
        data = sample_ohlcv_data.reset_index().to_dict('records')
        await db.insert_ohlcv(data)

        # Query subset
        start = data[10]['timestamp']
        end = data[20]['timestamp']

        result = await db.query_ohlcv(
            symbol='BTC/USDT',
            exchange='test',
            timeframe='1h',
            start=start,
            end=end
        )

        assert len(result) == 11

    @pytest.mark.asyncio
    async def test_handles_duplicates(self, db, sample_ohlcv_data):
        """Test duplicate handling"""
        data = sample_ohlcv_data.reset_index().to_dict('records')[:10]

        # Insert twice
        await db.insert_ohlcv(data)
        await db.insert_ohlcv(data)

        # Should not have duplicates
        result = await db.query_ohlcv(
            symbol='BTC/USDT',
            exchange='test',
            timeframe='1h',
            start=data[0]['timestamp'],
            end=data[9]['timestamp']
        )

        assert len(result) == 10
```

### Pipeline Integration Tests

```python
# tests/integration/test_pipeline_integration.py

import pytest
import asyncio
from datetime import datetime, timedelta
from pipelines.ohlcv_pipeline import OHLCVPipeline
from pipelines.trade_pipeline import TradePipeline


@pytest.mark.integration
class TestPipelineIntegration:
    """Integration tests for data pipelines"""

    @pytest.fixture
    async def ohlcv_pipeline(self, mock_exchange, db, cache):
        """Create OHLCV pipeline"""
        config = {
            'symbols': ['BTC/USDT', 'ETH/USDT'],
            'timeframes': ['1h'],
            'batch_size': 100
        }
        pipeline = OHLCVPipeline(config, mock_exchange, db, cache)
        yield pipeline

    @pytest.mark.asyncio
    async def test_full_etl_cycle(self, ohlcv_pipeline):
        """Test complete ETL cycle"""
        # Run pipeline
        await ohlcv_pipeline.run()

        # Verify data in storage
        result = await ohlcv_pipeline.storage.query_ohlcv(
            symbol='BTC/USDT',
            exchange='test',
            timeframe='1h',
            start=datetime.now() - timedelta(days=1),
            end=datetime.now()
        )

        assert len(result) > 0

    @pytest.mark.asyncio
    async def test_pipeline_handles_gaps(self, ohlcv_pipeline):
        """Test pipeline fills data gaps"""
        # Insert data with gap
        old_data = [...]  # Data from 2 days ago
        await ohlcv_pipeline.storage.insert_ohlcv(old_data)

        # Run pipeline
        await ohlcv_pipeline.run()

        # Gap should be filled
        result = await ohlcv_pipeline.storage.query_ohlcv(
            symbol='BTC/USDT',
            exchange='test',
            timeframe='1h',
            start=datetime.now() - timedelta(days=2),
            end=datetime.now()
        )

        # Check for continuity
        timestamps = [r['timestamp'] for r in result]
        for i in range(1, len(timestamps)):
            diff = (timestamps[i] - timestamps[i-1]).total_seconds()
            assert diff <= 3600 * 2  # Max 2 hour gap allowed

    @pytest.mark.asyncio
    async def test_pipeline_recovers_from_errors(self, ohlcv_pipeline, mock_exchange):
        """Test pipeline recovery from errors"""
        # Make exchange fail intermittently
        call_count = 0
        original_fetch = mock_exchange.fetch_ohlcv

        async def failing_fetch(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count % 3 == 0:
                raise Exception("Simulated network error")
            return await original_fetch(*args, **kwargs)

        mock_exchange.fetch_ohlcv = failing_fetch

        # Pipeline should still complete
        await ohlcv_pipeline.run()

        assert ohlcv_pipeline.metrics.successful_runs > 0
```

---

## End-to-End Testing

### Full System E2E Tests

```python
# tests/e2e/test_trading_system.py

import pytest
import asyncio
from datetime import datetime, timedelta
from core.engine import TradingEngine
from strategies.momentum import MomentumStrategy


@pytest.mark.e2e
class TestTradingSystemE2E:
    """End-to-end tests for complete trading system"""

    @pytest.fixture
    async def trading_system(self, mock_exchange, risk_config, prop_firm_rules):
        """Create complete trading system"""
        config = {
            'exchange': mock_exchange,
            'symbols': ['BTC/USDT'],
            'strategy': MomentumStrategy({'fast_period': 10, 'slow_period': 20}),
            'risk_config': risk_config,
            'prop_firm_rules': prop_firm_rules,
            'paper_trading': True
        }
        engine = TradingEngine(config)
        await engine.initialize()
        yield engine
        await engine.shutdown()

    @pytest.mark.asyncio
    async def test_complete_trade_lifecycle(self, trading_system, mock_exchange):
        """Test complete trade from signal to close"""
        # Setup: Make market conditions generate signal
        mock_exchange.fetch_ohlcv.return_value = self._create_bullish_data()

        # Run one cycle
        await trading_system.run_cycle()

        # Check signal generated
        signals = trading_system.get_recent_signals()
        assert len(signals) > 0

        # Check position opened
        positions = trading_system.get_open_positions()
        assert len(positions) > 0

        # Simulate profit taking
        mock_exchange.fetch_ticker.return_value = {'last': 55000}  # Price up

        # Run another cycle
        await trading_system.run_cycle()

        # Check position closed
        closed = trading_system.get_closed_trades()
        assert len(closed) > 0
        assert closed[-1]['pnl'] > 0

    @pytest.mark.asyncio
    async def test_risk_limits_enforced(self, trading_system, mock_exchange):
        """Test risk limits are enforced in live trading"""
        # Setup losing trades
        mock_exchange.fetch_ohlcv.return_value = self._create_bullish_data()

        # Open position
        await trading_system.run_cycle()

        # Simulate losses hitting daily limit
        for _ in range(5):
            trading_system.record_loss(0.5)  # 0.5% losses

        # Try to open new position
        await trading_system.run_cycle()

        # Should not open new position
        assert trading_system.is_trading_blocked()

    @pytest.mark.asyncio
    async def test_prop_firm_compliance(self, trading_system):
        """Test prop firm rules compliance"""
        # Check daily drawdown tracking
        trading_system.update_balance(97000)  # 3% down

        status = trading_system.get_prop_firm_status()

        assert status['daily_drawdown'] == pytest.approx(0.03)
        assert status['daily_drawdown_remaining'] == pytest.approx(0.02)
        assert status['can_trade'] is True

    @pytest.mark.asyncio
    async def test_graceful_shutdown(self, trading_system, mock_exchange):
        """Test graceful shutdown with open positions"""
        # Open position
        mock_exchange.fetch_ohlcv.return_value = self._create_bullish_data()
        await trading_system.run_cycle()

        assert len(trading_system.get_open_positions()) > 0

        # Initiate shutdown
        await trading_system.shutdown(close_positions=True)

        # All positions should be closed
        assert len(trading_system.get_open_positions()) == 0

        # State should be saved
        assert trading_system.state_saved is True

    @pytest.mark.asyncio
    async def test_recovery_from_crash(self, trading_system, mock_exchange):
        """Test system recovery after crash"""
        # Setup: Open position and save state
        mock_exchange.fetch_ohlcv.return_value = self._create_bullish_data()
        await trading_system.run_cycle()

        position = trading_system.get_open_positions()[0]
        await trading_system.save_state()

        # Simulate crash by creating new engine
        new_engine = TradingEngine(trading_system.config)
        await new_engine.initialize()
        await new_engine.restore_state()

        # Position should be restored
        restored_positions = new_engine.get_open_positions()
        assert len(restored_positions) == 1
        assert restored_positions[0]['symbol'] == position['symbol']

    def _create_bullish_data(self):
        """Create bullish OHLCV data"""
        import numpy as np
        return [
            [int(datetime.now().timestamp() * 1000) - i * 3600000,
             50000 + i * 100, 50100 + i * 100, 49900 + i * 100,
             50050 + i * 100, 1000]
            for i in range(100)
        ][::-1]


@pytest.mark.e2e
class TestMultiSymbolE2E:
    """E2E tests for multi-symbol trading"""

    @pytest.mark.asyncio
    async def test_trades_multiple_symbols(self, trading_system, mock_exchange):
        """Test trading across multiple symbols"""
        trading_system.config['symbols'] = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT']

        # Run several cycles
        for _ in range(10):
            await trading_system.run_cycle()
            await asyncio.sleep(0.1)

        # Should have trades in multiple symbols
        trades = trading_system.get_all_trades()
        symbols_traded = set(t['symbol'] for t in trades)

        assert len(symbols_traded) >= 2

    @pytest.mark.asyncio
    async def test_correlation_limits(self, trading_system):
        """Test correlation-based position limits"""
        # Try to open highly correlated positions
        await trading_system.open_position('BTC/USDT', 'long', 0.05)
        await trading_system.open_position('ETH/USDT', 'long', 0.05)

        # Third correlated position should be limited
        can_open = await trading_system.can_open_position('SOL/USDT', 'long', 0.05)

        # May be blocked due to correlation limits
        # Implementation dependent
```

---

## Backtesting as Testing

### Strategy Validation Through Backtesting

```python
# tests/backtest/test_strategy_validation.py

import pytest
import numpy as np
from datetime import datetime, timedelta
from backtesting.engine import BacktestEngine
from strategies.momentum import MomentumStrategy


class TestStrategyValidation:
    """Validate strategies through backtesting"""

    @pytest.fixture
    def backtest_engine(self, sample_ohlcv_data):
        """Create backtest engine with sample data"""
        return BacktestEngine(
            data=sample_ohlcv_data,
            initial_capital=100000,
            commission=0.001
        )

    def test_strategy_profitability(self, backtest_engine):
        """Test strategy is profitable on historical data"""
        strategy = MomentumStrategy({'fast_period': 10, 'slow_period': 20})
        results = backtest_engine.run(strategy)

        # Minimum profitability threshold
        assert results['total_return'] > 0
        assert results['profit_factor'] > 1.0

    def test_strategy_risk_metrics(self, backtest_engine):
        """Test strategy risk metrics are acceptable"""
        strategy = MomentumStrategy({'fast_period': 10, 'slow_period': 20})
        results = backtest_engine.run(strategy)

        # Risk metrics within bounds
        assert results['max_drawdown'] < 0.20  # Max 20% drawdown
        assert results['sharpe_ratio'] > 0.5

    def test_strategy_consistency(self, backtest_engine):
        """Test strategy performs consistently across periods"""
        strategy = MomentumStrategy({'fast_period': 10, 'slow_period': 20})

        # Split data into periods
        monthly_results = backtest_engine.run_monthly(strategy)

        # Count profitable months
        profitable_months = sum(1 for r in monthly_results if r['return'] > 0)
        total_months = len(monthly_results)

        # At least 50% profitable months
        assert profitable_months / total_months >= 0.5

    def test_strategy_not_overfitted(self, backtest_engine):
        """Test strategy is not overfitted"""
        strategy = MomentumStrategy({'fast_period': 10, 'slow_period': 20})

        # In-sample vs out-of-sample
        is_results = backtest_engine.run(strategy, end_date='2025-06-01')
        oos_results = backtest_engine.run(strategy, start_date='2025-06-01')

        # OOS performance should be at least 50% of IS
        performance_ratio = oos_results['sharpe_ratio'] / is_results['sharpe_ratio']
        assert performance_ratio >= 0.5

    def test_walk_forward_validation(self, backtest_engine):
        """Test strategy with walk-forward optimization"""
        from backtesting.optimization import WalkForwardOptimizer

        optimizer = WalkForwardOptimizer(
            strategy_class=MomentumStrategy,
            param_space={
                'fast_period': range(5, 20),
                'slow_period': range(20, 50)
            }
        )

        wf_results = optimizer.run(
            data=backtest_engine.data,
            train_period=60,
            test_period=20,
            windows=5
        )

        # Walk-forward should be profitable
        assert wf_results['total_return'] > 0
        assert wf_results['avg_test_sharpe'] > 0.3

    @pytest.mark.parametrize("market_regime", [
        'trending_up', 'trending_down', 'ranging', 'high_volatility'
    ])
    def test_strategy_in_different_regimes(self, market_regime):
        """Test strategy performance in different market regimes"""
        data = self._generate_regime_data(market_regime)
        engine = BacktestEngine(data=data, initial_capital=100000)

        strategy = MomentumStrategy({'fast_period': 10, 'slow_period': 20})
        results = engine.run(strategy)

        # Strategy should not blow up in any regime
        assert results['max_drawdown'] < 0.30
        assert results['total_return'] > -0.20

    def _generate_regime_data(self, regime: str) -> pd.DataFrame:
        """Generate data for specific market regime"""
        np.random.seed(42)
        n = 500

        if regime == 'trending_up':
            returns = np.random.normal(0.001, 0.01, n)  # Positive drift
        elif regime == 'trending_down':
            returns = np.random.normal(-0.001, 0.01, n)  # Negative drift
        elif regime == 'ranging':
            returns = np.random.normal(0, 0.005, n)  # Low volatility, no drift
        elif regime == 'high_volatility':
            returns = np.random.normal(0, 0.03, n)  # High volatility

        prices = 50000 * np.cumprod(1 + returns)
        dates = pd.date_range(start='2025-01-01', periods=n, freq='1H')

        return pd.DataFrame({
            'open': prices * 0.999,
            'high': prices * 1.005,
            'low': prices * 0.995,
            'close': prices,
            'volume': np.random.uniform(100, 1000, n)
        }, index=dates)
```

---

## Performance Testing

### Load and Performance Tests

```python
# tests/performance/test_performance.py

import pytest
import asyncio
import time
import numpy as np
from datetime import datetime


@pytest.mark.performance
class TestPerformance:
    """Performance tests for critical paths"""

    def test_strategy_signal_generation_speed(self, sample_ohlcv_data):
        """Test signal generation performance"""
        from strategies.momentum import MomentumStrategy

        strategy = MomentumStrategy({'fast_period': 10, 'slow_period': 20})

        # Warm up
        for _ in range(10):
            strategy.generate_signal(sample_ohlcv_data)

        # Measure
        times = []
        for _ in range(100):
            start = time.perf_counter()
            strategy.generate_signal(sample_ohlcv_data)
            times.append(time.perf_counter() - start)

        avg_time = np.mean(times)
        p99_time = np.percentile(times, 99)

        # Performance requirements
        assert avg_time < 0.01  # < 10ms average
        assert p99_time < 0.05  # < 50ms p99

    def test_risk_calculation_speed(self, risk_config, sample_ohlcv_data):
        """Test risk calculation performance"""
        from risk.manager import RiskManager

        manager = RiskManager(risk_config)

        times = []
        for _ in range(1000):
            start = time.perf_counter()
            manager.calculate_position_risk(
                entry_price=50000,
                stop_loss=49000,
                position_size=1.0,
                current_price=50500
            )
            times.append(time.perf_counter() - start)

        avg_time = np.mean(times)

        # Should be very fast
        assert avg_time < 0.001  # < 1ms

    def test_indicator_calculation_speed(self, sample_ohlcv_data):
        """Test indicator calculation performance"""
        from indicators.technical import TechnicalIndicators

        indicators = TechnicalIndicators()

        # Test various indicators
        indicator_times = {}

        for indicator in ['rsi', 'macd', 'bollinger', 'atr']:
            times = []
            for _ in range(100):
                start = time.perf_counter()
                getattr(indicators, f'calculate_{indicator}')(sample_ohlcv_data)
                times.append(time.perf_counter() - start)

            indicator_times[indicator] = np.mean(times)

        # All indicators should be < 10ms
        for indicator, avg_time in indicator_times.items():
            assert avg_time < 0.01, f"{indicator} too slow: {avg_time:.3f}s"

    @pytest.mark.asyncio
    async def test_order_execution_latency(self, mock_exchange):
        """Test order execution latency"""
        from core.order_manager import OrderManager

        manager = OrderManager(mock_exchange)

        times = []
        for _ in range(50):
            start = time.perf_counter()
            await manager.create_order(
                symbol='BTC/USDT',
                side='buy',
                order_type='market',
                amount=0.01
            )
            times.append(time.perf_counter() - start)

        avg_time = np.mean(times)
        p99_time = np.percentile(times, 99)

        # Order execution requirements
        assert avg_time < 0.1  # < 100ms average
        assert p99_time < 0.5  # < 500ms p99

    def test_data_processing_throughput(self, sample_ohlcv_data):
        """Test data processing throughput"""
        from data.processor import DataProcessor

        processor = DataProcessor()

        # Prepare large dataset
        large_data = pd.concat([sample_ohlcv_data] * 100)

        start = time.perf_counter()
        processed = processor.process(large_data)
        elapsed = time.perf_counter() - start

        records_per_second = len(large_data) / elapsed

        # Should process at least 10k records/second
        assert records_per_second > 10000

    @pytest.mark.asyncio
    async def test_concurrent_trading_performance(self, mock_exchange):
        """Test performance under concurrent load"""
        from core.engine import TradingEngine

        engines = []
        for i in range(5):
            engine = TradingEngine({'symbol': f'SYMBOL_{i}/USDT'})
            engines.append(engine)

        # Run all engines concurrently
        start = time.perf_counter()

        async def run_engine(engine):
            for _ in range(10):
                await engine.run_cycle()

        await asyncio.gather(*[run_engine(e) for e in engines])

        elapsed = time.perf_counter() - start

        # 50 cycles across 5 engines should complete quickly
        assert elapsed < 5.0  # < 5 seconds


@pytest.mark.performance
class TestMemoryUsage:
    """Memory usage tests"""

    def test_no_memory_leak_in_trading_loop(self):
        """Test for memory leaks in main trading loop"""
        import tracemalloc

        tracemalloc.start()

        # Simulate trading loop
        for _ in range(1000):
            # Typical trading loop operations
            data = np.random.random((1000, 6))
            df = pd.DataFrame(data)
            result = df.mean()
            del data, df, result

        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        # Memory should not grow significantly
        assert current < 100 * 1024 * 1024  # < 100MB

    def test_indicator_memory_efficiency(self, sample_ohlcv_data):
        """Test indicator memory efficiency"""
        import tracemalloc

        tracemalloc.start()

        from indicators.technical import TechnicalIndicators
        indicators = TechnicalIndicators()

        # Calculate many indicators
        for _ in range(100):
            indicators.calculate_all(sample_ohlcv_data)

        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        # Should not accumulate memory
        assert current < 50 * 1024 * 1024  # < 50MB
```

---

## Chaos Engineering

### Resilience Testing

```python
# tests/chaos/test_resilience.py

import pytest
import asyncio
from unittest.mock import patch, AsyncMock
import random


@pytest.mark.chaos
class TestChaosEngineering:
    """Chaos engineering tests for resilience"""

    @pytest.mark.asyncio
    async def test_survives_exchange_disconnection(self, trading_system, mock_exchange):
        """Test system survives exchange disconnection"""
        # Start trading
        task = asyncio.create_task(trading_system.run())

        await asyncio.sleep(1)

        # Simulate disconnection
        mock_exchange.fetch_ticker.side_effect = ConnectionError("Connection lost")

        await asyncio.sleep(2)

        # Restore connection
        mock_exchange.fetch_ticker.side_effect = None
        mock_exchange.fetch_ticker.return_value = {'last': 50000}

        await asyncio.sleep(2)

        # System should recover
        assert trading_system.is_running()
        assert trading_system.connection_errors < 5

        task.cancel()

    @pytest.mark.asyncio
    async def test_handles_partial_fills(self, trading_system, mock_exchange):
        """Test handling of partial order fills"""
        # Mock partial fill
        mock_exchange.create_order.return_value = {
            'id': 'order_123',
            'status': 'open',
            'filled': 0.5,  # Half filled
            'remaining': 0.5
        }

        await trading_system.open_position('BTC/USDT', 'long', 1.0)

        # System should handle partial fill
        position = trading_system.get_position('BTC/USDT')
        assert position['size'] == 0.5

    @pytest.mark.asyncio
    async def test_survives_data_corruption(self, trading_system, mock_exchange):
        """Test system handles corrupted market data"""
        # Return corrupted data
        mock_exchange.fetch_ohlcv.return_value = [
            [None, 50000, None, 49000, 'invalid', 1000],  # Bad data
            [int(datetime.now().timestamp() * 1000), -100, 50000, 49000, 50000, 1000],  # Negative price
        ]

        # Should not crash
        await trading_system.run_cycle()

        # Should log warnings but continue
        assert trading_system.is_running()

    @pytest.mark.asyncio
    async def test_handles_rapid_price_movements(self, trading_system, mock_exchange):
        """Test handling of flash crash scenario"""
        # Simulate flash crash
        prices = [50000, 45000, 40000, 35000, 40000, 45000, 50000]

        for price in prices:
            mock_exchange.fetch_ticker.return_value = {'last': price}
            await trading_system.run_cycle()
            await asyncio.sleep(0.1)

        # Risk management should have kicked in
        # Check position sizes are appropriate
        assert trading_system.get_current_exposure() < 0.5

    @pytest.mark.asyncio
    async def test_recovers_from_database_failure(self, trading_system, db):
        """Test recovery from database failure"""
        # Simulate DB failure
        with patch.object(db, 'query_ohlcv', side_effect=Exception("DB Error")):
            # Should use cached data or skip
            await trading_system.run_cycle()

        # System should continue when DB recovers
        await trading_system.run_cycle()
        assert trading_system.is_running()

    @pytest.mark.asyncio
    async def test_handles_out_of_order_events(self, trading_system):
        """Test handling of out-of-order market events"""
        events = [
            {'timestamp': 3, 'price': 50300},
            {'timestamp': 1, 'price': 50100},  # Out of order
            {'timestamp': 4, 'price': 50400},
            {'timestamp': 2, 'price': 50200},  # Out of order
        ]

        for event in events:
            await trading_system.process_market_event(event)

        # Events should be processed correctly
        last_price = trading_system.get_last_price('BTC/USDT')
        assert last_price == 50400

    @pytest.mark.asyncio
    async def test_handles_duplicate_events(self, trading_system):
        """Test handling of duplicate market events"""
        event = {'timestamp': 1, 'price': 50000, 'event_id': 'evt_123'}

        # Process same event twice
        await trading_system.process_market_event(event)
        await trading_system.process_market_event(event)

        # Should only process once
        assert trading_system.processed_event_count == 1


@pytest.mark.chaos
class TestRandomFailures:
    """Random failure injection tests"""

    @pytest.mark.asyncio
    async def test_random_api_failures(self, trading_system, mock_exchange):
        """Test system stability under random API failures"""
        original_fetch = mock_exchange.fetch_ticker

        async def random_failing_fetch(*args, **kwargs):
            if random.random() < 0.3:  # 30% failure rate
                raise Exception("Random API failure")
            return await original_fetch(*args, **kwargs)

        mock_exchange.fetch_ticker = random_failing_fetch

        # Run many cycles
        errors = 0
        for _ in range(100):
            try:
                await trading_system.run_cycle()
            except Exception:
                errors += 1

        # System should handle failures gracefully
        assert errors < 50  # Less than 50% actual errors (retries should help)
        assert trading_system.is_running()

    @pytest.mark.asyncio
    async def test_random_latency_spikes(self, trading_system, mock_exchange):
        """Test handling of random latency spikes"""
        original_fetch = mock_exchange.fetch_ticker

        async def latency_fetch(*args, **kwargs):
            if random.random() < 0.2:  # 20% chance of latency
                await asyncio.sleep(random.uniform(1, 3))
            return await original_fetch(*args, **kwargs)

        mock_exchange.fetch_ticker = latency_fetch

        # Run with timeout handling
        start = time.time()
        for _ in range(20):
            await trading_system.run_cycle()

        elapsed = time.time() - start

        # Should complete in reasonable time despite latency
        assert elapsed < 120  # Less than 2 minutes
```

---

## Continuous Integration

### CI/CD Pipeline Configuration

```yaml
# .github/workflows/trading-bot-ci.yml

name: Trading Bot CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
          pip install -r requirements-test.txt

      - name: Run unit tests
        run: |
          pytest tests/unit -v --cov=src --cov-report=xml

      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          files: ./coverage.xml

  integration-tests:
    runs-on: ubuntu-latest
    needs: unit-tests
    services:
      postgres:
        image: timescale/timescaledb:latest-pg14
        env:
          POSTGRES_DB: trading_test
          POSTGRES_USER: test_user
          POSTGRES_PASSWORD: test_password
        ports:
          - 5432:5432
      redis:
        image: redis:7
        ports:
          - 6379:6379

    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'

      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install -r requirements-test.txt

      - name: Run integration tests
        run: |
          pytest tests/integration -v -m integration
        env:
          DB_HOST: localhost
          DB_PORT: 5432
          REDIS_HOST: localhost

  performance-tests:
    runs-on: ubuntu-latest
    needs: integration-tests
    steps:
      - uses: actions/checkout@v3

      - name: Run performance tests
        run: |
          pytest tests/performance -v -m performance

      - name: Upload performance results
        uses: actions/upload-artifact@v3
        with:
          name: performance-results
          path: performance_results.json

  backtest-validation:
    runs-on: ubuntu-latest
    needs: unit-tests
    steps:
      - uses: actions/checkout@v3

      - name: Run backtest validation
        run: |
          pytest tests/backtest -v

      - name: Check strategy metrics
        run: |
          python scripts/validate_strategy_metrics.py

  security-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Run security scan
        uses: snyk/actions/python@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}

  deploy-staging:
    runs-on: ubuntu-latest
    needs: [integration-tests, backtest-validation]
    if: github.ref == 'refs/heads/develop'
    steps:
      - name: Deploy to staging
        run: |
          echo "Deploying to staging environment"
          # Deployment commands

  deploy-production:
    runs-on: ubuntu-latest
    needs: [integration-tests, backtest-validation, performance-tests]
    if: github.ref == 'refs/heads/main'
    environment: production
    steps:
      - name: Deploy to production
        run: |
          echo "Deploying to production"
          # Production deployment commands
```

### Test Coverage Requirements

```python
# pytest.ini

[pytest]
minversion = 7.0
addopts = -ra -q --strict-markers
testpaths = tests
markers =
    unit: Unit tests
    integration: Integration tests
    e2e: End-to-end tests
    performance: Performance tests
    chaos: Chaos engineering tests
    slow: Slow running tests

# Coverage configuration
[coverage:run]
source = src
branch = True

[coverage:report]
fail_under = 80
exclude_lines =
    pragma: no cover
    def __repr__
    raise NotImplementedError
    if __name__ == .__main__.:
```

---

## Testing Best Practices Summary

```python
testing_best_practices = {
    'unit_tests': [
        'Test one thing per test',
        'Use descriptive test names',
        'Mock external dependencies',
        'Cover edge cases',
        'Test error handling'
    ],

    'integration_tests': [
        'Use real database (test instance)',
        'Test component interactions',
        'Clean up after tests',
        'Use fixtures for setup'
    ],

    'e2e_tests': [
        'Test complete workflows',
        'Use realistic data',
        'Include failure scenarios',
        'Test recovery procedures'
    ],

    'performance_tests': [
        'Establish baselines',
        'Test under load',
        'Monitor memory usage',
        'Set performance budgets'
    ],

    'general': [
        'Run tests in CI/CD',
        'Maintain high coverage',
        'Review test failures immediately',
        'Update tests with code changes'
    ]
}
```

---

*Comprehensive testing is the foundation of reliable trading systems.*
