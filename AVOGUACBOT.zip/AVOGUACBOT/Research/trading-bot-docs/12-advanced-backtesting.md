# 12 - Advanced Backtesting

> **Walk-forward optimization, regime detection, Monte Carlo analysis, and robust testing**

---

## Overview

Basic backtesting can be misleading. This document covers advanced techniques to ensure your strategy is robust and not just curve-fitted to historical data.

---

## Walk-Forward Optimization

Walk-forward analysis prevents overfitting by optimizing on past data and testing on unseen future data.

```python
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any
from dataclasses import dataclass
from itertools import product

@dataclass
class WalkForwardResult:
    """Results from walk-forward analysis"""
    period_start: pd.Timestamp
    period_end: pd.Timestamp
    optimized_params: Dict
    in_sample_performance: Dict
    out_of_sample_performance: Dict


class WalkForwardOptimizer:
    """
    Walk-Forward Analysis

    Process:
    1. Optimize parameters on in-sample period
    2. Test on out-of-sample period
    3. Roll forward and repeat
    4. Aggregate out-of-sample results
    """

    def __init__(self, strategy_class, param_grid: Dict[str, List]):
        self.strategy_class = strategy_class
        self.param_grid = param_grid

    def run(self, df: pd.DataFrame, in_sample_days: int = 180,
            out_of_sample_days: int = 30, step_days: int = 30,
            optimization_metric: str = 'sharpe_ratio') -> List[WalkForwardResult]:
        """
        Run walk-forward optimization

        Args:
            df: Full historical data
            in_sample_days: Days for optimization
            out_of_sample_days: Days for testing
            step_days: Days to roll forward each iteration
            optimization_metric: Metric to optimize ('sharpe_ratio', 'total_return', 'profit_factor')
        """
        results = []
        current_start = 0
        total_bars = len(df)

        while current_start + in_sample_days + out_of_sample_days <= total_bars:
            # Define periods
            in_sample_end = current_start + in_sample_days
            out_sample_end = in_sample_end + out_of_sample_days

            in_sample_data = df.iloc[current_start:in_sample_end]
            out_sample_data = df.iloc[in_sample_end:out_sample_end]

            print(f"Walk-forward: {df.index[current_start]} to {df.index[out_sample_end-1]}")

            # Optimize on in-sample
            best_params, in_sample_perf = self._optimize(
                in_sample_data, optimization_metric
            )

            # Test on out-of-sample
            out_sample_perf = self._backtest(out_sample_data, best_params)

            results.append(WalkForwardResult(
                period_start=df.index[in_sample_end],
                period_end=df.index[out_sample_end - 1],
                optimized_params=best_params,
                in_sample_performance=in_sample_perf,
                out_of_sample_performance=out_sample_perf
            ))

            # Roll forward
            current_start += step_days

        return results

    def _optimize(self, df: pd.DataFrame, metric: str) -> Tuple[Dict, Dict]:
        """Grid search optimization on in-sample data"""
        best_params = None
        best_metric = -float('inf')
        best_performance = None

        # Generate all parameter combinations
        param_names = list(self.param_grid.keys())
        param_values = list(self.param_grid.values())

        for combination in product(*param_values):
            params = dict(zip(param_names, combination))

            # Skip invalid combinations
            if not self._validate_params(params):
                continue

            performance = self._backtest(df, params)

            if performance[metric] > best_metric:
                best_metric = performance[metric]
                best_params = params
                best_performance = performance

        return best_params, best_performance

    def _backtest(self, df: pd.DataFrame, params: Dict) -> Dict:
        """Run backtest with given parameters"""
        strategy = self.strategy_class(**params)
        # ... run backtest logic ...
        # Return performance metrics
        return {
            'total_return': 0,  # Calculate actual values
            'sharpe_ratio': 0,
            'max_drawdown': 0,
            'profit_factor': 0,
            'win_rate': 0,
            'num_trades': 0
        }

    def _validate_params(self, params: Dict) -> bool:
        """Validate parameter combination"""
        # Example: fast MA must be less than slow MA
        if 'fast_period' in params and 'slow_period' in params:
            if params['fast_period'] >= params['slow_period']:
                return False
        return True

    def analyze_results(self, results: List[WalkForwardResult]) -> Dict:
        """Analyze walk-forward results"""
        if not results:
            return {}

        # Aggregate out-of-sample performance
        oos_returns = [r.out_of_sample_performance['total_return'] for r in results]
        oos_sharpes = [r.out_of_sample_performance['sharpe_ratio'] for r in results]

        # Check parameter stability
        param_variations = {}
        for param_name in results[0].optimized_params.keys():
            values = [r.optimized_params[param_name] for r in results]
            param_variations[param_name] = {
                'values': values,
                'std': np.std(values),
                'mean': np.mean(values)
            }

        # Efficiency ratio: OOS performance / IS performance
        efficiency_ratios = []
        for r in results:
            if r.in_sample_performance['total_return'] != 0:
                ratio = r.out_of_sample_performance['total_return'] / r.in_sample_performance['total_return']
                efficiency_ratios.append(ratio)

        return {
            'num_periods': len(results),
            'oos_mean_return': np.mean(oos_returns),
            'oos_std_return': np.std(oos_returns),
            'oos_mean_sharpe': np.mean(oos_sharpes),
            'win_rate_periods': sum(1 for r in oos_returns if r > 0) / len(oos_returns),
            'efficiency_ratio': np.mean(efficiency_ratios) if efficiency_ratios else 0,
            'parameter_stability': param_variations
        }
```

---

## Regime Detection

Markets behave differently in different regimes. Test your strategy across all regimes.

```python
class RegimeDetector:
    """
    Detect market regimes for regime-aware backtesting

    Regimes:
    - Trending up
    - Trending down
    - Ranging/consolidating
    - High volatility
    - Low volatility
    """

    def __init__(self, trend_period: int = 50, vol_period: int = 20):
        self.trend_period = trend_period
        self.vol_period = vol_period

    def detect_regimes(self, df: pd.DataFrame) -> pd.DataFrame:
        """Classify each bar into a regime"""
        df = df.copy()

        # Trend detection using ADX and MA slope
        df['ma'] = df['close'].rolling(self.trend_period).mean()
        df['ma_slope'] = df['ma'].diff(5) / df['ma'].shift(5)

        # Volatility regime
        df['volatility'] = df['close'].pct_change().rolling(self.vol_period).std()
        df['vol_percentile'] = df['volatility'].rolling(252).rank(pct=True)

        # ADX for trend strength
        df['adx'] = self._calculate_adx(df, 14)

        # Classify regimes
        df['trend_regime'] = self._classify_trend(df)
        df['vol_regime'] = self._classify_volatility(df)
        df['combined_regime'] = df['trend_regime'] + '_' + df['vol_regime']

        return df

    def _calculate_adx(self, df: pd.DataFrame, period: int) -> pd.Series:
        """Calculate Average Directional Index"""
        high = df['high']
        low = df['low']
        close = df['close']

        plus_dm = high.diff()
        minus_dm = low.diff().abs()

        plus_dm[plus_dm < 0] = 0
        minus_dm[minus_dm < 0] = 0

        tr = pd.DataFrame({
            'hl': high - low,
            'hc': (high - close.shift()).abs(),
            'lc': (low - close.shift()).abs()
        }).max(axis=1)

        atr = tr.rolling(period).mean()
        plus_di = 100 * (plus_dm.rolling(period).mean() / atr)
        minus_di = 100 * (minus_dm.rolling(period).mean() / atr)

        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
        adx = dx.rolling(period).mean()

        return adx

    def _classify_trend(self, df: pd.DataFrame) -> pd.Series:
        """Classify trend regime"""
        conditions = [
            (df['adx'] > 25) & (df['ma_slope'] > 0.001),  # Strong uptrend
            (df['adx'] > 25) & (df['ma_slope'] < -0.001),  # Strong downtrend
            (df['adx'] <= 25)  # Ranging
        ]
        choices = ['uptrend', 'downtrend', 'ranging']

        return pd.Series(np.select(conditions, choices, default='ranging'), index=df.index)

    def _classify_volatility(self, df: pd.DataFrame) -> pd.Series:
        """Classify volatility regime"""
        conditions = [
            df['vol_percentile'] > 0.7,  # High volatility
            df['vol_percentile'] < 0.3,  # Low volatility
        ]
        choices = ['high_vol', 'low_vol']

        return pd.Series(np.select(conditions, choices, default='normal_vol'), index=df.index)


class RegimeAwareBacktester:
    """Backtest with regime analysis"""

    def __init__(self, strategy):
        self.strategy = strategy
        self.regime_detector = RegimeDetector()

    def backtest_by_regime(self, df: pd.DataFrame) -> Dict:
        """Run backtest and analyze by regime"""
        # Detect regimes
        df = self.regime_detector.detect_regimes(df)

        # Run backtest
        trades = self._run_backtest(df)

        # Classify trades by regime
        regime_performance = {}
        for regime in df['combined_regime'].unique():
            regime_trades = [t for t in trades if t.get('regime') == regime]
            if regime_trades:
                regime_performance[regime] = self._calculate_performance(regime_trades)

        return {
            'overall': self._calculate_performance(trades),
            'by_regime': regime_performance,
            'regime_distribution': df['combined_regime'].value_counts().to_dict()
        }

    def _run_backtest(self, df: pd.DataFrame) -> List[Dict]:
        """Run backtest and tag trades with regime"""
        trades = []
        # ... backtest logic ...
        return trades

    def _calculate_performance(self, trades: List[Dict]) -> Dict:
        """Calculate performance metrics"""
        if not trades:
            return {'num_trades': 0}

        pnls = [t['pnl'] for t in trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]

        return {
            'num_trades': len(trades),
            'total_pnl': sum(pnls),
            'win_rate': len(wins) / len(trades) if trades else 0,
            'avg_win': np.mean(wins) if wins else 0,
            'avg_loss': np.mean(losses) if losses else 0,
            'profit_factor': sum(wins) / abs(sum(losses)) if losses else float('inf')
        }
```

---

## Monte Carlo Simulation

Test strategy robustness through randomization.

```python
class MonteCarloSimulator:
    """
    Monte Carlo simulation for strategy robustness testing

    Methods:
    - Trade shuffling: Randomize trade order
    - Parameter perturbation: Add noise to parameters
    - Bootstrap resampling: Resample with replacement
    """

    def __init__(self, n_simulations: int = 1000):
        self.n_simulations = n_simulations

    def trade_shuffle_simulation(self, trades: List[Dict],
                                  initial_capital: float = 100000) -> Dict:
        """
        Shuffle trade order to see range of possible equity curves

        Same trades, different order = different max drawdowns
        """
        pnls = [t['pnl'] for t in trades]
        results = []

        for _ in range(self.n_simulations):
            # Shuffle trade order
            shuffled = np.random.permutation(pnls)

            # Calculate equity curve
            equity = [initial_capital]
            for pnl in shuffled:
                equity.append(equity[-1] + pnl)

            equity = np.array(equity)

            # Calculate metrics
            max_dd = self._max_drawdown(equity)
            total_return = (equity[-1] - initial_capital) / initial_capital

            results.append({
                'max_drawdown': max_dd,
                'total_return': total_return,
                'final_equity': equity[-1]
            })

        return self._analyze_mc_results(results)

    def parameter_perturbation(self, strategy_class, base_params: Dict,
                                df: pd.DataFrame, perturbation_pct: float = 0.1) -> Dict:
        """
        Add noise to parameters and test stability

        If small parameter changes cause large performance changes,
        the strategy may be overfit
        """
        results = []

        for _ in range(self.n_simulations):
            # Perturb parameters
            perturbed_params = {}
            for key, value in base_params.items():
                if isinstance(value, (int, float)):
                    noise = np.random.uniform(1 - perturbation_pct, 1 + perturbation_pct)
                    perturbed_params[key] = type(value)(value * noise)
                else:
                    perturbed_params[key] = value

            # Run backtest
            try:
                strategy = strategy_class(**perturbed_params)
                performance = self._backtest(strategy, df)
                results.append(performance)
            except:
                continue

        return self._analyze_mc_results(results)

    def bootstrap_simulation(self, df: pd.DataFrame, strategy,
                             block_size: int = 20) -> Dict:
        """
        Bootstrap resampling with blocks

        Preserves some temporal structure while creating synthetic data
        """
        results = []
        n_blocks = len(df) // block_size

        for _ in range(self.n_simulations):
            # Sample blocks with replacement
            sampled_indices = []
            for _ in range(n_blocks):
                start = np.random.randint(0, len(df) - block_size)
                sampled_indices.extend(range(start, start + block_size))

            sampled_df = df.iloc[sampled_indices].reset_index(drop=True)

            # Run backtest
            try:
                performance = self._backtest(strategy, sampled_df)
                results.append(performance)
            except:
                continue

        return self._analyze_mc_results(results)

    def _max_drawdown(self, equity: np.array) -> float:
        """Calculate maximum drawdown"""
        peak = np.maximum.accumulate(equity)
        drawdown = (peak - equity) / peak
        return np.max(drawdown)

    def _backtest(self, strategy, df: pd.DataFrame) -> Dict:
        """Run backtest and return metrics"""
        # Implement backtest logic
        return {
            'total_return': 0,
            'max_drawdown': 0,
            'sharpe_ratio': 0
        }

    def _analyze_mc_results(self, results: List[Dict]) -> Dict:
        """Analyze Monte Carlo results"""
        if not results:
            return {}

        metrics = {}
        for key in results[0].keys():
            values = [r[key] for r in results]
            metrics[key] = {
                'mean': np.mean(values),
                'std': np.std(values),
                'median': np.median(values),
                'percentile_5': np.percentile(values, 5),
                'percentile_95': np.percentile(values, 95),
                'min': np.min(values),
                'max': np.max(values)
            }

        return {
            'n_simulations': len(results),
            'metrics': metrics
        }
```

---

## Stress Testing

Test strategy under extreme conditions.

```python
class StressTester:
    """
    Stress test strategies under extreme conditions

    Tests:
    - Flash crash scenarios
    - Extended drawdowns
    - Gap events
    - Liquidity crises
    """

    def __init__(self, strategy):
        self.strategy = strategy

    def simulate_flash_crash(self, df: pd.DataFrame, crash_pct: float = 0.10,
                             duration_bars: int = 5, recovery_bars: int = 20) -> Dict:
        """
        Simulate a flash crash scenario

        Price drops X% in Y bars, then recovers over Z bars
        """
        df = df.copy()
        crash_start = len(df) // 2

        # Create crash
        original_price = df.iloc[crash_start]['close']
        crash_bottom = original_price * (1 - crash_pct)

        for i in range(duration_bars):
            idx = crash_start + i
            if idx < len(df):
                progress = (i + 1) / duration_bars
                df.iloc[idx, df.columns.get_loc('close')] = original_price - (original_price - crash_bottom) * progress
                df.iloc[idx, df.columns.get_loc('low')] = df.iloc[idx]['close'] * 0.99

        # Recovery
        for i in range(recovery_bars):
            idx = crash_start + duration_bars + i
            if idx < len(df):
                progress = (i + 1) / recovery_bars
                df.iloc[idx, df.columns.get_loc('close')] = crash_bottom + (original_price - crash_bottom) * progress

        return self._run_stress_test(df, 'flash_crash')

    def simulate_extended_drawdown(self, df: pd.DataFrame,
                                    trend_pct: float = -0.30,
                                    duration_bars: int = 100) -> Dict:
        """
        Simulate extended bear market

        Slow, grinding drawdown over many bars
        """
        df = df.copy()
        start_idx = len(df) // 4

        for i in range(duration_bars):
            idx = start_idx + i
            if idx < len(df):
                daily_change = trend_pct / duration_bars
                df.iloc[idx, df.columns.get_loc('close')] *= (1 + daily_change)

        return self._run_stress_test(df, 'extended_drawdown')

    def simulate_gap_events(self, df: pd.DataFrame, num_gaps: int = 5,
                            gap_range: Tuple[float, float] = (-0.05, 0.05)) -> Dict:
        """
        Simulate price gaps (common in crypto weekends/maintenance)
        """
        df = df.copy()

        for _ in range(num_gaps):
            gap_idx = np.random.randint(10, len(df) - 10)
            gap_pct = np.random.uniform(gap_range[0], gap_range[1])

            # Apply gap
            df.iloc[gap_idx:, df.columns.get_loc('close')] *= (1 + gap_pct)
            df.iloc[gap_idx:, df.columns.get_loc('open')] *= (1 + gap_pct)
            df.iloc[gap_idx:, df.columns.get_loc('high')] *= (1 + gap_pct)
            df.iloc[gap_idx:, df.columns.get_loc('low')] *= (1 + gap_pct)

        return self._run_stress_test(df, 'gap_events')

    def simulate_volatility_spike(self, df: pd.DataFrame,
                                   vol_multiplier: float = 3.0,
                                   duration_bars: int = 20) -> Dict:
        """
        Simulate volatility spike (e.g., news event)
        """
        df = df.copy()
        spike_start = len(df) // 2

        for i in range(duration_bars):
            idx = spike_start + i
            if idx < len(df):
                # Increase high-low range
                mid = (df.iloc[idx]['high'] + df.iloc[idx]['low']) / 2
                half_range = (df.iloc[idx]['high'] - df.iloc[idx]['low']) / 2
                df.iloc[idx, df.columns.get_loc('high')] = mid + half_range * vol_multiplier
                df.iloc[idx, df.columns.get_loc('low')] = mid - half_range * vol_multiplier

        return self._run_stress_test(df, 'volatility_spike')

    def _run_stress_test(self, df: pd.DataFrame, scenario: str) -> Dict:
        """Run backtest on stressed data"""
        # Run backtest
        performance = {}  # ... backtest logic ...

        return {
            'scenario': scenario,
            'performance': performance
        }

    def run_all_stress_tests(self, df: pd.DataFrame) -> Dict:
        """Run all stress test scenarios"""
        results = {}

        results['baseline'] = self._run_stress_test(df.copy(), 'baseline')
        results['flash_crash'] = self.simulate_flash_crash(df.copy())
        results['extended_drawdown'] = self.simulate_extended_drawdown(df.copy())
        results['gap_events'] = self.simulate_gap_events(df.copy())
        results['volatility_spike'] = self.simulate_volatility_spike(df.copy())

        return results
```

---

## Robustness Checklist

### Before Deploying Any Strategy

```python
class RobustnessChecker:
    """Checklist for strategy robustness"""

    def __init__(self, strategy, df: pd.DataFrame, params: Dict):
        self.strategy = strategy
        self.df = df
        self.params = params
        self.checks = {}

    def run_all_checks(self) -> Dict:
        """Run complete robustness check"""
        self.checks['sample_size'] = self._check_sample_size()
        self.checks['out_of_sample'] = self._check_out_of_sample()
        self.checks['walk_forward'] = self._check_walk_forward()
        self.checks['parameter_stability'] = self._check_parameter_stability()
        self.checks['regime_performance'] = self._check_regime_performance()
        self.checks['monte_carlo'] = self._check_monte_carlo()
        self.checks['stress_tests'] = self._check_stress_tests()

        # Calculate overall score
        passed = sum(1 for c in self.checks.values() if c['passed'])
        total = len(self.checks)

        return {
            'checks': self.checks,
            'passed': passed,
            'total': total,
            'score': passed / total,
            'ready_for_live': passed >= total * 0.8  # 80% pass rate
        }

    def _check_sample_size(self) -> Dict:
        """Check if enough trades for statistical significance"""
        min_trades = 100
        # ... run backtest and count trades ...
        num_trades = 150  # placeholder

        return {
            'name': 'Sample Size',
            'passed': num_trades >= min_trades,
            'details': f'{num_trades} trades (minimum: {min_trades})'
        }

    def _check_out_of_sample(self) -> Dict:
        """Check out-of-sample performance"""
        train_pct = 0.7
        split_idx = int(len(self.df) * train_pct)

        # ... run backtests on train and test ...
        train_sharpe = 1.5  # placeholder
        test_sharpe = 1.2   # placeholder

        degradation = (train_sharpe - test_sharpe) / train_sharpe

        return {
            'name': 'Out-of-Sample',
            'passed': degradation < 0.3 and test_sharpe > 0.5,
            'details': f'Train Sharpe: {train_sharpe:.2f}, Test Sharpe: {test_sharpe:.2f}'
        }

    def _check_walk_forward(self) -> Dict:
        """Run walk-forward optimization"""
        # ... run walk-forward ...
        efficiency_ratio = 0.75  # placeholder

        return {
            'name': 'Walk-Forward',
            'passed': efficiency_ratio > 0.5,
            'details': f'Efficiency ratio: {efficiency_ratio:.2f}'
        }

    def _check_parameter_stability(self) -> Dict:
        """Check if nearby parameters have similar performance"""
        # ... test parameter variations ...
        stability_score = 0.8  # placeholder

        return {
            'name': 'Parameter Stability',
            'passed': stability_score > 0.6,
            'details': f'Stability score: {stability_score:.2f}'
        }

    def _check_regime_performance(self) -> Dict:
        """Check performance across market regimes"""
        # ... analyze by regime ...
        worst_regime_sharpe = 0.3  # placeholder

        return {
            'name': 'Regime Performance',
            'passed': worst_regime_sharpe > 0,
            'details': f'Worst regime Sharpe: {worst_regime_sharpe:.2f}'
        }

    def _check_monte_carlo(self) -> Dict:
        """Run Monte Carlo simulation"""
        # ... run MC simulation ...
        percentile_5_dd = 0.08  # placeholder (5th percentile max drawdown)

        return {
            'name': 'Monte Carlo',
            'passed': percentile_5_dd < 0.15,
            'details': f'95% confidence max DD: {percentile_5_dd:.1%}'
        }

    def _check_stress_tests(self) -> Dict:
        """Run stress tests"""
        # ... run stress tests ...
        survived_all = True  # placeholder

        return {
            'name': 'Stress Tests',
            'passed': survived_all,
            'details': 'Survived all stress scenarios' if survived_all else 'Failed some scenarios'
        }
```

---

## Summary

Advanced backtesting ensures:

1. **Walk-forward analysis** - Prevents overfitting
2. **Regime analysis** - Strategy works in all conditions
3. **Monte Carlo** - Understand range of outcomes
4. **Stress testing** - Survive extreme events
5. **Robustness checks** - Systematic verification

Never deploy a strategy that hasn't passed rigorous testing!

---

*Next: [13-complete-bot-template.md](./13-complete-bot-template.md) - Full working trading bot implementation*
