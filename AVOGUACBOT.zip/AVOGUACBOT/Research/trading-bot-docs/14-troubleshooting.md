# 14 - Troubleshooting & Edge Cases

> **Common issues, debugging techniques, and edge case handling**

---

## Overview

This document covers common problems you'll encounter when building and running a trading bot, along with solutions and debugging techniques.

---

## Common Issues & Solutions

### 1. Connection Issues

#### Problem: "Authentication failed"
```python
# Error: ccxt.AuthenticationError: binance {"code":-2015,"msg":"Invalid API-key..."}

# Solutions:
# 1. Check API key permissions
# 2. Verify key is for correct environment (testnet vs mainnet)
# 3. Check if IP is whitelisted
# 4. Ensure system time is synced (NTP)

# Fix time sync:
# Linux: sudo ntpdate pool.ntp.org
# Or in code:
import ccxt
exchange = ccxt.binance({
    'apiKey': key,
    'secret': secret,
    'options': {
        'adjustForTimeDifference': True,  # Auto-sync time
    }
})
```

#### Problem: "Connection reset by peer"
```python
# Implement reconnection logic
async def robust_connect(self, max_retries=5):
    for attempt in range(max_retries):
        try:
            await self.exchange.load_markets()
            return True
        except ccxt.NetworkError as e:
            wait = 2 ** attempt
            self.logger.warning(f"Connection failed, retry in {wait}s: {e}")
            await asyncio.sleep(wait)
    raise ConnectionError("Could not connect to exchange")
```

#### Problem: Rate limiting
```python
# Error: ccxt.RateLimitExceeded

# Solutions:
# 1. Enable built-in rate limiting
exchange = ccxt.binance({'enableRateLimit': True})

# 2. Implement custom rate limiter
from collections import deque
import time

class RateLimiter:
    def __init__(self, max_requests=10, per_seconds=1):
        self.max_requests = max_requests
        self.per_seconds = per_seconds
        self.requests = deque()

    async def acquire(self):
        now = time.time()
        # Remove old requests
        while self.requests and self.requests[0] < now - self.per_seconds:
            self.requests.popleft()

        if len(self.requests) >= self.max_requests:
            sleep_time = self.requests[0] + self.per_seconds - now
            await asyncio.sleep(sleep_time)

        self.requests.append(time.time())
```

### 2. Order Issues

#### Problem: "Order would trigger immediately"
```python
# When placing stop orders, price must be on correct side

def validate_stop_order(current_price, stop_price, side):
    if side == 'sell':  # Stop loss for long
        if stop_price >= current_price:
            raise ValueError(f"Stop sell price {stop_price} must be below current {current_price}")
    else:  # Stop loss for short
        if stop_price <= current_price:
            raise ValueError(f"Stop buy price {stop_price} must be above current {current_price}")
```

#### Problem: "Insufficient balance"
```python
# Always check balance before ordering
async def safe_order(self, symbol, side, amount, price=None):
    balance = await self.exchange.fetch_balance()

    if side == 'buy':
        required = amount * (price or await self.get_price(symbol))
        available = balance['USDT']['free']
    else:
        available = balance[symbol.split('/')[0]]['free']
        required = amount

    if available < required * 1.01:  # 1% buffer for fees
        raise ValueError(f"Insufficient balance: need {required}, have {available}")

    return await self.exchange.create_order(symbol, 'limit' if price else 'market', side, amount, price)
```

#### Problem: "Order size too small"
```python
# Check minimum order sizes
def get_min_order(self, symbol):
    market = self.exchange.markets[symbol]
    return {
        'min_amount': market['limits']['amount']['min'],
        'min_cost': market['limits']['cost']['min'],
        'amount_precision': market['precision']['amount'],
        'price_precision': market['precision']['price']
    }

def round_order(self, symbol, amount, price):
    mins = self.get_min_order(symbol)

    # Round to precision
    amount = round(amount, mins['amount_precision'])
    price = round(price, mins['price_precision'])

    # Check minimums
    if amount < mins['min_amount']:
        raise ValueError(f"Amount {amount} below minimum {mins['min_amount']}")
    if amount * price < mins['min_cost']:
        raise ValueError(f"Order value below minimum {mins['min_cost']}")

    return amount, price
```

### 3. Position Management Issues

#### Problem: Position mismatch between local and exchange
```python
async def sync_positions(self):
    """Sync local position state with exchange"""
    exchange_positions = await self.exchange.fetch_positions()

    # Build exchange position map
    exchange_pos_map = {
        p['symbol']: {
            'side': p['side'],
            'size': abs(p['contracts']),
            'entry_price': p['entryPrice'],
            'unrealized_pnl': p['unrealizedPnl']
        }
        for p in exchange_positions if p['contracts'] != 0
    }

    # Check for mismatches
    for symbol, local_pos in self.positions.items():
        if symbol not in exchange_pos_map:
            self.logger.warning(f"Local position {symbol} not on exchange - removing")
            del self.positions[symbol]
        elif exchange_pos_map[symbol]['size'] != local_pos['size']:
            self.logger.warning(f"Position size mismatch for {symbol}, syncing")
            self.positions[symbol] = exchange_pos_map[symbol]

    # Add any exchange positions we don't have locally
    for symbol, ex_pos in exchange_pos_map.items():
        if symbol not in self.positions:
            self.logger.warning(f"Found position {symbol} on exchange - adding locally")
            self.positions[symbol] = ex_pos
```

#### Problem: Orphan orders (stop loss/take profit without position)
```python
async def cleanup_orphan_orders(self):
    """Cancel orders for positions that no longer exist"""
    open_orders = await self.exchange.fetch_open_orders()

    for order in open_orders:
        symbol = order['symbol']

        # Check if we have a position for this order
        if symbol not in self.positions:
            self.logger.warning(f"Canceling orphan order {order['id']} for {symbol}")
            await self.exchange.cancel_order(order['id'], symbol)
```

### 4. Data Issues

#### Problem: Missing candles / gaps in data
```python
def check_data_gaps(df, expected_freq='15min'):
    """Identify gaps in OHLCV data"""
    expected_index = pd.date_range(
        start=df.index.min(),
        end=df.index.max(),
        freq=expected_freq
    )

    missing = expected_index.difference(df.index)

    if len(missing) > 0:
        print(f"Found {len(missing)} missing candles")

        # Option 1: Forward fill small gaps
        if len(missing) < 5:
            df = df.reindex(expected_index).ffill()

        # Option 2: Fetch missing data
        # else: fetch_missing_data(missing)

    return df, missing

def handle_incomplete_candle(df):
    """Handle the current incomplete candle"""
    # Last candle may be incomplete - don't use it for signals
    if datetime.now() - df.index[-1] < pd.Timedelta('15min'):
        return df.iloc[:-1]  # Remove last incomplete candle
    return df
```

#### Problem: Stale data / WebSocket disconnection
```python
class DataFreshness:
    def __init__(self, max_age_seconds=60):
        self.max_age = max_age_seconds
        self.last_update = {}

    def update(self, symbol):
        self.last_update[symbol] = datetime.now()

    def is_stale(self, symbol):
        if symbol not in self.last_update:
            return True
        age = (datetime.now() - self.last_update[symbol]).total_seconds()
        return age > self.max_age

    async def ensure_fresh(self, symbol, fetch_func):
        """Ensure data is fresh, refetch if stale"""
        if self.is_stale(symbol):
            self.logger.warning(f"Stale data for {symbol}, refetching")
            await fetch_func(symbol)
            self.update(symbol)
```

### 5. Strategy Issues

#### Problem: Look-ahead bias in backtesting
```python
# WRONG - uses future data
df['signal'] = df['close'].shift(-1) > df['close']  # Using tomorrow's price!

# RIGHT - only uses past data
df['signal'] = df['close'].shift(1) < df['close']  # Using yesterday's price

# WRONG - indicator leaks future
df['rolling_mean'] = df['close'].rolling(20, center=True).mean()  # center=True uses future!

# RIGHT
df['rolling_mean'] = df['close'].rolling(20).mean()  # Only uses past
```

#### Problem: Signals on incomplete candles
```python
def should_process_signal(self, df):
    """Only generate signals on completed candles"""
    latest_candle_time = df.index[-1]
    candle_close_time = latest_candle_time + pd.Timedelta(self.timeframe)

    # Wait until candle is complete
    if datetime.now(timezone.utc) < candle_close_time:
        return False
    return True
```

---

## Edge Cases

### Exchange-Specific Behavior

```python
# Different exchanges handle things differently

class ExchangeQuirks:
    @staticmethod
    def get_quirks(exchange_id):
        quirks = {
            'binance': {
                'reduce_only_param': 'reduceOnly',
                'stop_order_type': 'STOP_MARKET',
                'position_side': True,  # Uses positionSide for hedge mode
            },
            'bybit': {
                'reduce_only_param': 'reduce_only',
                'stop_order_type': 'Stop',
                'position_side': False,
            },
            'okx': {
                'reduce_only_param': 'reduceOnly',
                'stop_order_type': 'trigger',
                'position_side': True,
            }
        }
        return quirks.get(exchange_id, {})
```

### Time Zone Handling

```python
from datetime import datetime, timezone
import pytz

def handle_timezones(timestamp, exchange_tz='UTC', local_tz='UTC'):
    """Properly handle timezone conversions"""
    # Exchange timestamps are usually UTC
    if isinstance(timestamp, (int, float)):
        dt = datetime.fromtimestamp(timestamp / 1000, tz=timezone.utc)
    else:
        dt = timestamp

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    # Convert to desired timezone
    target_tz = pytz.timezone(local_tz)
    return dt.astimezone(target_tz)

# Daily reset timing
def get_daily_reset_time(prop_firm='ftmo'):
    """Get daily reset time for prop firm"""
    reset_times = {
        'ftmo': '00:00 UTC',
        'funded_trader': '17:00 EST',
        # etc.
    }
    return reset_times.get(prop_firm, '00:00 UTC')
```

### Floating Point Precision

```python
# Floating point issues can cause problems

# WRONG
if balance == 0.1:  # May never be exactly 0.1
    pass

# RIGHT
from decimal import Decimal, ROUND_DOWN

def safe_compare(a, b, precision=8):
    return abs(a - b) < 10 ** -precision

def round_down(value, decimals):
    """Round down for position sizing (never risk more than intended)"""
    d = Decimal(str(value))
    return float(d.quantize(Decimal(10) ** -decimals, rounding=ROUND_DOWN))

# Position sizing with proper rounding
size = round_down(calculated_size, 4)  # Round down to 4 decimals
```

### Order Fill Edge Cases

```python
class OrderFillHandler:
    """Handle various order fill scenarios"""

    async def handle_partial_fill(self, order):
        """Handle partially filled orders"""
        filled = order['filled']
        remaining = order['amount'] - filled

        if remaining > self.min_order_size:
            # Cancel remaining and place new order
            await self.exchange.cancel_order(order['id'], order['symbol'])
            # Decide: market order remaining? or wait?
        else:
            # Remaining too small, accept partial fill
            self.logger.info(f"Accepting partial fill: {filled}/{order['amount']}")

    async def handle_rejected_order(self, order, error):
        """Handle rejected orders"""
        if 'insufficient balance' in str(error).lower():
            # Reduce size and retry
            new_size = order['amount'] * 0.95
            return await self.retry_order(order, new_size)
        elif 'price' in str(error).lower():
            # Price moved, use market order
            return await self.exchange.create_market_order(
                order['symbol'], order['side'], order['amount']
            )
        else:
            # Unknown error, don't retry
            self.logger.error(f"Order rejected: {error}")
            return None
```

---

## Debugging Techniques

### Comprehensive Logging

```python
import logging
import json

class TradingLogger:
    """Structured logging for trading bot"""

    def __init__(self, name='trading_bot'):
        self.logger = logging.getLogger(name)

    def log_signal(self, signal, context=None):
        """Log trading signal with context"""
        self.logger.info(json.dumps({
            'event': 'signal',
            'type': signal.type.value,
            'symbol': signal.symbol,
            'strength': signal.strength,
            'price': signal.price,
            'stop_loss': signal.stop_loss,
            'take_profit': signal.take_profit,
            'context': context or {}
        }))

    def log_order(self, order, action='submitted'):
        """Log order events"""
        self.logger.info(json.dumps({
            'event': f'order_{action}',
            'order_id': order.get('id'),
            'symbol': order.get('symbol'),
            'side': order.get('side'),
            'amount': order.get('amount'),
            'price': order.get('price'),
            'status': order.get('status'),
            'filled': order.get('filled'),
        }))

    def log_error(self, error, context=None):
        """Log errors with full context"""
        self.logger.error(json.dumps({
            'event': 'error',
            'error': str(error),
            'type': type(error).__name__,
            'context': context or {}
        }), exc_info=True)
```

### State Inspection

```python
class StateInspector:
    """Inspect bot state for debugging"""

    def __init__(self, engine):
        self.engine = engine

    def dump_state(self):
        """Dump complete bot state"""
        return {
            'timestamp': datetime.now().isoformat(),
            'running': self.engine.running,
            'paused': self.engine.paused,
            'positions': self.engine.positions,
            'pending_orders': self.engine.pending_orders,
            'risk_status': self.engine.risk_manager.get_status(),
            'data_freshness': {
                symbol: self.engine.data_feed.last_update.get(symbol)
                for symbol in self.engine.config.trading.symbols
            }
        }

    def save_state(self, filepath='state_dump.json'):
        """Save state to file"""
        with open(filepath, 'w') as f:
            json.dump(self.dump_state(), f, indent=2, default=str)
```

### Replay Mode

```python
class ReplayMode:
    """Replay historical data for debugging"""

    def __init__(self, engine, historical_data):
        self.engine = engine
        self.data = historical_data
        self.current_idx = 0

    async def step(self):
        """Process one candle"""
        if self.current_idx >= len(self.data):
            return False

        candle = self.data.iloc[self.current_idx]

        # Simulate market data update
        await self.engine.data_feed.inject_candle(candle)

        # Run trading logic
        await self.engine._process_symbol(candle.name)

        self.current_idx += 1
        return True

    async def run_all(self, delay=0):
        """Run through all historical data"""
        while await self.step():
            if delay:
                await asyncio.sleep(delay)
```

---

## Health Checks

```python
class HealthChecker:
    """Comprehensive health checks"""

    def __init__(self, engine):
        self.engine = engine
        self.checks = []

    async def run_all_checks(self):
        """Run all health checks"""
        results = {
            'exchange_connection': await self._check_exchange(),
            'data_freshness': self._check_data(),
            'risk_limits': self._check_risk(),
            'system_resources': self._check_system(),
            'heartbeat': self._check_heartbeat(),
        }

        all_healthy = all(r['healthy'] for r in results.values())

        return {
            'healthy': all_healthy,
            'checks': results,
            'timestamp': datetime.now().isoformat()
        }

    async def _check_exchange(self):
        """Check exchange connectivity"""
        try:
            await asyncio.wait_for(
                self.engine.exchange.fetch_ticker('BTC/USDT'),
                timeout=10
            )
            return {'healthy': True, 'message': 'Connected'}
        except Exception as e:
            return {'healthy': False, 'message': str(e)}

    def _check_data(self):
        """Check data freshness"""
        max_age = 120  # seconds
        issues = []

        for symbol in self.engine.config.trading.symbols:
            last_update = self.engine.data_feed.last_update.get(symbol)
            if not last_update:
                issues.append(f"No data for {symbol}")
            elif (datetime.now() - last_update).seconds > max_age:
                issues.append(f"Stale data for {symbol}")

        return {
            'healthy': len(issues) == 0,
            'message': '; '.join(issues) if issues else 'All data fresh'
        }

    def _check_risk(self):
        """Check risk limits"""
        status = self.engine.risk_manager.get_status()

        warnings = []
        if status['daily_drawdown'] > status['max_daily_dd'] * 0.8:
            warnings.append('Daily DD > 80% of limit')
        if status['total_drawdown'] > status['max_total_dd'] * 0.8:
            warnings.append('Total DD > 80% of limit')

        return {
            'healthy': len(warnings) == 0,
            'message': '; '.join(warnings) if warnings else 'Within limits',
            'daily_dd': status['daily_drawdown'],
            'total_dd': status['total_drawdown']
        }

    def _check_system(self):
        """Check system resources"""
        import psutil

        cpu = psutil.cpu_percent()
        memory = psutil.virtual_memory().percent

        issues = []
        if cpu > 90:
            issues.append(f'High CPU: {cpu}%')
        if memory > 90:
            issues.append(f'High memory: {memory}%')

        return {
            'healthy': len(issues) == 0,
            'message': '; '.join(issues) if issues else f'CPU: {cpu}%, Mem: {memory}%'
        }

    def _check_heartbeat(self):
        """Check last heartbeat"""
        max_age = 60
        last_hb = self.engine.last_heartbeat

        if not last_hb:
            return {'healthy': False, 'message': 'No heartbeat'}

        age = (datetime.now() - last_hb).seconds
        return {
            'healthy': age < max_age,
            'message': f'Last heartbeat: {age}s ago'
        }
```

---

## Summary

Key debugging practices:
1. **Log everything** - Structured JSON logs
2. **Sync state regularly** - Local vs exchange state
3. **Handle all edge cases** - Partial fills, rejects, etc.
4. **Monitor health** - Automated health checks
5. **Test thoroughly** - Replay mode for debugging

When something goes wrong:
1. Check logs first
2. Verify exchange state
3. Compare with local state
4. Look for edge cases
5. Test fix in replay mode

---

*This concludes the troubleshooting documentation.*
