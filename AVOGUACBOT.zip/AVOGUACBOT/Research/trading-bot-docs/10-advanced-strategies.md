# 10 - Advanced Trading Strategies

> **Sophisticated strategies including order flow analysis, machine learning, and market making**

---

## Overview

This document covers advanced strategy concepts that go beyond basic technical analysis. These strategies require deeper market understanding and more sophisticated implementation.

---

## Order Flow Analysis

Order flow analysis examines the actual buying and selling pressure in the market, providing insights that price alone cannot reveal.

### Volume Delta

```python
import pandas as pd
import numpy as np

class VolumeAnalysis:
    """Analyze volume patterns and order flow"""

    def calculate_volume_delta(self, trades_df):
        """
        Calculate volume delta (buying vs selling volume)

        Buy volume = trades at ask price
        Sell volume = trades at bid price
        Delta = Buy volume - Sell volume
        """
        trades_df = trades_df.copy()

        # Classify trades as buy or sell based on price movement
        trades_df['price_change'] = trades_df['price'].diff()
        trades_df['side'] = np.where(trades_df['price_change'] >= 0, 'buy', 'sell')

        # Or use actual trade side if available
        if 'taker_side' in trades_df.columns:
            trades_df['side'] = trades_df['taker_side']

        # Calculate delta
        buy_volume = trades_df[trades_df['side'] == 'buy']['amount'].sum()
        sell_volume = trades_df[trades_df['side'] == 'sell']['amount'].sum()

        delta = buy_volume - sell_volume
        total_volume = buy_volume + sell_volume

        return {
            'delta': delta,
            'buy_volume': buy_volume,
            'sell_volume': sell_volume,
            'total_volume': total_volume,
            'delta_percent': delta / total_volume * 100 if total_volume > 0 else 0
        }

    def cumulative_volume_delta(self, trades_df, timeframe='1min'):
        """
        Calculate Cumulative Volume Delta (CVD)

        CVD shows the running total of volume delta
        Rising CVD = buying pressure
        Falling CVD = selling pressure
        """
        trades_df = trades_df.copy()
        trades_df['timestamp'] = pd.to_datetime(trades_df['timestamp'], unit='ms')

        # Classify trades
        trades_df['signed_volume'] = np.where(
            trades_df['side'] == 'buy',
            trades_df['amount'],
            -trades_df['amount']
        )

        # Resample to timeframe
        cvd = trades_df.set_index('timestamp').resample(timeframe)['signed_volume'].sum()
        cvd_cumulative = cvd.cumsum()

        return cvd_cumulative

    def volume_profile(self, df, num_bins=50):
        """
        Calculate Volume Profile (Volume at Price)

        Shows where most volume traded - identifies support/resistance
        """
        price_range = df['close'].max() - df['close'].min()
        bin_size = price_range / num_bins

        # Create price bins
        bins = np.linspace(df['close'].min(), df['close'].max(), num_bins + 1)
        df['price_bin'] = pd.cut(df['close'], bins=bins)

        # Sum volume at each price level
        volume_profile = df.groupby('price_bin')['volume'].sum()

        # Find Point of Control (POC) - price level with highest volume
        poc_bin = volume_profile.idxmax()
        poc_price = (poc_bin.left + poc_bin.right) / 2

        # Find Value Area (70% of volume)
        total_volume = volume_profile.sum()
        target_volume = total_volume * 0.70

        sorted_profile = volume_profile.sort_values(ascending=False)
        cumsum = sorted_profile.cumsum()
        value_area_bins = cumsum[cumsum <= target_volume].index.tolist()

        if value_area_bins:
            vah = max([b.right for b in value_area_bins])  # Value Area High
            val = min([b.left for b in value_area_bins])   # Value Area Low
        else:
            vah = poc_price
            val = poc_price

        return {
            'profile': volume_profile,
            'poc': poc_price,
            'value_area_high': vah,
            'value_area_low': val
        }


class OrderFlowStrategy(BaseStrategy):
    """Strategy based on order flow analysis"""

    def __init__(self, delta_threshold=1000, cvd_period=20):
        super().__init__()
        self.delta_threshold = delta_threshold
        self.cvd_period = cvd_period
        self.volume_analyzer = VolumeAnalysis()

    def calculate_indicators(self, df, trades_df=None):
        """Calculate order flow indicators"""
        df = df.copy()

        if trades_df is not None:
            # Calculate CVD
            cvd = self.volume_analyzer.cumulative_volume_delta(trades_df, '1min')
            df['cvd'] = cvd.reindex(df.index, method='ffill')
            df['cvd_ma'] = df['cvd'].rolling(self.cvd_period).mean()

            # CVD divergence from price
            df['price_ma'] = df['close'].rolling(self.cvd_period).mean()
            df['cvd_divergence'] = (
                (df['close'] > df['price_ma']) & (df['cvd'] < df['cvd_ma'])
            ) | (
                (df['close'] < df['price_ma']) & (df['cvd'] > df['cvd_ma'])
            )

        return df

    def generate_signal(self, df, trades_df, current_position=None):
        """Generate signal based on order flow"""
        df = self.calculate_indicators(df, trades_df)
        latest = df.iloc[-1]

        # Recent volume delta
        recent_trades = trades_df[trades_df['timestamp'] > df.index[-1] - pd.Timedelta(minutes=5)]
        delta_info = self.volume_analyzer.calculate_volume_delta(recent_trades)

        # Strong buying pressure with CVD confirmation
        if (delta_info['delta'] > self.delta_threshold and
            latest['cvd'] > latest['cvd_ma']):
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=min(1.0, delta_info['delta'] / (self.delta_threshold * 2)),
                price=latest['close']
            )

        # Strong selling pressure
        if (delta_info['delta'] < -self.delta_threshold and
            latest['cvd'] < latest['cvd_ma']):
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=min(1.0, abs(delta_info['delta']) / (self.delta_threshold * 2)),
                price=latest['close']
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=latest['close'])
```

### Order Book Imbalance

```python
class OrderBookAnalyzer:
    """Analyze order book for trading signals"""

    def __init__(self, levels=10):
        self.levels = levels

    def calculate_imbalance(self, orderbook):
        """
        Calculate order book imbalance

        Imbalance > 0 = more bids than asks (bullish)
        Imbalance < 0 = more asks than bids (bearish)
        """
        bids = orderbook['bids'][:self.levels]
        asks = orderbook['asks'][:self.levels]

        bid_volume = sum(level[1] for level in bids)
        ask_volume = sum(level[1] for level in asks)

        total_volume = bid_volume + ask_volume
        if total_volume == 0:
            return 0

        imbalance = (bid_volume - ask_volume) / total_volume
        return imbalance

    def calculate_weighted_mid_price(self, orderbook):
        """
        Calculate volume-weighted mid price

        More accurate fair price than simple mid
        """
        best_bid = orderbook['bids'][0]
        best_ask = orderbook['asks'][0]

        bid_price, bid_volume = best_bid
        ask_price, ask_volume = best_ask

        total_volume = bid_volume + ask_volume
        if total_volume == 0:
            return (bid_price + ask_price) / 2

        weighted_mid = (bid_price * ask_volume + ask_price * bid_volume) / total_volume
        return weighted_mid

    def detect_spoofing(self, orderbook_history, threshold=0.5):
        """
        Detect potential spoofing (large orders that disappear)

        Spoofing: placing large orders to move price, then canceling
        """
        if len(orderbook_history) < 2:
            return False

        current = orderbook_history[-1]
        previous = orderbook_history[-2]

        # Check if large bid/ask disappeared without execution
        prev_large_bids = [b for b in previous['bids'] if b[1] > threshold]
        curr_bids = {b[0]: b[1] for b in current['bids']}

        for price, volume in prev_large_bids:
            if price not in curr_bids or curr_bids[price] < volume * 0.5:
                # Large order disappeared - possible spoof
                return True

        return False

    def calculate_depth_ratio(self, orderbook, price_range_pct=0.01):
        """
        Calculate depth ratio within price range

        Useful for understanding market depth
        """
        mid_price = (orderbook['bids'][0][0] + orderbook['asks'][0][0]) / 2
        price_range = mid_price * price_range_pct

        bid_depth = sum(
            level[1] for level in orderbook['bids']
            if level[0] >= mid_price - price_range
        )
        ask_depth = sum(
            level[1] for level in orderbook['asks']
            if level[0] <= mid_price + price_range
        )

        if ask_depth == 0:
            return float('inf')

        return bid_depth / ask_depth


class OrderBookStrategy(BaseStrategy):
    """Strategy using order book analysis"""

    def __init__(self, imbalance_threshold=0.3, depth_threshold=1.5):
        super().__init__()
        self.imbalance_threshold = imbalance_threshold
        self.depth_threshold = depth_threshold
        self.ob_analyzer = OrderBookAnalyzer()

    def generate_signal(self, df, orderbook, current_position=None):
        """Generate signal from order book"""
        imbalance = self.ob_analyzer.calculate_imbalance(orderbook)
        depth_ratio = self.ob_analyzer.calculate_depth_ratio(orderbook)
        weighted_mid = self.ob_analyzer.calculate_weighted_mid_price(orderbook)

        current_price = df['close'].iloc[-1]
        price_vs_mid = (current_price - weighted_mid) / weighted_mid

        # Strong bid imbalance + good depth + price below weighted mid
        if (imbalance > self.imbalance_threshold and
            depth_ratio > self.depth_threshold and
            price_vs_mid < -0.001):
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=imbalance,
                price=current_price
            )

        # Strong ask imbalance + weak depth + price above weighted mid
        if (imbalance < -self.imbalance_threshold and
            depth_ratio < 1/self.depth_threshold and
            price_vs_mid > 0.001):
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=abs(imbalance),
                price=current_price
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)
```

---

## Machine Learning Strategies

### Feature Engineering

```python
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import pandas_ta as ta

class FeatureEngineer:
    """Create features for ML models"""

    def __init__(self):
        self.scaler = StandardScaler()

    def create_features(self, df, lookback_periods=[5, 10, 20, 50]):
        """Create comprehensive feature set"""
        features = pd.DataFrame(index=df.index)

        # Price-based features
        for period in lookback_periods:
            # Returns
            features[f'return_{period}'] = df['close'].pct_change(period)

            # Volatility
            features[f'volatility_{period}'] = df['close'].pct_change().rolling(period).std()

            # Price relative to moving average
            ma = df['close'].rolling(period).mean()
            features[f'price_ma_ratio_{period}'] = df['close'] / ma

            # High-low range
            features[f'range_{period}'] = (
                df['high'].rolling(period).max() - df['low'].rolling(period).min()
            ) / df['close']

        # Technical indicators
        features['rsi'] = ta.rsi(df['close'], length=14)
        features['rsi_slope'] = features['rsi'].diff(5)

        macd = ta.macd(df['close'])
        features['macd'] = macd['MACD_12_26_9']
        features['macd_signal'] = macd['MACDs_12_26_9']
        features['macd_hist'] = macd['MACDh_12_26_9']

        bbands = ta.bbands(df['close'], length=20)
        features['bb_position'] = (df['close'] - bbands['BBL_20_2.0']) / (
            bbands['BBU_20_2.0'] - bbands['BBL_20_2.0']
        )

        # ATR normalized
        features['atr_pct'] = ta.atr(df['high'], df['low'], df['close'], length=14) / df['close']

        # Volume features
        features['volume_ratio'] = df['volume'] / df['volume'].rolling(20).mean()
        features['volume_trend'] = df['volume'].rolling(5).mean() / df['volume'].rolling(20).mean()

        # Momentum
        features['momentum_5'] = df['close'] / df['close'].shift(5) - 1
        features['momentum_10'] = df['close'] / df['close'].shift(10) - 1

        # Higher timeframe trend (using rolling max/min)
        features['trend_strength'] = (
            df['close'] - df['low'].rolling(50).min()
        ) / (
            df['high'].rolling(50).max() - df['low'].rolling(50).min()
        )

        # Time-based features (for crypto, 24/7 but still patterns)
        features['hour'] = df.index.hour
        features['day_of_week'] = df.index.dayofweek
        features['hour_sin'] = np.sin(2 * np.pi * features['hour'] / 24)
        features['hour_cos'] = np.cos(2 * np.pi * features['hour'] / 24)

        return features.dropna()

    def create_labels(self, df, forward_periods=10, threshold=0.01):
        """
        Create labels for supervised learning

        Labels: 1 = price goes up by threshold
               -1 = price goes down by threshold
                0 = no significant move
        """
        future_return = df['close'].shift(-forward_periods) / df['close'] - 1

        labels = pd.Series(0, index=df.index)
        labels[future_return > threshold] = 1
        labels[future_return < -threshold] = -1

        return labels

    def prepare_data(self, df, forward_periods=10, threshold=0.01, train_ratio=0.7):
        """Prepare data for ML training"""
        features = self.create_features(df)
        labels = self.create_labels(df, forward_periods, threshold)

        # Align features and labels
        common_idx = features.index.intersection(labels.dropna().index)
        features = features.loc[common_idx]
        labels = labels.loc[common_idx]

        # Remove last forward_periods (no labels)
        features = features.iloc[:-forward_periods]
        labels = labels.iloc[:-forward_periods]

        # Train/test split (time-based, not random!)
        split_idx = int(len(features) * train_ratio)

        X_train = features.iloc[:split_idx]
        X_test = features.iloc[split_idx:]
        y_train = labels.iloc[:split_idx]
        y_test = labels.iloc[split_idx:]

        # Scale features
        X_train_scaled = pd.DataFrame(
            self.scaler.fit_transform(X_train),
            index=X_train.index,
            columns=X_train.columns
        )
        X_test_scaled = pd.DataFrame(
            self.scaler.transform(X_test),
            index=X_test.index,
            columns=X_test.columns
        )

        return X_train_scaled, X_test_scaled, y_train, y_test
```

### ML Model Training

```python
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix
import joblib

class MLModelTrainer:
    """Train and evaluate ML models for trading"""

    def __init__(self):
        self.models = {}
        self.feature_engineer = FeatureEngineer()

    def train_random_forest(self, X_train, y_train, **params):
        """Train Random Forest classifier"""
        default_params = {
            'n_estimators': 100,
            'max_depth': 10,
            'min_samples_split': 50,
            'min_samples_leaf': 20,
            'class_weight': 'balanced',
            'random_state': 42,
            'n_jobs': -1
        }
        default_params.update(params)

        model = RandomForestClassifier(**default_params)
        model.fit(X_train, y_train)

        self.models['random_forest'] = model
        return model

    def train_gradient_boosting(self, X_train, y_train, **params):
        """Train Gradient Boosting classifier"""
        default_params = {
            'n_estimators': 100,
            'max_depth': 5,
            'learning_rate': 0.1,
            'min_samples_split': 50,
            'random_state': 42
        }
        default_params.update(params)

        model = GradientBoostingClassifier(**default_params)
        model.fit(X_train, y_train)

        self.models['gradient_boosting'] = model
        return model

    def evaluate_model(self, model, X_test, y_test):
        """Evaluate model performance"""
        predictions = model.predict(X_test)
        probabilities = model.predict_proba(X_test)

        # Classification report
        report = classification_report(y_test, predictions, output_dict=True)

        # Confusion matrix
        cm = confusion_matrix(y_test, predictions)

        # Feature importance
        if hasattr(model, 'feature_importances_'):
            importance = pd.Series(
                model.feature_importances_,
                index=X_test.columns
            ).sort_values(ascending=False)
        else:
            importance = None

        return {
            'classification_report': report,
            'confusion_matrix': cm,
            'feature_importance': importance,
            'predictions': predictions,
            'probabilities': probabilities
        }

    def save_model(self, model_name, path):
        """Save trained model"""
        if model_name in self.models:
            joblib.dump(self.models[model_name], path)

    def load_model(self, path):
        """Load trained model"""
        return joblib.load(path)


class MLStrategy(BaseStrategy):
    """Strategy using ML predictions"""

    def __init__(self, model_path, confidence_threshold=0.6):
        super().__init__()
        self.model = joblib.load(model_path)
        self.feature_engineer = FeatureEngineer()
        self.confidence_threshold = confidence_threshold

    def generate_signal(self, df, current_position=None):
        """Generate signal using ML model"""
        # Create features
        features = self.feature_engineer.create_features(df)

        if len(features) == 0:
            return Signal(type=SignalType.NONE, symbol='', strength=0, price=df['close'].iloc[-1])

        # Get latest features
        latest_features = features.iloc[[-1]]

        # Scale features
        latest_scaled = self.feature_engineer.scaler.transform(latest_features)

        # Get prediction and probability
        prediction = self.model.predict(latest_scaled)[0]
        probabilities = self.model.predict_proba(latest_scaled)[0]

        # Get confidence (max probability)
        confidence = max(probabilities)
        current_price = df['close'].iloc[-1]

        # Only trade with sufficient confidence
        if confidence < self.confidence_threshold:
            return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)

        if prediction == 1:  # Buy signal
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=confidence,
                price=current_price
            )
        elif prediction == -1:  # Sell signal
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=confidence,
                price=current_price
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)
```

---

## Market Making Strategy

Market making involves providing liquidity by placing both buy and sell orders.

```python
class MarketMakingStrategy:
    """
    Basic market making strategy

    WARNING: Market making is complex and risky.
    This is a simplified educational example.
    """

    def __init__(self, spread_pct=0.002, order_size=0.01, inventory_limit=1.0,
                 skew_factor=0.5):
        self.spread_pct = spread_pct  # Target spread (0.2%)
        self.order_size = order_size
        self.inventory_limit = inventory_limit
        self.skew_factor = skew_factor  # How much to skew quotes based on inventory

        self.inventory = 0  # Current position
        self.orders = {'bid': None, 'ask': None}

    def calculate_quotes(self, mid_price, volatility):
        """
        Calculate bid and ask prices

        Factors considered:
        - Base spread (minimum profit margin)
        - Volatility (wider spread in volatile markets)
        - Inventory (skew to reduce position)
        """
        # Adjust spread for volatility
        vol_adjusted_spread = self.spread_pct * (1 + volatility * 10)

        # Calculate inventory skew
        inventory_ratio = self.inventory / self.inventory_limit
        skew = inventory_ratio * self.skew_factor * self.spread_pct

        # Calculate prices
        half_spread = vol_adjusted_spread / 2

        bid_price = mid_price * (1 - half_spread - skew)
        ask_price = mid_price * (1 + half_spread - skew)

        return {
            'bid': round(bid_price, 2),
            'ask': round(ask_price, 2),
            'spread': ask_price - bid_price,
            'spread_pct': (ask_price - bid_price) / mid_price * 100
        }

    def should_quote(self, orderbook):
        """Determine if we should place quotes"""
        # Check if our orders would be competitive
        best_bid = orderbook['bids'][0][0]
        best_ask = orderbook['asks'][0][0]
        current_spread = (best_ask - best_bid) / best_bid

        # Only quote if spread is wide enough
        return current_spread > self.spread_pct * 0.5

    def update_inventory(self, fill):
        """Update inventory after fill"""
        if fill['side'] == 'buy':
            self.inventory += fill['amount']
        else:
            self.inventory -= fill['amount']

    def check_inventory_limits(self):
        """Check if inventory is within limits"""
        if abs(self.inventory) > self.inventory_limit:
            return False, "Inventory limit exceeded"
        return True, None

    def generate_orders(self, mid_price, volatility, orderbook):
        """Generate market making orders"""
        orders = []

        # Check if we should quote
        if not self.should_quote(orderbook):
            return []

        # Check inventory
        within_limits, _ = self.check_inventory_limits()
        if not within_limits:
            # Only quote on the side that reduces inventory
            quotes = self.calculate_quotes(mid_price, volatility)
            if self.inventory > 0:
                # Only place ask to reduce long
                orders.append({
                    'side': 'sell',
                    'price': quotes['ask'],
                    'amount': self.order_size
                })
            else:
                # Only place bid to reduce short
                orders.append({
                    'side': 'buy',
                    'price': quotes['bid'],
                    'amount': self.order_size
                })
            return orders

        # Normal two-sided quoting
        quotes = self.calculate_quotes(mid_price, volatility)

        orders.append({
            'side': 'buy',
            'price': quotes['bid'],
            'amount': self.order_size
        })
        orders.append({
            'side': 'sell',
            'price': quotes['ask'],
            'amount': self.order_size
        })

        return orders
```

---

## Mean Reversion Strategies

### Statistical Arbitrage

```python
from scipy import stats

class StatisticalArbitrageStrategy(BaseStrategy):
    """
    Mean reversion using statistical measures

    Trades when price deviates significantly from statistical norm
    """

    def __init__(self, lookback=100, entry_zscore=2.0, exit_zscore=0.5):
        super().__init__()
        self.lookback = lookback
        self.entry_zscore = entry_zscore
        self.exit_zscore = exit_zscore

    def calculate_indicators(self, df):
        """Calculate z-score and related indicators"""
        df = df.copy()

        # Rolling statistics
        df['mean'] = df['close'].rolling(self.lookback).mean()
        df['std'] = df['close'].rolling(self.lookback).std()

        # Z-score
        df['zscore'] = (df['close'] - df['mean']) / df['std']

        # Half-life of mean reversion (how fast it reverts)
        df['log_price'] = np.log(df['close'])
        df['log_price_lag'] = df['log_price'].shift(1)
        df['log_return'] = df['log_price'] - df['log_price_lag']

        # Hurst exponent (< 0.5 = mean reverting)
        df['hurst'] = self._calculate_hurst(df['close'], self.lookback)

        return df

    def _calculate_hurst(self, series, window):
        """Calculate Hurst exponent (rolling)"""
        def hurst_single(x):
            if len(x) < 20:
                return np.nan

            lags = range(2, min(20, len(x) // 2))
            tau = []
            for lag in lags:
                tau.append(np.sqrt(np.std(np.subtract(x[lag:], x[:-lag]))))

            if len(tau) < 2:
                return np.nan

            reg = np.polyfit(np.log(list(lags)), np.log(tau), 1)
            return reg[0]

        return series.rolling(window).apply(hurst_single, raw=True)

    def generate_signal(self, df, current_position=None):
        """Generate mean reversion signals"""
        df = self.calculate_indicators(df)
        latest = df.iloc[-1]
        current_price = latest['close']

        # Check if market is mean-reverting (Hurst < 0.5)
        if latest['hurst'] >= 0.5:
            # Market is trending, don't trade mean reversion
            return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)

        zscore = latest['zscore']

        # Exit conditions
        if current_position == 'long' and zscore > -self.exit_zscore:
            return Signal(type=SignalType.CLOSE, symbol='', strength=0.5, price=current_price)
        if current_position == 'short' and zscore < self.exit_zscore:
            return Signal(type=SignalType.CLOSE, symbol='', strength=0.5, price=current_price)

        # Entry conditions
        if zscore < -self.entry_zscore and current_position != 'long':
            # Price below mean - buy expecting reversion up
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=min(1.0, abs(zscore) / 3),
                price=current_price,
                stop_loss=current_price * 0.97,
                take_profit=latest['mean']
            )

        if zscore > self.entry_zscore and current_position != 'short':
            # Price above mean - sell expecting reversion down
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=min(1.0, abs(zscore) / 3),
                price=current_price,
                stop_loss=current_price * 1.03,
                take_profit=latest['mean']
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)
```

### Pairs Trading

```python
class PairsTradingStrategy:
    """
    Trade the spread between two correlated assets

    When spread widens, short the outperformer, long the underperformer
    """

    def __init__(self, lookback=60, entry_zscore=2.0, exit_zscore=0.5):
        self.lookback = lookback
        self.entry_zscore = entry_zscore
        self.exit_zscore = exit_zscore

    def calculate_hedge_ratio(self, price_a, price_b):
        """Calculate hedge ratio using OLS regression"""
        from sklearn.linear_model import LinearRegression

        X = price_b.values.reshape(-1, 1)
        y = price_a.values

        model = LinearRegression()
        model.fit(X, y)

        return model.coef_[0]

    def calculate_spread(self, price_a, price_b, hedge_ratio=None):
        """Calculate spread between two assets"""
        if hedge_ratio is None:
            hedge_ratio = self.calculate_hedge_ratio(price_a, price_b)

        spread = price_a - hedge_ratio * price_b
        return spread, hedge_ratio

    def test_cointegration(self, price_a, price_b):
        """Test if two series are cointegrated"""
        from statsmodels.tsa.stattools import coint

        score, pvalue, _ = coint(price_a, price_b)
        return pvalue < 0.05, pvalue

    def generate_signals(self, df_a, df_b, current_position=None):
        """Generate pairs trading signals"""
        price_a = df_a['close']
        price_b = df_b['close']

        # Check cointegration
        is_coint, pvalue = self.test_cointegration(
            price_a.iloc[-self.lookback:],
            price_b.iloc[-self.lookback:]
        )

        if not is_coint:
            return None, None, "Pair not cointegrated"

        # Calculate spread
        spread, hedge_ratio = self.calculate_spread(
            price_a.iloc[-self.lookback:],
            price_b.iloc[-self.lookback:]
        )

        # Z-score of spread
        spread_mean = spread.rolling(self.lookback).mean()
        spread_std = spread.rolling(self.lookback).std()
        zscore = (spread.iloc[-1] - spread_mean.iloc[-1]) / spread_std.iloc[-1]

        current_price_a = price_a.iloc[-1]
        current_price_b = price_b.iloc[-1]

        # Generate signals
        signal_a = Signal(type=SignalType.NONE, symbol='A', strength=0, price=current_price_a)
        signal_b = Signal(type=SignalType.NONE, symbol='B', strength=0, price=current_price_b)

        if zscore > self.entry_zscore:
            # Spread too wide - short A, long B
            signal_a = Signal(type=SignalType.SELL, symbol='A', strength=0.7, price=current_price_a)
            signal_b = Signal(type=SignalType.BUY, symbol='B', strength=0.7, price=current_price_b)

        elif zscore < -self.entry_zscore:
            # Spread too narrow - long A, short B
            signal_a = Signal(type=SignalType.BUY, symbol='A', strength=0.7, price=current_price_a)
            signal_b = Signal(type=SignalType.SELL, symbol='B', strength=0.7, price=current_price_b)

        elif abs(zscore) < self.exit_zscore and current_position:
            # Close positions
            signal_a = Signal(type=SignalType.CLOSE, symbol='A', strength=0.5, price=current_price_a)
            signal_b = Signal(type=SignalType.CLOSE, symbol='B', strength=0.5, price=current_price_b)

        return signal_a, signal_b, {'zscore': zscore, 'hedge_ratio': hedge_ratio}
```

---

## Strategy Combination

### Ensemble Strategy

```python
class EnsembleStrategy(BaseStrategy):
    """
    Combine multiple strategies for more robust signals

    Methods:
    - Voting: majority rules
    - Weighted: weight by historical performance
    - Stacking: use ML to combine
    """

    def __init__(self, strategies, method='weighted', weights=None):
        super().__init__()
        self.strategies = strategies  # List of strategy instances
        self.method = method
        self.weights = weights or [1.0 / len(strategies)] * len(strategies)

    def generate_signal(self, df, current_position=None, **kwargs):
        """Generate combined signal"""
        signals = []

        # Collect signals from all strategies
        for strategy in self.strategies:
            signal = strategy.generate_signal(df, current_position, **kwargs)
            signals.append(signal)

        if self.method == 'voting':
            return self._voting_combine(signals)
        elif self.method == 'weighted':
            return self._weighted_combine(signals)
        else:
            raise ValueError(f"Unknown method: {self.method}")

    def _voting_combine(self, signals):
        """Simple majority voting"""
        buy_votes = sum(1 for s in signals if s.type == SignalType.BUY)
        sell_votes = sum(1 for s in signals if s.type == SignalType.SELL)

        total = len(signals)
        current_price = signals[0].price

        if buy_votes > total / 2:
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=buy_votes / total,
                price=current_price
            )
        elif sell_votes > total / 2:
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=sell_votes / total,
                price=current_price
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)

    def _weighted_combine(self, signals):
        """Weighted combination"""
        buy_weight = 0
        sell_weight = 0

        for signal, weight in zip(signals, self.weights):
            if signal.type == SignalType.BUY:
                buy_weight += weight * signal.strength
            elif signal.type == SignalType.SELL:
                sell_weight += weight * signal.strength

        current_price = signals[0].price

        if buy_weight > sell_weight and buy_weight > 0.5:
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=buy_weight,
                price=current_price
            )
        elif sell_weight > buy_weight and sell_weight > 0.5:
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=sell_weight,
                price=current_price
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)


# Usage example
ensemble = EnsembleStrategy(
    strategies=[
        MACrossoverStrategy(fast_period=10, slow_period=20),
        RSIMeanReversionStrategy(rsi_period=14),
        BreakoutStrategy(lookback=20),
    ],
    method='weighted',
    weights=[0.4, 0.3, 0.3]
)
```

---

## Summary

Advanced strategies require:

1. **Deeper market understanding** - Order flow, microstructure
2. **More sophisticated analysis** - ML, statistical methods
3. **Better risk management** - These strategies can be riskier
4. **Extensive testing** - More complexity = more potential for bugs
5. **Careful parameter tuning** - Overfitting risk is higher

Always start simple and add complexity only when justified by evidence.

---

*Next: [11-execution-algorithms.md](./11-execution-algorithms.md) - TWAP, VWAP, and smart order routing*
