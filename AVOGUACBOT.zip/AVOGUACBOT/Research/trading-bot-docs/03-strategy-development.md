# 03 - Strategy Development

> **Building, structuring, and implementing trading strategies for automated execution**

---

## Overview

A trading strategy is a set of rules that determine when to enter and exit positions. This document covers how to structure strategies for automation, common strategy types, and implementation patterns.

---

## Strategy Framework

### Base Strategy Class

Create a consistent interface for all strategies:

```python
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any
import pandas as pd

class SignalType(Enum):
    BUY = "buy"
    SELL = "sell"
    CLOSE = "close"
    NONE = "none"

@dataclass
class Signal:
    type: SignalType
    symbol: str
    strength: float  # 0.0 to 1.0
    price: float
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    metadata: Dict[str, Any] = None

class BaseStrategy(ABC):
    """Base class for all trading strategies"""

    def __init__(self, params: Dict[str, Any] = None):
        self.params = params or {}
        self.name = self.__class__.__name__
        self.indicators = {}

    @abstractmethod
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate all indicators needed for the strategy"""
        pass

    @abstractmethod
    def generate_signal(self, df: pd.DataFrame, current_position: Optional[str] = None) -> Signal:
        """Generate trading signal based on current data"""
        pass

    def validate_params(self):
        """Validate strategy parameters"""
        pass

    def get_required_history(self) -> int:
        """Return minimum candles needed for indicators"""
        return 100  # Default
```

### Strategy Components

Every strategy should define:

1. **Entry conditions** - When to open a position
2. **Exit conditions** - When to close a position
3. **Stop loss** - Maximum acceptable loss
4. **Take profit** - Target profit level
5. **Position sizing** - How much to trade (see Risk Management doc)

---

## Technical Indicators

### Using pandas-ta

```python
import pandas_ta as ta

class IndicatorCalculator:
    @staticmethod
    def add_moving_averages(df, periods=[20, 50, 200]):
        """Add Simple and Exponential Moving Averages"""
        for period in periods:
            df[f'sma_{period}'] = ta.sma(df['close'], length=period)
            df[f'ema_{period}'] = ta.ema(df['close'], length=period)
        return df

    @staticmethod
    def add_rsi(df, period=14):
        """Add Relative Strength Index"""
        df['rsi'] = ta.rsi(df['close'], length=period)
        return df

    @staticmethod
    def add_macd(df, fast=12, slow=26, signal=9):
        """Add MACD indicator"""
        macd = ta.macd(df['close'], fast=fast, slow=slow, signal=signal)
        df = pd.concat([df, macd], axis=1)
        return df

    @staticmethod
    def add_bollinger_bands(df, period=20, std=2):
        """Add Bollinger Bands"""
        bbands = ta.bbands(df['close'], length=period, std=std)
        df = pd.concat([df, bbands], axis=1)
        return df

    @staticmethod
    def add_atr(df, period=14):
        """Add Average True Range (for stop loss calculation)"""
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=period)
        return df

    @staticmethod
    def add_volume_indicators(df):
        """Add volume-based indicators"""
        df['volume_sma'] = ta.sma(df['volume'], length=20)
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        return df
```

### Custom Indicators

```python
def calculate_swing_highs_lows(df, window=5):
    """Identify swing highs and lows"""
    df['swing_high'] = df['high'].rolling(window=window, center=True).max() == df['high']
    df['swing_low'] = df['low'].rolling(window=window, center=True).min() == df['low']
    return df

def calculate_support_resistance(df, window=20, threshold=0.02):
    """Identify support and resistance levels"""
    levels = []
    for i in range(window, len(df) - window):
        if df['swing_high'].iloc[i]:
            levels.append(('resistance', df['high'].iloc[i]))
        if df['swing_low'].iloc[i]:
            levels.append(('support', df['low'].iloc[i]))

    # Cluster nearby levels
    clustered = cluster_levels(levels, threshold)
    return clustered
```

---

## Example Strategies

### 1. Moving Average Crossover

Classic trend-following strategy:

```python
class MACrossoverStrategy(BaseStrategy):
    """
    Simple Moving Average Crossover Strategy

    Entry: Fast MA crosses above Slow MA (buy) or below (sell)
    Exit: Opposite crossover or stop loss/take profit hit
    """

    def __init__(self, fast_period=10, slow_period=20, atr_multiplier=2.0):
        super().__init__({
            'fast_period': fast_period,
            'slow_period': slow_period,
            'atr_multiplier': atr_multiplier
        })

    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        # Moving averages
        df['fast_ma'] = ta.ema(df['close'], length=self.params['fast_period'])
        df['slow_ma'] = ta.ema(df['close'], length=self.params['slow_period'])

        # ATR for stop loss
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)

        # Crossover detection
        df['ma_diff'] = df['fast_ma'] - df['slow_ma']
        df['ma_diff_prev'] = df['ma_diff'].shift(1)

        df['bullish_cross'] = (df['ma_diff'] > 0) & (df['ma_diff_prev'] <= 0)
        df['bearish_cross'] = (df['ma_diff'] < 0) & (df['ma_diff_prev'] >= 0)

        return df

    def generate_signal(self, df: pd.DataFrame, current_position: Optional[str] = None) -> Signal:
        df = self.calculate_indicators(df)
        latest = df.iloc[-1]

        current_price = latest['close']
        atr = latest['atr']

        # Check for crossover signals
        if latest['bullish_cross'] and current_position != 'long':
            return Signal(
                type=SignalType.BUY,
                symbol=df.name if hasattr(df, 'name') else 'UNKNOWN',
                strength=0.7,
                price=current_price,
                stop_loss=current_price - (atr * self.params['atr_multiplier']),
                take_profit=current_price + (atr * self.params['atr_multiplier'] * 2)
            )

        elif latest['bearish_cross'] and current_position != 'short':
            return Signal(
                type=SignalType.SELL,
                symbol=df.name if hasattr(df, 'name') else 'UNKNOWN',
                strength=0.7,
                price=current_price,
                stop_loss=current_price + (atr * self.params['atr_multiplier']),
                take_profit=current_price - (atr * self.params['atr_multiplier'] * 2)
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=current_price)

    def get_required_history(self) -> int:
        return self.params['slow_period'] + 20
```

### 2. RSI Mean Reversion

Counter-trend strategy for ranging markets:

```python
class RSIMeanReversionStrategy(BaseStrategy):
    """
    RSI Mean Reversion Strategy

    Entry: RSI oversold (buy) or overbought (sell)
    Exit: RSI returns to neutral zone
    """

    def __init__(self, rsi_period=14, oversold=30, overbought=70, atr_mult=1.5):
        super().__init__({
            'rsi_period': rsi_period,
            'oversold': oversold,
            'overbought': overbought,
            'atr_mult': atr_mult
        })

    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        df['rsi'] = ta.rsi(df['close'], length=self.params['rsi_period'])
        df['rsi_prev'] = df['rsi'].shift(1)
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)

        # Also add a trend filter
        df['sma_200'] = ta.sma(df['close'], length=200)
        df['trend'] = df['close'] > df['sma_200']

        return df

    def generate_signal(self, df: pd.DataFrame, current_position: Optional[str] = None) -> Signal:
        df = self.calculate_indicators(df)
        latest = df.iloc[-1]

        price = latest['close']
        rsi = latest['rsi']
        rsi_prev = latest['rsi_prev']
        atr = latest['atr']

        # Close position if RSI returns to neutral
        if current_position == 'long' and rsi > 50:
            return Signal(type=SignalType.CLOSE, symbol='', strength=0.6, price=price)
        if current_position == 'short' and rsi < 50:
            return Signal(type=SignalType.CLOSE, symbol='', strength=0.6, price=price)

        # Entry signals
        # Buy when RSI crosses above oversold (was oversold, now rising)
        if rsi_prev < self.params['oversold'] and rsi >= self.params['oversold']:
            if latest['trend']:  # Only buy in uptrend
                return Signal(
                    type=SignalType.BUY,
                    symbol='',
                    strength=0.6,
                    price=price,
                    stop_loss=price - (atr * self.params['atr_mult']),
                    take_profit=price + (atr * self.params['atr_mult'] * 1.5)
                )

        # Sell when RSI crosses below overbought
        if rsi_prev > self.params['overbought'] and rsi <= self.params['overbought']:
            if not latest['trend']:  # Only sell in downtrend
                return Signal(
                    type=SignalType.SELL,
                    symbol='',
                    strength=0.6,
                    price=price,
                    stop_loss=price + (atr * self.params['atr_mult']),
                    take_profit=price - (atr * self.params['atr_mult'] * 1.5)
                )

        return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=price)
```

### 3. Breakout Strategy

For trending markets and volatility expansion:

```python
class BreakoutStrategy(BaseStrategy):
    """
    Channel Breakout Strategy

    Entry: Price breaks above/below recent high/low
    Exit: Trailing stop or opposite breakout
    """

    def __init__(self, lookback=20, atr_period=14, atr_mult=2.0):
        super().__init__({
            'lookback': lookback,
            'atr_period': atr_period,
            'atr_mult': atr_mult
        })

    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        lookback = self.params['lookback']

        # Calculate channel
        df['channel_high'] = df['high'].rolling(window=lookback).max().shift(1)
        df['channel_low'] = df['low'].rolling(window=lookback).min().shift(1)
        df['channel_mid'] = (df['channel_high'] + df['channel_low']) / 2

        # ATR for position sizing and stops
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=self.params['atr_period'])

        # Breakout signals
        df['breakout_up'] = df['close'] > df['channel_high']
        df['breakout_down'] = df['close'] < df['channel_low']

        # Volume confirmation
        df['volume_sma'] = df['volume'].rolling(window=20).mean()
        df['volume_surge'] = df['volume'] > (df['volume_sma'] * 1.5)

        return df

    def generate_signal(self, df: pd.DataFrame, current_position: Optional[str] = None) -> Signal:
        df = self.calculate_indicators(df)
        latest = df.iloc[-1]

        price = latest['close']
        atr = latest['atr']

        # Upside breakout with volume confirmation
        if latest['breakout_up'] and latest['volume_surge']:
            if current_position != 'long':
                return Signal(
                    type=SignalType.BUY,
                    symbol='',
                    strength=0.8,
                    price=price,
                    stop_loss=latest['channel_mid'],
                    take_profit=price + (price - latest['channel_mid']) * 2,
                    metadata={'breakout_level': latest['channel_high']}
                )

        # Downside breakout with volume confirmation
        if latest['breakout_down'] and latest['volume_surge']:
            if current_position != 'short':
                return Signal(
                    type=SignalType.SELL,
                    symbol='',
                    strength=0.8,
                    price=price,
                    stop_loss=latest['channel_mid'],
                    take_profit=price - (latest['channel_mid'] - price) * 2,
                    metadata={'breakout_level': latest['channel_low']}
                )

        return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=price)
```

---

## Strategy Filters

Add filters to improve signal quality:

### Trend Filter

```python
class TrendFilter:
    """Only take signals in direction of major trend"""

    def __init__(self, ma_period=200):
        self.ma_period = ma_period

    def apply(self, df: pd.DataFrame, signal: Signal) -> Signal:
        df['trend_ma'] = ta.sma(df['close'], length=self.ma_period)
        is_uptrend = df['close'].iloc[-1] > df['trend_ma'].iloc[-1]

        if signal.type == SignalType.BUY and not is_uptrend:
            return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=signal.price)

        if signal.type == SignalType.SELL and is_uptrend:
            return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=signal.price)

        return signal
```

### Volatility Filter

```python
class VolatilityFilter:
    """Filter signals based on market volatility"""

    def __init__(self, atr_period=14, min_atr=None, max_atr=None):
        self.atr_period = atr_period
        self.min_atr = min_atr  # Minimum volatility required
        self.max_atr = max_atr  # Maximum volatility allowed

    def apply(self, df: pd.DataFrame, signal: Signal) -> Signal:
        atr = ta.atr(df['high'], df['low'], df['close'], length=self.atr_period).iloc[-1]
        price = df['close'].iloc[-1]
        atr_pct = atr / price * 100

        if self.min_atr and atr_pct < self.min_atr:
            return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=signal.price)

        if self.max_atr and atr_pct > self.max_atr:
            return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=signal.price)

        return signal
```

### Time Filter

```python
class TimeFilter:
    """Filter signals based on time of day"""

    def __init__(self, allowed_hours=None, blocked_hours=None):
        self.allowed_hours = allowed_hours  # e.g., [9, 10, 11, 14, 15, 16]
        self.blocked_hours = blocked_hours or []

    def apply(self, df: pd.DataFrame, signal: Signal) -> Signal:
        current_hour = df.index[-1].hour

        if self.allowed_hours and current_hour not in self.allowed_hours:
            return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=signal.price)

        if current_hour in self.blocked_hours:
            return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=signal.price)

        return signal
```

---

## Multi-Timeframe Strategy

Combine signals from multiple timeframes:

```python
class MultiTimeframeStrategy(BaseStrategy):
    """
    Use higher timeframe for trend, lower for entry
    """

    def __init__(self):
        super().__init__()
        self.trend_tf = '4h'  # Higher timeframe for trend
        self.entry_tf = '15m'  # Lower timeframe for entry

    def analyze_trend(self, df_high: pd.DataFrame) -> str:
        """Determine trend from higher timeframe"""
        df = df_high.copy()
        df['ema_20'] = ta.ema(df['close'], length=20)
        df['ema_50'] = ta.ema(df['close'], length=50)

        if df['ema_20'].iloc[-1] > df['ema_50'].iloc[-1]:
            return 'bullish'
        else:
            return 'bearish'

    def find_entry(self, df_low: pd.DataFrame, trend: str) -> Signal:
        """Find entry on lower timeframe in direction of trend"""
        df = df_low.copy()
        df['rsi'] = ta.rsi(df['close'], length=14)
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)

        latest = df.iloc[-1]
        price = latest['close']
        atr = latest['atr']

        # In bullish trend, look for pullback entries
        if trend == 'bullish' and latest['rsi'] < 40:
            return Signal(
                type=SignalType.BUY,
                symbol='',
                strength=0.7,
                price=price,
                stop_loss=price - (atr * 2),
                take_profit=price + (atr * 3)
            )

        # In bearish trend, look for rally entries
        if trend == 'bearish' and latest['rsi'] > 60:
            return Signal(
                type=SignalType.SELL,
                symbol='',
                strength=0.7,
                price=price,
                stop_loss=price + (atr * 2),
                take_profit=price - (atr * 3)
            )

        return Signal(type=SignalType.NONE, symbol='', strength=0.0, price=price)
```

---

## Strategy Optimization

### Parameter Ranges

Define reasonable parameter ranges for optimization:

```python
class StrategyOptimizer:
    def __init__(self, strategy_class):
        self.strategy_class = strategy_class

    def define_param_space(self):
        """Define parameter search space"""
        return {
            'fast_period': range(5, 30, 5),
            'slow_period': range(20, 100, 10),
            'atr_multiplier': [1.0, 1.5, 2.0, 2.5, 3.0]
        }

    def grid_search(self, df, param_space):
        """Exhaustive search over parameter grid"""
        from itertools import product

        results = []
        param_names = list(param_space.keys())
        param_values = list(param_space.values())

        for combination in product(*param_values):
            params = dict(zip(param_names, combination))

            # Skip invalid combinations
            if params.get('fast_period', 0) >= params.get('slow_period', float('inf')):
                continue

            strategy = self.strategy_class(**params)
            # Run backtest and record results
            # performance = backtest(strategy, df)
            # results.append({'params': params, 'performance': performance})

        return sorted(results, key=lambda x: x['performance'], reverse=True)
```

### Walk-Forward Optimization

Prevent overfitting with walk-forward analysis:

```python
def walk_forward_optimize(df, strategy_class, param_space,
                          in_sample_size=252, out_sample_size=63):
    """
    Walk-forward optimization:
    1. Optimize on in-sample period
    2. Test on out-of-sample period
    3. Roll forward and repeat
    """
    results = []
    start = 0

    while start + in_sample_size + out_sample_size <= len(df):
        # In-sample optimization
        in_sample = df.iloc[start:start + in_sample_size]
        best_params = optimize_params(strategy_class, in_sample, param_space)

        # Out-of-sample testing
        out_sample = df.iloc[start + in_sample_size:start + in_sample_size + out_sample_size]
        strategy = strategy_class(**best_params)
        performance = backtest(strategy, out_sample)

        results.append({
            'period': df.index[start + in_sample_size],
            'params': best_params,
            'performance': performance
        })

        # Roll forward
        start += out_sample_size

    return results
```

---

## Strategy Checklist

Before deploying any strategy, verify:

### Logic Verification
- [ ] Entry logic is clear and unambiguous
- [ ] Exit logic covers all scenarios (profit, loss, time)
- [ ] No look-ahead bias in indicator calculations
- [ ] Stop loss is always defined
- [ ] Position sizing is appropriate

### Testing
- [ ] Backtested on multiple market conditions
- [ ] Out-of-sample testing performed
- [ ] Parameter sensitivity analyzed
- [ ] Drawdown analysis completed
- [ ] Monte Carlo simulation run

### Risk Checks
- [ ] Maximum drawdown acceptable
- [ ] Largest losing streak survivable
- [ ] Complies with prop firm rules
- [ ] Risk per trade defined
- [ ] Maximum exposure limited

### Implementation
- [ ] Code is clean and documented
- [ ] Error handling is robust
- [ ] Logging is comprehensive
- [ ] Paper trading completed
- [ ] Monitoring alerts configured

---

## Summary

Key principles for strategy development:

1. **Start simple** - Complex doesn't mean better
2. **Define clear rules** - No ambiguity in entry/exit
3. **Always use stops** - Protect your capital
4. **Filter aggressively** - Quality over quantity
5. **Test thoroughly** - Backtest, paper trade, then live
6. **Optimize carefully** - Avoid overfitting
7. **Document everything** - Future you will thank you

---

*Next: [04-backtesting.md](./04-backtesting.md) - Testing strategies on historical data*
