# 06 - Prop Firm Rules

> **Understanding and adapting your trading bot to prop firm constraints**

---

## Overview

Proprietary trading firms (prop firms) provide capital to traders who can demonstrate consistent profitability. They have strict rules designed to protect their capital. Understanding and strictly adhering to these rules is critical for success.

---

## How Prop Firms Work

### The Challenge/Evaluation Process

Most crypto prop firms follow this model:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Challenge     │────▶│  Verification   │────▶│  Funded Account │
│   (Phase 1)     │     │  (Phase 2)      │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
      ↓                       ↓                       ↓
  - Prove skill         - Confirm skill         - Real capital
  - Hit profit target   - Lower target          - Profit split
  - Respect DD limits   - Same DD limits        - Ongoing rules
```

### Typical Structure

| Phase | Profit Target | Daily DD | Max DD | Min Days | Fees |
|-------|---------------|----------|--------|----------|------|
| Challenge | 8-10% | 5% | 10% | 4-5 | Yes |
| Verification | 5% | 5% | 10% | 4-5 | No |
| Funded | None | 5% | 10% | - | No |

---

## Common Rules

### 1. Daily Drawdown Limit

**Definition:** Maximum loss allowed from the day's starting balance.

```python
def calculate_daily_drawdown(starting_balance_today, current_equity):
    """
    Daily DD = (Starting Balance - Lowest Point Today) / Starting Balance

    Example:
    - Day starts at $100,000
    - Equity drops to $96,000
    - Daily DD = ($100,000 - $96,000) / $100,000 = 4%
    """
    drawdown = (starting_balance_today - current_equity) / starting_balance_today
    return max(0, drawdown)
```

**Key Points:**
- Resets at a specific time (often midnight UTC or server time)
- Includes unrealized P&L (open positions count)
- Breaching this = instant failure
- Some firms use "trailing" daily DD

### 2. Maximum/Total Drawdown Limit

**Definition:** Maximum loss allowed from initial balance or high water mark.

```python
def calculate_max_drawdown(reference_balance, current_equity, is_trailing=False, high_water_mark=None):
    """
    Max DD can be:
    - Static: measured from initial balance
    - Trailing: measured from highest equity achieved

    Example (Static):
    - Initial: $100,000
    - Current: $92,000
    - Max DD = ($100,000 - $92,000) / $100,000 = 8%

    Example (Trailing):
    - Initial: $100,000
    - Peak reached: $105,000
    - Current: $96,000
    - Trailing DD = ($105,000 - $96,000) / $105,000 = 8.6%
    """
    if is_trailing and high_water_mark:
        reference = high_water_mark
    else:
        reference = reference_balance

    drawdown = (reference - current_equity) / reference
    return max(0, drawdown)
```

**Trailing vs Static:**
- **Static (Better for traders):** Drawdown measured from initial balance
- **Trailing (More restrictive):** Drawdown measured from highest equity

### 3. Profit Targets

**Challenge Phase:**
- Typically 8-10% of account
- Must be achieved within time limit (usually 30 days)
- Reaching target advances to next phase

**Verification Phase:**
- Typically 5% (lower than challenge)
- Same time and DD limits
- Passing grants funded account

### 4. Minimum Trading Days

**Purpose:** Ensure consistent trading, not lucky one-time bets.

```python
def check_minimum_trading_days(trading_days, required_days=5):
    """
    A trading day typically requires:
    - At least one trade opened OR
    - At least one trade closed

    Some firms require minimum trade size
    """
    return len(trading_days) >= required_days


def is_valid_trading_day(trades_today, min_lot_size=0.01):
    """Check if today counts as a trading day"""
    for trade in trades_today:
        if trade['size'] >= min_lot_size:
            return True
    return False
```

### 5. Position Size Limits

Some firms impose:
- Maximum lot size per trade
- Maximum total exposure
- Maximum positions open simultaneously

```python
class PropFirmLimits:
    def __init__(self, config):
        self.max_position_size = config.get('max_position_size', float('inf'))
        self.max_exposure = config.get('max_exposure', 1.0)  # 100%
        self.max_positions = config.get('max_positions', float('inf'))

    def validate_order(self, order_size, current_exposure, open_positions):
        """Validate order against prop firm limits"""
        errors = []

        if order_size > self.max_position_size:
            errors.append(f"Order size {order_size} exceeds max {self.max_position_size}")

        if current_exposure + order_size > self.max_exposure:
            errors.append(f"Would exceed max exposure {self.max_exposure}")

        if len(open_positions) >= self.max_positions:
            errors.append(f"Max positions {self.max_positions} reached")

        return len(errors) == 0, errors
```

### 6. Prohibited Actions

Common restrictions:
- **News trading:** No trades during major news events
- **Weekend holding:** Must close positions before weekend
- **Copy trading:** Cannot copy signals from other traders
- **Hedging:** Cannot hold opposing positions
- **Martingale:** Cannot use martingale position sizing

```python
class TradingRestrictions:
    def __init__(self, config):
        self.no_news_trading = config.get('no_news_trading', True)
        self.no_weekend_holding = config.get('no_weekend_holding', True)
        self.no_hedging = config.get('no_hedging', True)

    def check_news_restriction(self, current_time, news_calendar):
        """Check if trading is restricted due to news"""
        # Check for high-impact news within 15 minutes
        for event in news_calendar:
            if abs((event['time'] - current_time).total_seconds()) < 900:
                if event['impact'] == 'high':
                    return False, f"High-impact news: {event['name']}"
        return True, None

    def check_weekend_restriction(self, current_time, open_positions):
        """Check weekend position restriction"""
        # Friday after 22:00 UTC
        if current_time.weekday() == 4 and current_time.hour >= 22:
            if open_positions:
                return False, "Must close positions before weekend"
        return True, None
```

---

## Implementing Prop Firm Rules

### Complete Prop Firm Rules Engine

```python
from datetime import datetime, time
from enum import Enum
from typing import Dict, List, Optional, Tuple

class RuleViolation(Enum):
    DAILY_DD_EXCEEDED = "Daily drawdown limit exceeded"
    MAX_DD_EXCEEDED = "Maximum drawdown limit exceeded"
    PROFIT_TARGET_NOT_MET = "Profit target not met in time"
    MIN_DAYS_NOT_MET = "Minimum trading days not met"
    NEWS_RESTRICTION = "Trading during news event"
    WEEKEND_RESTRICTION = "Weekend position restriction"
    POSITION_LIMIT = "Position size/count limit exceeded"
    HEDGING_VIOLATION = "Hedging not allowed"


class PropFirmRulesEngine:
    """
    Complete rules engine for prop firm compliance

    Checks all rules before allowing trades
    Tracks violations and account status
    """

    def __init__(self, config: Dict):
        # Account settings
        self.initial_balance = config['initial_balance']
        self.current_balance = config['initial_balance']
        self.high_water_mark = config['initial_balance']

        # Drawdown limits
        self.max_daily_dd = config.get('max_daily_dd', 0.05)
        self.max_total_dd = config.get('max_total_dd', 0.10)
        self.trailing_dd = config.get('trailing_dd', False)

        # Profit target
        self.profit_target = config.get('profit_target', 0.08)
        self.challenge_deadline = config.get('deadline')  # datetime

        # Trading requirements
        self.min_trading_days = config.get('min_trading_days', 5)
        self.trading_days = set()

        # Position limits
        self.max_position_size = config.get('max_position_size', float('inf'))
        self.max_positions = config.get('max_positions', float('inf'))
        self.max_exposure_pct = config.get('max_exposure_pct', 1.0)

        # Restrictions
        self.no_news_trading = config.get('no_news_trading', False)
        self.no_weekend_holding = config.get('no_weekend_holding', False)
        self.no_hedging = config.get('no_hedging', True)

        # State
        self.daily_start_balance = config['initial_balance']
        self.current_date = None
        self.open_positions = {}
        self.violations = []
        self.account_status = "ACTIVE"  # ACTIVE, PASSED, FAILED

    def update_balance(self, new_balance: float, current_time: datetime):
        """Update account balance and check rules"""
        # Handle day change
        current_date = current_time.date()
        if self.current_date != current_date:
            self.current_date = current_date
            self.daily_start_balance = self.current_balance

        self.current_balance = new_balance

        # Update high water mark
        if new_balance > self.high_water_mark:
            self.high_water_mark = new_balance

        # Check drawdown rules
        self._check_drawdown_rules()

        return self.account_status

    def _check_drawdown_rules(self):
        """Check if drawdown limits are breached"""
        # Daily drawdown
        daily_dd = self._calculate_daily_dd()
        if daily_dd >= self.max_daily_dd:
            self._record_violation(RuleViolation.DAILY_DD_EXCEEDED)
            self.account_status = "FAILED"
            return

        # Maximum drawdown
        total_dd = self._calculate_total_dd()
        if total_dd >= self.max_total_dd:
            self._record_violation(RuleViolation.MAX_DD_EXCEEDED)
            self.account_status = "FAILED"
            return

    def _calculate_daily_dd(self) -> float:
        """Calculate current daily drawdown"""
        if self.daily_start_balance == 0:
            return 0
        dd = (self.daily_start_balance - self.current_balance) / self.daily_start_balance
        return max(0, dd)

    def _calculate_total_dd(self) -> float:
        """Calculate total drawdown"""
        reference = self.high_water_mark if self.trailing_dd else self.initial_balance
        if reference == 0:
            return 0
        dd = (reference - self.current_balance) / reference
        return max(0, dd)

    def can_open_trade(self, symbol: str, direction: str, size: float,
                        current_time: datetime, news_events: List = None) -> Tuple[bool, str]:
        """
        Check if a trade is allowed under all rules

        Returns: (allowed, reason)
        """
        # Check account status
        if self.account_status != "ACTIVE":
            return False, f"Account status: {self.account_status}"

        # Check drawdown headroom
        daily_dd = self._calculate_daily_dd()
        if daily_dd >= self.max_daily_dd * 0.9:  # 90% of limit
            return False, "Approaching daily drawdown limit"

        total_dd = self._calculate_total_dd()
        if total_dd >= self.max_total_dd * 0.9:
            return False, "Approaching maximum drawdown limit"

        # Check position limits
        if len(self.open_positions) >= self.max_positions:
            return False, f"Maximum positions ({self.max_positions}) reached"

        if size > self.max_position_size:
            return False, f"Position size {size} exceeds limit {self.max_position_size}"

        # Check hedging
        if self.no_hedging and symbol in self.open_positions:
            existing = self.open_positions[symbol]
            if existing['direction'] != direction:
                return False, "Hedging not allowed"

        # Check news restriction
        if self.no_news_trading and news_events:
            can_trade, reason = self._check_news(current_time, news_events)
            if not can_trade:
                return False, reason

        # Check weekend restriction
        if self.no_weekend_holding:
            can_trade, reason = self._check_weekend(current_time)
            if not can_trade:
                return False, reason

        return True, "Trade allowed"

    def _check_news(self, current_time: datetime, events: List) -> Tuple[bool, str]:
        """Check for high-impact news"""
        buffer_minutes = 15
        for event in events:
            time_diff = abs((event['time'] - current_time).total_seconds() / 60)
            if time_diff < buffer_minutes and event['impact'] == 'high':
                return False, f"High-impact news in {time_diff:.0f} minutes"
        return True, None

    def _check_weekend(self, current_time: datetime) -> Tuple[bool, str]:
        """Check weekend restrictions"""
        # No new trades Friday after 20:00 UTC
        if current_time.weekday() == 4 and current_time.hour >= 20:
            return False, "No new trades before weekend"
        # No trades on weekend
        if current_time.weekday() in [5, 6]:
            return False, "No weekend trading"
        return True, None

    def record_trade(self, symbol: str, direction: str, size: float, entry_price: float):
        """Record a new trade"""
        self.open_positions[symbol] = {
            'direction': direction,
            'size': size,
            'entry_price': entry_price
        }
        # Record trading day
        self.trading_days.add(self.current_date)

    def close_trade(self, symbol: str):
        """Record trade closure"""
        if symbol in self.open_positions:
            del self.open_positions[symbol]

    def check_profit_target(self) -> Tuple[bool, float]:
        """Check if profit target is met"""
        current_profit = (self.current_balance - self.initial_balance) / self.initial_balance
        target_met = current_profit >= self.profit_target
        return target_met, current_profit

    def check_challenge_complete(self) -> Tuple[bool, str]:
        """Check if challenge requirements are met"""
        # Check profit target
        target_met, profit = self.check_profit_target()
        if not target_met:
            return False, f"Profit: {profit:.2%} (need {self.profit_target:.2%})"

        # Check minimum trading days
        if len(self.trading_days) < self.min_trading_days:
            return False, f"Trading days: {len(self.trading_days)} (need {self.min_trading_days})"

        # Check no violations
        if self.account_status == "FAILED":
            return False, "Account failed due to rule violation"

        return True, "Challenge requirements met!"

    def _record_violation(self, violation: RuleViolation):
        """Record a rule violation"""
        self.violations.append({
            'type': violation,
            'time': datetime.now(),
            'balance': self.current_balance,
            'daily_dd': self._calculate_daily_dd(),
            'total_dd': self._calculate_total_dd()
        })

    def get_status(self) -> Dict:
        """Get comprehensive status report"""
        target_met, profit = self.check_profit_target()

        return {
            'account_status': self.account_status,
            'current_balance': self.current_balance,
            'initial_balance': self.initial_balance,
            'high_water_mark': self.high_water_mark,
            'current_profit_pct': profit,
            'profit_target_pct': self.profit_target,
            'profit_target_met': target_met,
            'daily_drawdown_pct': self._calculate_daily_dd(),
            'max_daily_dd_pct': self.max_daily_dd,
            'total_drawdown_pct': self._calculate_total_dd(),
            'max_total_dd_pct': self.max_total_dd,
            'trading_days': len(self.trading_days),
            'min_trading_days': self.min_trading_days,
            'open_positions': len(self.open_positions),
            'violations': len(self.violations),
            'daily_dd_remaining': self.max_daily_dd - self._calculate_daily_dd(),
            'total_dd_remaining': self.max_total_dd - self._calculate_total_dd(),
        }


# Example usage
config = {
    'initial_balance': 100000,
    'max_daily_dd': 0.05,
    'max_total_dd': 0.10,
    'trailing_dd': False,
    'profit_target': 0.08,
    'min_trading_days': 5,
    'max_positions': 5,
    'no_hedging': True,
    'no_news_trading': True,
    'no_weekend_holding': True,
}

rules_engine = PropFirmRulesEngine(config)
```

---

## Strategy Adjustments for Prop Firms

### Conservative vs Aggressive Approach

**Conservative (Recommended for challenges):**
- Lower risk per trade (0.5-1%)
- Higher R:R ratio (2:1 or better)
- Fewer trades, higher quality
- Focus on not losing rather than winning big

**Aggressive (Risky):**
- Higher risk per trade (1-2%)
- Standard R:R (1.5:1)
- More trades
- Higher chance of hitting target fast
- Higher chance of failing

### Recommended Approach

```python
class PropFirmStrategy:
    """Strategy adjustments for prop firm trading"""

    def __init__(self, phase='challenge'):
        self.phase = phase

        if phase == 'challenge':
            # More conservative during challenge
            self.risk_per_trade = 0.005  # 0.5%
            self.min_rr_ratio = 2.0
            self.max_trades_per_day = 3
        elif phase == 'verification':
            # Slightly more relaxed
            self.risk_per_trade = 0.0075  # 0.75%
            self.min_rr_ratio = 1.5
            self.max_trades_per_day = 4
        else:  # funded
            # Standard trading
            self.risk_per_trade = 0.01  # 1%
            self.min_rr_ratio = 1.5
            self.max_trades_per_day = 5

    def should_trade(self, rules_engine, signal):
        """Determine if we should take this trade"""
        status = rules_engine.get_status()

        # If close to drawdown limit, don't trade
        if status['daily_dd_remaining'] < 0.02:  # Less than 2% remaining
            return False, "Too close to daily DD limit"

        if status['total_dd_remaining'] < 0.03:  # Less than 3% remaining
            return False, "Too close to total DD limit"

        # If already profitable enough today, consider stopping
        if status['current_profit_pct'] >= self.calculate_daily_target(status):
            return False, "Daily profit target reached - consider stopping"

        return True, "Trade conditions acceptable"

    def calculate_daily_target(self, status):
        """Calculate sensible daily profit target"""
        remaining_to_target = status['profit_target_pct'] - status['current_profit_pct']
        days_remaining = 20  # Assume 20 trading days in challenge

        # Aim for slightly more than average needed
        daily_target = (remaining_to_target / days_remaining) * 1.2

        return min(0.02, daily_target)  # Cap at 2% per day
```

---

## Common Mistakes to Avoid

1. **Trading too large** - Even one oversized loss can end your challenge
2. **Overtrading** - Quality over quantity
3. **Ignoring drawdown cushion** - Don't use all your allowed drawdown
4. **Weekend gaps** - Close positions before Friday close
5. **News trading** - Avoid high-impact news if restricted
6. **Revenge trading** - Don't try to recover losses aggressively
7. **Moving stop losses** - Honor your original stop
8. **Forgetting minimum days** - Spread trades across multiple days

---

## Summary

Prop firm success requires:

1. **Know the rules** - Read every rule carefully
2. **Track everything** - Monitor DD constantly
3. **Trade conservatively** - Especially during challenge
4. **Consistency** - Small daily gains add up
5. **Risk management first** - Never risk the account
6. **Patience** - Don't rush the process

---

*Next: [07-exchange-integration.md](./07-exchange-integration.md) - Connecting to crypto exchanges*
