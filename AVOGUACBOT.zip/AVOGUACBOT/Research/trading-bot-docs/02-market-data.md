# 02 - Market Data

> **Obtaining, processing, and managing market data for your trading bot**

---

## Overview

Quality market data is the foundation of any trading system. This document covers how to obtain real-time and historical data, process it into usable formats, and store it efficiently.

---

## Data Types

### OHLCV Data (Candlesticks)

The most common data format for technical analysis:

| Field | Description |
|-------|-------------|
| **O**pen | Price at candle open |
| **H**igh | Highest price during period |
| **L**ow | Lowest price during period |
| **C**lose | Price at candle close |
| **V**olume | Total volume traded |

```python
import pandas as pd

# Example OHLCV DataFrame structure
ohlcv_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']

# Sample data
data = [
    [1704067200000, 42150.0, 42300.0, 42100.0, 42250.0, 1500.5],
    [1704067260000, 42250.0, 42400.0, 42200.0, 42380.0, 1200.3],
]

df = pd.DataFrame(data, columns=ohlcv_columns)
df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
df.set_index('timestamp', inplace=True)
```

### Tick Data

Individual trades as they occur:

```python
tick_data = {
    'timestamp': 1704067200123,
    'price': 42150.50,
    'amount': 0.5,
    'side': 'buy',  # or 'sell'
    'trade_id': '123456789'
}
```

### Order Book Data

Current bids and asks:

```python
orderbook = {
    'bids': [
        [42100.0, 1.5],   # [price, amount]
        [42099.0, 2.3],
        [42098.0, 0.8],
    ],
    'asks': [
        [42101.0, 1.2],
        [42102.0, 0.9],
        [42103.0, 3.1],
    ],
    'timestamp': 1704067200000
}
```

---

## Data Sources

### Using CCXT for Data Retrieval

CCXT (CryptoCurrency eXchange Trading) provides a unified API for 100+ exchanges.

```python
import ccxt
import pandas as pd

class DataFetcher:
    def __init__(self, exchange_id='binance'):
        self.exchange = ccxt.binance({
            'enableRateLimit': True,
        })

    def fetch_ohlcv(self, symbol, timeframe='1h', limit=100):
        """Fetch OHLCV data from exchange"""
        ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)

        df = pd.DataFrame(
            ohlcv,
            columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
        )
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)

        return df

    def fetch_historical(self, symbol, timeframe, start_date, end_date=None):
        """Fetch historical data in chunks"""
        all_ohlcv = []
        since = self.exchange.parse8601(start_date)

        while True:
            ohlcv = self.exchange.fetch_ohlcv(
                symbol, timeframe, since=since, limit=1000
            )

            if not ohlcv:
                break

            all_ohlcv.extend(ohlcv)
            since = ohlcv[-1][0] + 1  # Next millisecond

            # Rate limiting
            self.exchange.sleep(self.exchange.rateLimit)

            # Check if we've reached end_date
            if end_date:
                end_ts = self.exchange.parse8601(end_date)
                if since >= end_ts:
                    break

        return self._to_dataframe(all_ohlcv)

    def _to_dataframe(self, ohlcv):
        df = pd.DataFrame(
            ohlcv,
            columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
        )
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)
        df = df[~df.index.duplicated(keep='first')]  # Remove duplicates
        return df


# Usage
fetcher = DataFetcher('binance')
btc_data = fetcher.fetch_ohlcv('BTC/USDT', '15m', limit=500)
```

### Real-Time Data with WebSockets

For live trading, WebSocket connections provide lower latency than REST polling:

```python
import ccxt.pro as ccxtpro
import asyncio

class RealTimeDataFeed:
    def __init__(self, exchange_id='binance'):
        self.exchange = ccxtpro.binance()
        self.ohlcv_data = {}
        self.running = False

    async def watch_ohlcv(self, symbol, timeframe='1m'):
        """Subscribe to OHLCV updates"""
        while self.running:
            try:
                ohlcv = await self.exchange.watch_ohlcv(symbol, timeframe)
                self.ohlcv_data[symbol] = ohlcv
                await self.on_candle_update(symbol, ohlcv[-1])
            except Exception as e:
                print(f"Error watching {symbol}: {e}")
                await asyncio.sleep(5)  # Wait before retry

    async def watch_trades(self, symbol):
        """Subscribe to trade updates"""
        while self.running:
            try:
                trades = await self.exchange.watch_trades(symbol)
                for trade in trades:
                    await self.on_trade(symbol, trade)
            except Exception as e:
                print(f"Error watching trades for {symbol}: {e}")
                await asyncio.sleep(5)

    async def watch_orderbook(self, symbol):
        """Subscribe to orderbook updates"""
        while self.running:
            try:
                orderbook = await self.exchange.watch_order_book(symbol)
                await self.on_orderbook(symbol, orderbook)
            except Exception as e:
                print(f"Error watching orderbook for {symbol}: {e}")
                await asyncio.sleep(5)

    async def on_candle_update(self, symbol, candle):
        """Override to handle candle updates"""
        pass

    async def on_trade(self, symbol, trade):
        """Override to handle trade updates"""
        pass

    async def on_orderbook(self, symbol, orderbook):
        """Override to handle orderbook updates"""
        pass

    async def start(self, symbols, timeframe='1m'):
        """Start watching multiple symbols"""
        self.running = True
        tasks = []
        for symbol in symbols:
            tasks.append(self.watch_ohlcv(symbol, timeframe))
            tasks.append(self.watch_trades(symbol))
        await asyncio.gather(*tasks)

    async def stop(self):
        """Stop all data feeds"""
        self.running = False
        await self.exchange.close()


# Usage
async def main():
    feed = RealTimeDataFeed()
    await feed.start(['BTC/USDT', 'ETH/USDT'], '15m')

# asyncio.run(main())
```

---

## Timeframes

### Common Timeframes

| Timeframe | Use Case |
|-----------|----------|
| 1m | Scalping, precise entries |
| 5m | Short-term trading |
| 15m | Intraday trading, common for prop firms |
| 1h | Swing trading |
| 4h | Medium-term trends |
| 1d | Long-term analysis |

### Multi-Timeframe Analysis

Analyzing multiple timeframes can improve signal quality:

```python
class MultiTimeframeData:
    def __init__(self, exchange):
        self.exchange = exchange
        self.data = {}

    def fetch_multi_timeframe(self, symbol, timeframes=['15m', '1h', '4h']):
        """Fetch data for multiple timeframes"""
        for tf in timeframes:
            self.data[tf] = self.exchange.fetch_ohlcv(symbol, tf, limit=200)

        return self.data

    def resample_to_higher(self, df, target_timeframe):
        """Resample lower timeframe to higher"""
        resampled = df.resample(target_timeframe).agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        })
        return resampled.dropna()
```

---

## Data Quality

### Common Data Issues

1. **Missing candles** - Gaps in data
2. **Duplicate entries** - Same timestamp appears twice
3. **Outliers** - Extreme prices from flash crashes
4. **Timezone issues** - Inconsistent timestamps

### Data Cleaning

```python
class DataCleaner:
    def clean_ohlcv(self, df):
        """Clean and validate OHLCV data"""
        df = df.copy()

        # Remove duplicates
        df = df[~df.index.duplicated(keep='first')]

        # Sort by timestamp
        df = df.sort_index()

        # Validate OHLC relationships
        # High should be >= Open, Close, Low
        # Low should be <= Open, Close, High
        invalid_mask = (
            (df['high'] < df['open']) |
            (df['high'] < df['close']) |
            (df['low'] > df['open']) |
            (df['low'] > df['close']) |
            (df['high'] < df['low'])
        )

        if invalid_mask.any():
            print(f"Found {invalid_mask.sum()} invalid candles")
            # Fix by adjusting high/low
            df.loc[invalid_mask, 'high'] = df.loc[invalid_mask, ['open', 'high', 'low', 'close']].max(axis=1)
            df.loc[invalid_mask, 'low'] = df.loc[invalid_mask, ['open', 'high', 'low', 'close']].min(axis=1)

        # Remove zero or negative volumes
        df = df[df['volume'] > 0]

        # Forward fill small gaps (1-2 candles)
        df = df.resample(df.index.freq or '1min').ffill(limit=2)

        return df

    def detect_outliers(self, df, z_threshold=4):
        """Detect price outliers using z-score"""
        from scipy import stats

        z_scores = stats.zscore(df['close'])
        outliers = abs(z_scores) > z_threshold

        return df[outliers].index.tolist()

    def fill_gaps(self, df, expected_freq='1min'):
        """Identify and optionally fill gaps in data"""
        expected_index = pd.date_range(
            start=df.index.min(),
            end=df.index.max(),
            freq=expected_freq
        )

        missing = expected_index.difference(df.index)

        if len(missing) > 0:
            print(f"Found {len(missing)} missing candles")

        return missing
```

---

## Data Storage

### In-Memory (for live trading)

```python
from collections import deque

class CandleBuffer:
    def __init__(self, max_length=1000):
        self.candles = deque(maxlen=max_length)

    def add(self, candle):
        self.candles.append(candle)

    def to_dataframe(self):
        return pd.DataFrame(list(self.candles))

    def get_last(self, n=1):
        return list(self.candles)[-n:]
```

### Database Storage (for backtesting and analysis)

#### SQLite (Simple, File-Based)

```python
import sqlite3

class SQLiteStorage:
    def __init__(self, db_path='market_data.db'):
        self.conn = sqlite3.connect(db_path)
        self.create_tables()

    def create_tables(self):
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS ohlcv (
                symbol TEXT,
                timeframe TEXT,
                timestamp INTEGER,
                open REAL,
                high REAL,
                low REAL,
                close REAL,
                volume REAL,
                PRIMARY KEY (symbol, timeframe, timestamp)
            )
        ''')
        self.conn.execute('''
            CREATE INDEX IF NOT EXISTS idx_ohlcv_lookup
            ON ohlcv (symbol, timeframe, timestamp)
        ''')
        self.conn.commit()

    def save_ohlcv(self, symbol, timeframe, df):
        records = []
        for timestamp, row in df.iterrows():
            records.append((
                symbol, timeframe,
                int(timestamp.timestamp() * 1000),
                row['open'], row['high'], row['low'],
                row['close'], row['volume']
            ))

        self.conn.executemany('''
            INSERT OR REPLACE INTO ohlcv
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', records)
        self.conn.commit()

    def load_ohlcv(self, symbol, timeframe, start_ts=None, end_ts=None):
        query = '''
            SELECT timestamp, open, high, low, close, volume
            FROM ohlcv
            WHERE symbol = ? AND timeframe = ?
        '''
        params = [symbol, timeframe]

        if start_ts:
            query += ' AND timestamp >= ?'
            params.append(start_ts)
        if end_ts:
            query += ' AND timestamp <= ?'
            params.append(end_ts)

        query += ' ORDER BY timestamp'

        df = pd.read_sql_query(query, self.conn, params=params)
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)

        return df
```

#### TimescaleDB (Production-Ready)

For production systems handling large amounts of data:

```python
import psycopg2
from sqlalchemy import create_engine

class TimescaleStorage:
    def __init__(self, connection_string):
        self.engine = create_engine(connection_string)

    def create_hypertable(self):
        """Create TimescaleDB hypertable for efficient time-series storage"""
        with self.engine.connect() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS ohlcv (
                    time TIMESTAMPTZ NOT NULL,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    open DOUBLE PRECISION,
                    high DOUBLE PRECISION,
                    low DOUBLE PRECISION,
                    close DOUBLE PRECISION,
                    volume DOUBLE PRECISION
                );

                SELECT create_hypertable('ohlcv', 'time', if_not_exists => TRUE);

                CREATE INDEX IF NOT EXISTS idx_ohlcv_symbol_time
                ON ohlcv (symbol, timeframe, time DESC);
            ''')

    def save_ohlcv(self, symbol, timeframe, df):
        df = df.copy()
        df['symbol'] = symbol
        df['timeframe'] = timeframe
        df.reset_index(inplace=True)
        df.rename(columns={'timestamp': 'time'}, inplace=True)

        df.to_sql('ohlcv', self.engine, if_exists='append', index=False)
```

---

## Building OHLCV from Ticks

If you need to build candles from tick data:

```python
class TickAggregator:
    def __init__(self, timeframe_seconds=60):
        self.timeframe_seconds = timeframe_seconds
        self.current_candle = None
        self.completed_candles = []

    def process_tick(self, tick):
        """Process a single tick and update candle"""
        tick_time = tick['timestamp']
        price = tick['price']
        volume = tick['amount']

        # Calculate candle start time
        candle_start = (tick_time // (self.timeframe_seconds * 1000)) * (self.timeframe_seconds * 1000)

        if self.current_candle is None or self.current_candle['timestamp'] != candle_start:
            # New candle
            if self.current_candle:
                self.completed_candles.append(self.current_candle)

            self.current_candle = {
                'timestamp': candle_start,
                'open': price,
                'high': price,
                'low': price,
                'close': price,
                'volume': volume
            }
        else:
            # Update current candle
            self.current_candle['high'] = max(self.current_candle['high'], price)
            self.current_candle['low'] = min(self.current_candle['low'], price)
            self.current_candle['close'] = price
            self.current_candle['volume'] += volume

        return self.current_candle

    def get_completed_candles(self):
        """Return all completed candles"""
        return self.completed_candles
```

---

## Best Practices

### 1. Handle Rate Limits
```python
import time

class RateLimitedFetcher:
    def __init__(self, exchange, calls_per_second=3):
        self.exchange = exchange
        self.min_interval = 1.0 / calls_per_second
        self.last_call = 0

    def fetch(self, *args, **kwargs):
        elapsed = time.time() - self.last_call
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)

        result = self.exchange.fetch_ohlcv(*args, **kwargs)
        self.last_call = time.time()
        return result
```

### 2. Implement Reconnection Logic
```python
async def robust_websocket_connection(self, symbol, max_retries=5):
    retries = 0
    while retries < max_retries:
        try:
            await self.exchange.watch_ohlcv(symbol, '1m')
            retries = 0  # Reset on success
        except Exception as e:
            retries += 1
            wait_time = min(60, 2 ** retries)  # Exponential backoff
            print(f"Connection failed, retry {retries} in {wait_time}s")
            await asyncio.sleep(wait_time)
```

### 3. Validate Incoming Data
```python
def validate_candle(self, candle):
    """Validate a single candle"""
    required_fields = ['timestamp', 'open', 'high', 'low', 'close', 'volume']

    for field in required_fields:
        if field not in candle or candle[field] is None:
            return False

    if candle['high'] < candle['low']:
        return False

    if candle['volume'] < 0:
        return False

    return True
```

### 4. Use Appropriate Timeframes
- Don't fetch 1-minute data if your strategy uses 15-minute candles
- Higher timeframes = less data, faster backtests
- Match your data timeframe to your strategy timeframe

---

## Summary

Key points for handling market data:

1. **Use CCXT** for unified exchange access
2. **WebSockets** for real-time data, REST for historical
3. **Clean your data** - check for gaps, duplicates, outliers
4. **Store efficiently** - in-memory for live, database for historical
5. **Handle errors gracefully** - rate limits, disconnections
6. **Match timeframes** to your strategy needs

---

*Next: [03-strategy-development.md](./03-strategy-development.md) - Building trading strategies*
