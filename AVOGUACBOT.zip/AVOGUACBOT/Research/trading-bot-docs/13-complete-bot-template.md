# 13 - Complete Trading Bot Template

> **Full working implementation with all components integrated**

---

## Overview

This document provides a complete, production-ready trading bot template. Copy and customize for your needs.

---

## Project Structure

```
trading-bot/
├── config/
│   ├── __init__.py
│   ├── settings.py
│   └── logging_config.py
├── src/
│   ├── __init__.py
│   ├── main.py                 # Entry point
│   ├── core/
│   │   ├── __init__.py
│   │   ├── engine.py           # Main trading engine
│   │   ├── events.py           # Event system
│   │   └── state.py            # State management
│   ├── data/
│   │   ├── __init__.py
│   │   ├── feed.py             # Market data feed
│   │   └── storage.py          # Data persistence
│   ├── strategy/
│   │   ├── __init__.py
│   │   ├── base.py             # Base strategy class
│   │   └── ma_crossover.py     # Example strategy
│   ├── risk/
│   │   ├── __init__.py
│   │   ├── manager.py          # Risk management
│   │   ├── position_sizer.py   # Position sizing
│   │   └── prop_firm.py        # Prop firm rules
│   ├── execution/
│   │   ├── __init__.py
│   │   ├── order_manager.py    # Order handling
│   │   └── exchange.py         # Exchange connector
│   └── utils/
│       ├── __init__.py
│       ├── logger.py           # Logging
│       └── notifications.py    # Alerts
├── tests/
├── requirements.txt
├── docker-compose.yml
├── Dockerfile
└── .env.example
```

---

## Configuration (config/settings.py)

```python
"""
Configuration management for the trading bot
"""
import os
from dataclasses import dataclass, field
from typing import List, Optional
from dotenv import load_dotenv

load_dotenv()


@dataclass
class ExchangeConfig:
    """Exchange connection configuration"""
    exchange_id: str = 'binance'
    api_key: str = ''
    api_secret: str = ''
    testnet: bool = True
    market_type: str = 'future'  # 'spot' or 'future'


@dataclass
class TradingConfig:
    """Trading parameters"""
    symbols: List[str] = field(default_factory=lambda: ['BTC/USDT'])
    timeframe: str = '15m'
    leverage: int = 1


@dataclass
class RiskConfig:
    """Risk management configuration"""
    initial_balance: float = 100000.0
    risk_per_trade: float = 0.01  # 1%
    max_daily_drawdown: float = 0.05  # 5%
    max_total_drawdown: float = 0.10  # 10%
    max_positions: int = 3
    max_exposure: float = 0.50  # 50%
    min_rr_ratio: float = 1.5
    trailing_drawdown: bool = False


@dataclass
class StrategyConfig:
    """Strategy parameters"""
    name: str = 'ma_crossover'
    fast_period: int = 10
    slow_period: int = 20
    atr_period: int = 14
    atr_multiplier: float = 2.0


@dataclass
class NotificationConfig:
    """Notification settings"""
    telegram_token: str = ''
    telegram_chat_id: str = ''
    email_enabled: bool = False


@dataclass
class Config:
    """Main configuration class"""
    exchange: ExchangeConfig = field(default_factory=ExchangeConfig)
    trading: TradingConfig = field(default_factory=TradingConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    strategy: StrategyConfig = field(default_factory=StrategyConfig)
    notifications: NotificationConfig = field(default_factory=NotificationConfig)

    @classmethod
    def from_env(cls) -> 'Config':
        """Load configuration from environment variables"""
        return cls(
            exchange=ExchangeConfig(
                exchange_id=os.getenv('EXCHANGE_ID', 'binance'),
                api_key=os.getenv('API_KEY', ''),
                api_secret=os.getenv('API_SECRET', ''),
                testnet=os.getenv('TESTNET', 'true').lower() == 'true',
                market_type=os.getenv('MARKET_TYPE', 'future'),
            ),
            trading=TradingConfig(
                symbols=os.getenv('SYMBOLS', 'BTC/USDT').split(','),
                timeframe=os.getenv('TIMEFRAME', '15m'),
                leverage=int(os.getenv('LEVERAGE', '1')),
            ),
            risk=RiskConfig(
                initial_balance=float(os.getenv('INITIAL_BALANCE', '100000')),
                risk_per_trade=float(os.getenv('RISK_PER_TRADE', '0.01')),
                max_daily_drawdown=float(os.getenv('MAX_DAILY_DD', '0.05')),
                max_total_drawdown=float(os.getenv('MAX_TOTAL_DD', '0.10')),
            ),
            strategy=StrategyConfig(
                name=os.getenv('STRATEGY_NAME', 'ma_crossover'),
                fast_period=int(os.getenv('FAST_PERIOD', '10')),
                slow_period=int(os.getenv('SLOW_PERIOD', '20')),
            ),
            notifications=NotificationConfig(
                telegram_token=os.getenv('TELEGRAM_TOKEN', ''),
                telegram_chat_id=os.getenv('TELEGRAM_CHAT_ID', ''),
            ),
        )

    def validate(self):
        """Validate configuration"""
        errors = []

        if not self.exchange.api_key:
            errors.append("API_KEY is required")
        if not self.exchange.api_secret:
            errors.append("API_SECRET is required")
        if self.risk.risk_per_trade > 0.05:
            errors.append("Risk per trade should not exceed 5%")
        if self.strategy.fast_period >= self.strategy.slow_period:
            errors.append("Fast period must be less than slow period")

        if errors:
            raise ValueError(f"Configuration errors: {errors}")

        return True
```

---

## Main Entry Point (src/main.py)

```python
"""
Trading Bot Entry Point
"""
import asyncio
import signal
import sys
from datetime import datetime

from config.settings import Config
from src.core.engine import TradingEngine
from src.utils.logger import setup_logger


async def main():
    """Main entry point"""
    # Setup logging
    logger = setup_logger('trading_bot')
    logger.info("=" * 50)
    logger.info("Trading Bot Starting")
    logger.info("=" * 50)

    # Load configuration
    try:
        config = Config.from_env()
        config.validate()
        logger.info("Configuration loaded successfully")
    except Exception as e:
        logger.error(f"Configuration error: {e}")
        sys.exit(1)

    # Create and start engine
    engine = TradingEngine(config)

    # Setup signal handlers
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, shutting down...")
        asyncio.create_task(engine.shutdown())

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Start the engine
    try:
        await engine.start()
    except Exception as e:
        logger.error(f"Engine error: {e}", exc_info=True)
        await engine.shutdown()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
```

---

## Trading Engine (src/core/engine.py)

```python
"""
Main Trading Engine - Orchestrates all components
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Optional
import logging

from config.settings import Config
from src.data.feed import MarketDataFeed
from src.strategy.base import BaseStrategy
from src.strategy.ma_crossover import MACrossoverStrategy
from src.risk.manager import RiskManager
from src.risk.prop_firm import PropFirmRulesEngine
from src.execution.order_manager import OrderManager
from src.execution.exchange import ExchangeConnector
from src.utils.notifications import NotificationService


class TradingEngine:
    """
    Main trading engine that coordinates all components

    Responsibilities:
    - Initialize all components
    - Run main trading loop
    - Handle state transitions
    - Coordinate shutdown
    """

    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger('trading_bot.engine')

        # State
        self.running = False
        self.paused = False
        self.start_time = None
        self.last_heartbeat = None

        # Components (initialized in start())
        self.exchange: Optional[ExchangeConnector] = None
        self.data_feed: Optional[MarketDataFeed] = None
        self.strategy: Optional[BaseStrategy] = None
        self.risk_manager: Optional[RiskManager] = None
        self.prop_firm_rules: Optional[PropFirmRulesEngine] = None
        self.order_manager: Optional[OrderManager] = None
        self.notifier: Optional[NotificationService] = None

        # Trading state
        self.positions: Dict = {}
        self.pending_orders: Dict = {}
        self.daily_trades = 0

    async def start(self):
        """Initialize components and start trading"""
        self.logger.info("Initializing trading engine...")
        self.start_time = datetime.now()

        try:
            # Initialize components
            await self._initialize_components()

            # Sync with exchange
            await self._sync_with_exchange()

            # Start trading loop
            self.running = True
            await self._notify("🚀 Trading bot started")
            await self._run_trading_loop()

        except Exception as e:
            self.logger.error(f"Engine start failed: {e}", exc_info=True)
            raise

    async def _initialize_components(self):
        """Initialize all trading components"""
        # Exchange connector
        self.exchange = ExchangeConnector(
            exchange_id=self.config.exchange.exchange_id,
            config={
                'api_key': self.config.exchange.api_key,
                'secret': self.config.exchange.api_secret,
                'testnet': self.config.exchange.testnet,
                'market_type': self.config.exchange.market_type,
            }
        )
        await self.exchange.connect()
        self.logger.info("Exchange connected")

        # Data feed
        self.data_feed = MarketDataFeed(
            exchange=self.exchange,
            symbols=self.config.trading.symbols,
            timeframe=self.config.trading.timeframe
        )
        await self.data_feed.initialize()
        self.logger.info("Data feed initialized")

        # Strategy
        self.strategy = self._create_strategy()
        self.logger.info(f"Strategy loaded: {self.config.strategy.name}")

        # Risk manager
        self.risk_manager = RiskManager(
            config={
                'initial_balance': self.config.risk.initial_balance,
                'risk_per_trade': self.config.risk.risk_per_trade,
                'max_daily_dd': self.config.risk.max_daily_drawdown,
                'max_total_dd': self.config.risk.max_total_drawdown,
                'max_positions': self.config.risk.max_positions,
                'max_exposure': self.config.risk.max_exposure,
                'min_rr_ratio': self.config.risk.min_rr_ratio,
            }
        )

        # Prop firm rules
        self.prop_firm_rules = PropFirmRulesEngine({
            'initial_balance': self.config.risk.initial_balance,
            'max_daily_dd': self.config.risk.max_daily_drawdown,
            'max_total_dd': self.config.risk.max_total_drawdown,
            'trailing_dd': self.config.risk.trailing_drawdown,
        })

        # Order manager
        self.order_manager = OrderManager(self.exchange)

        # Notifications
        if self.config.notifications.telegram_token:
            self.notifier = NotificationService(
                telegram_token=self.config.notifications.telegram_token,
                telegram_chat_id=self.config.notifications.telegram_chat_id
            )
        self.logger.info("All components initialized")

    def _create_strategy(self) -> BaseStrategy:
        """Create strategy based on configuration"""
        if self.config.strategy.name == 'ma_crossover':
            return MACrossoverStrategy(
                fast_period=self.config.strategy.fast_period,
                slow_period=self.config.strategy.slow_period,
                atr_period=self.config.strategy.atr_period,
                atr_multiplier=self.config.strategy.atr_multiplier
            )
        else:
            raise ValueError(f"Unknown strategy: {self.config.strategy.name}")

    async def _sync_with_exchange(self):
        """Sync local state with exchange"""
        # Get current balance
        balance = await self.exchange.fetch_balance()
        usdt_balance = balance.get('USDT', {}).get('free', 0)
        self.logger.info(f"Account balance: {usdt_balance:.2f} USDT")

        # Get open positions
        positions = await self.exchange.fetch_positions()
        for pos in positions:
            if pos['contracts'] > 0:
                self.positions[pos['symbol']] = pos
                self.logger.info(f"Open position: {pos['symbol']} {pos['side']} {pos['contracts']}")

        # Get open orders
        orders = await self.exchange.fetch_open_orders()
        for order in orders:
            self.pending_orders[order['id']] = order

        self.logger.info(f"Synced: {len(self.positions)} positions, {len(self.pending_orders)} orders")

    async def _run_trading_loop(self):
        """Main trading loop"""
        self.logger.info("Starting trading loop...")

        while self.running:
            try:
                loop_start = datetime.now()
                self.last_heartbeat = loop_start

                # Skip if paused
                if self.paused:
                    await asyncio.sleep(1)
                    continue

                # Check prop firm rules
                await self._check_prop_firm_status()

                # Process each symbol
                for symbol in self.config.trading.symbols:
                    await self._process_symbol(symbol)

                # Update metrics
                await self._update_metrics()

                # Check for daily reset
                await self._check_daily_reset()

                # Calculate sleep time to maintain loop frequency
                loop_time = (datetime.now() - loop_start).total_seconds()
                sleep_time = max(0, 1 - loop_time)  # Target 1 second per loop
                await asyncio.sleep(sleep_time)

            except Exception as e:
                self.logger.error(f"Trading loop error: {e}", exc_info=True)
                await asyncio.sleep(5)

    async def _process_symbol(self, symbol: str):
        """Process trading logic for a single symbol"""
        try:
            # Get latest data
            df = await self.data_feed.get_candles(symbol, limit=200)
            if df is None or len(df) < self.strategy.get_required_history():
                return

            # Get current position for this symbol
            current_position = None
            if symbol in self.positions:
                current_position = self.positions[symbol].get('side')

            # Generate signal
            signal = self.strategy.generate_signal(df, current_position)

            if signal.type == SignalType.NONE:
                return

            # Log signal
            self.logger.info(f"Signal: {signal.type.value} {symbol} strength={signal.strength:.2f}")

            # Validate with risk manager
            balance = await self._get_current_balance()
            approved, reason, size = self.risk_manager.validate_trade(
                signal, df['close'].iloc[-1], balance
            )

            if not approved:
                self.logger.info(f"Trade rejected: {reason}")
                return

            # Execute trade
            await self._execute_trade(symbol, signal, size)

        except Exception as e:
            self.logger.error(f"Error processing {symbol}: {e}", exc_info=True)

    async def _execute_trade(self, symbol: str, signal, size: float):
        """Execute a trade"""
        try:
            current_price = signal.price

            # Close existing position if needed
            if signal.type == SignalType.CLOSE:
                if symbol in self.positions:
                    await self.order_manager.close_position(symbol)
                    del self.positions[symbol]
                    await self._notify(f"🔄 Closed position: {symbol}")
                return

            # Determine side
            side = 'buy' if signal.type == SignalType.BUY else 'sell'

            # Create order with stop loss and take profit
            order = await self.order_manager.create_order_with_sl_tp(
                symbol=symbol,
                side=side,
                amount=size,
                entry_price=current_price,
                stop_loss=signal.stop_loss,
                take_profit=signal.take_profit,
                order_type='market'
            )

            if order:
                self.positions[symbol] = {
                    'side': side,
                    'size': size,
                    'entry_price': order.get('average', current_price),
                    'stop_loss': signal.stop_loss,
                    'take_profit': signal.take_profit,
                    'entry_time': datetime.now()
                }

                self.daily_trades += 1
                self.risk_manager.record_position_open(symbol, size, order.get('average', current_price))

                await self._notify(
                    f"📈 {'Long' if side == 'buy' else 'Short'} {symbol}\n"
                    f"Size: {size:.4f}\n"
                    f"Entry: {order.get('average', current_price):.2f}\n"
                    f"SL: {signal.stop_loss:.2f}\n"
                    f"TP: {signal.take_profit:.2f}"
                )

                self.logger.info(f"Trade executed: {side} {size} {symbol} @ {order.get('average')}")

        except Exception as e:
            self.logger.error(f"Trade execution error: {e}", exc_info=True)
            await self._notify(f"❌ Trade execution failed: {e}")

    async def _check_prop_firm_status(self):
        """Check prop firm rules compliance"""
        balance = await self._get_current_balance()
        self.prop_firm_rules.update_balance(balance, datetime.now())

        status = self.prop_firm_rules.get_status()

        # Check if we can still trade
        if not self.prop_firm_rules.can_trade():
            if self.running and not self.paused:
                self.logger.warning("Drawdown limit reached - pausing trading")
                self.paused = True
                await self._notify(
                    f"🚨 TRADING PAUSED\n"
                    f"Daily DD: {status['daily_drawdown']:.2%}\n"
                    f"Total DD: {status['total_drawdown']:.2%}"
                )

        # Check for warnings
        if status['daily_drawdown'] > self.config.risk.max_daily_drawdown * 0.7:
            await self._notify(
                f"⚠️ Daily drawdown warning: {status['daily_drawdown']:.2%}",
                cooldown_key='daily_dd_warning'
            )

    async def _update_metrics(self):
        """Update performance metrics"""
        balance = await self._get_current_balance()

        # Update risk manager
        self.risk_manager.dd_manager.update(balance, datetime.now())

        # Log status periodically
        if datetime.now().minute % 15 == 0 and datetime.now().second < 2:
            status = self.risk_manager.get_status()
            self.logger.info(
                f"Status: Balance={balance:.2f}, "
                f"Daily DD={status['daily_drawdown']:.2%}, "
                f"Total DD={status['total_drawdown']:.2%}, "
                f"Positions={len(self.positions)}"
            )

    async def _check_daily_reset(self):
        """Check if it's time for daily reset"""
        now = datetime.now()
        if now.hour == 0 and now.minute == 0 and now.second < 2:
            self.logger.info("Daily reset")
            self.risk_manager.daily_reset()
            self.prop_firm_rules.daily_reset()
            self.daily_trades = 0

            # Send daily summary
            await self._send_daily_summary()

    async def _send_daily_summary(self):
        """Send daily trading summary"""
        status = self.risk_manager.get_status()
        await self._notify(
            f"📊 Daily Summary\n"
            f"Trades: {self.daily_trades}\n"
            f"Balance: ${status['current_balance']:,.2f}\n"
            f"Daily DD: {status['daily_drawdown']:.2%}\n"
            f"Total DD: {status['total_drawdown']:.2%}"
        )

    async def _get_current_balance(self) -> float:
        """Get current account balance"""
        try:
            balance = await self.exchange.fetch_balance()
            return balance.get('USDT', {}).get('total', 0)
        except:
            return self.config.risk.initial_balance

    async def _notify(self, message: str, cooldown_key: str = None):
        """Send notification"""
        if self.notifier:
            await self.notifier.send_message(message, cooldown_key=cooldown_key)

    async def shutdown(self):
        """Graceful shutdown"""
        self.logger.info("Shutting down trading engine...")
        self.running = False

        try:
            # Cancel pending orders
            for order_id in list(self.pending_orders.keys()):
                try:
                    await self.exchange.cancel_order(order_id, None)
                except:
                    pass

            # Optionally close positions
            # for symbol in list(self.positions.keys()):
            #     await self.order_manager.close_position(symbol)

            # Close connections
            if self.exchange:
                await self.exchange.disconnect()

            await self._notify("🛑 Trading bot stopped")
            self.logger.info("Shutdown complete")

        except Exception as e:
            self.logger.error(f"Shutdown error: {e}")

    def get_status(self) -> Dict:
        """Get current engine status"""
        return {
            'running': self.running,
            'paused': self.paused,
            'uptime': str(datetime.now() - self.start_time) if self.start_time else None,
            'last_heartbeat': self.last_heartbeat,
            'positions': len(self.positions),
            'pending_orders': len(self.pending_orders),
            'daily_trades': self.daily_trades,
        }
```

---

## Strategy Implementation (src/strategy/ma_crossover.py)

```python
"""
Moving Average Crossover Strategy
"""
import pandas as pd
import pandas_ta as ta
from typing import Optional
from src.strategy.base import BaseStrategy, Signal, SignalType


class MACrossoverStrategy(BaseStrategy):
    """
    Moving Average Crossover Strategy

    Entry:
    - Long: Fast MA crosses above Slow MA
    - Short: Fast MA crosses below Slow MA

    Exit:
    - Opposite crossover
    - Stop loss (ATR-based)
    - Take profit (ATR-based)
    """

    def __init__(self, fast_period: int = 10, slow_period: int = 20,
                 atr_period: int = 14, atr_multiplier: float = 2.0):
        super().__init__()
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.atr_period = atr_period
        self.atr_multiplier = atr_multiplier

    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate all required indicators"""
        df = df.copy()

        # Moving averages
        df['fast_ma'] = ta.ema(df['close'], length=self.fast_period)
        df['slow_ma'] = ta.ema(df['close'], length=self.slow_period)

        # MA difference and crossover
        df['ma_diff'] = df['fast_ma'] - df['slow_ma']
        df['ma_diff_prev'] = df['ma_diff'].shift(1)
        df['bullish_cross'] = (df['ma_diff'] > 0) & (df['ma_diff_prev'] <= 0)
        df['bearish_cross'] = (df['ma_diff'] < 0) & (df['ma_diff_prev'] >= 0)

        # ATR for stops
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=self.atr_period)

        # Trend filter (200 MA)
        df['trend_ma'] = ta.sma(df['close'], length=200)
        df['uptrend'] = df['close'] > df['trend_ma']

        # RSI filter
        df['rsi'] = ta.rsi(df['close'], length=14)

        return df

    def generate_signal(self, df: pd.DataFrame,
                        current_position: Optional[str] = None) -> Signal:
        """Generate trading signal"""
        df = self.calculate_indicators(df)

        if len(df) < self.slow_period + 10:
            return Signal(type=SignalType.NONE, symbol='', strength=0, price=df['close'].iloc[-1])

        latest = df.iloc[-1]
        current_price = latest['close']
        atr = latest['atr']

        # Exit logic first
        if current_position == 'long' and latest['bearish_cross']:
            return Signal(
                type=SignalType.CLOSE,
                symbol='',
                strength=0.5,
                price=current_price
            )
        if current_position == 'short' and latest['bullish_cross']:
            return Signal(
                type=SignalType.CLOSE,
                symbol='',
                strength=0.5,
                price=current_price
            )

        # Entry logic
        # Long: Bullish crossover + uptrend + RSI not overbought
        if latest['bullish_cross'] and latest['uptrend'] and latest['rsi'] < 70:
            if current_position != 'long':
                stop_loss = current_price - (atr * self.atr_multiplier)
                take_profit = current_price + (atr * self.atr_multiplier * 2)

                return Signal(
                    type=SignalType.BUY,
                    symbol='',
                    strength=0.7,
                    price=current_price,
                    stop_loss=stop_loss,
                    take_profit=take_profit
                )

        # Short: Bearish crossover + downtrend + RSI not oversold
        if latest['bearish_cross'] and not latest['uptrend'] and latest['rsi'] > 30:
            if current_position != 'short':
                stop_loss = current_price + (atr * self.atr_multiplier)
                take_profit = current_price - (atr * self.atr_multiplier * 2)

                return Signal(
                    type=SignalType.SELL,
                    symbol='',
                    strength=0.7,
                    price=current_price,
                    stop_loss=stop_loss,
                    take_profit=take_profit
                )

        return Signal(type=SignalType.NONE, symbol='', strength=0, price=current_price)

    def get_required_history(self) -> int:
        """Minimum bars needed for indicators"""
        return 250  # For 200 MA + buffer
```

---

## Requirements (requirements.txt)

```
# Core
ccxt>=4.0.0
ccxt[async]
pandas>=2.0.0
numpy>=1.24.0
pandas-ta>=0.3.14b

# Async
aiohttp>=3.8.0
asyncio

# Configuration
python-dotenv>=1.0.0
pyyaml>=6.0

# Database (optional)
sqlalchemy>=2.0.0
psycopg2-binary>=2.9.0
redis>=4.5.0

# Monitoring (optional)
prometheus-client>=0.16.0

# Testing
pytest>=7.0.0
pytest-asyncio>=0.21.0
```

---

## Docker Files

### Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc libpq-dev && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

# Create non-root user
RUN useradd -m botuser && chown -R botuser:botuser /app
USER botuser

ENV PYTHONUNBUFFERED=1

CMD ["python", "-m", "src.main"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  trading-bot:
    build: .
    container_name: trading-bot
    restart: unless-stopped
    env_file:
      - .env
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

---

## Environment File (.env.example)

```bash
# Exchange
EXCHANGE_ID=binance
API_KEY=your_api_key
API_SECRET=your_api_secret
TESTNET=true
MARKET_TYPE=future

# Trading
SYMBOLS=BTC/USDT
TIMEFRAME=15m
LEVERAGE=1

# Risk
INITIAL_BALANCE=100000
RISK_PER_TRADE=0.01
MAX_DAILY_DD=0.05
MAX_TOTAL_DD=0.10

# Strategy
STRATEGY_NAME=ma_crossover
FAST_PERIOD=10
SLOW_PERIOD=20

# Notifications
TELEGRAM_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id
```

---

## Running the Bot

```bash
# 1. Clone and setup
git clone your-repo
cd trading-bot
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Edit .env with your settings

# 3. Test on testnet first!
# Make sure TESTNET=true in .env

# 4. Run
python -m src.main

# Or with Docker
docker-compose up -d
docker-compose logs -f trading-bot
```

---

## Summary

This template provides:

1. **Modular architecture** - Easy to modify and extend
2. **Configuration management** - Environment-based config
3. **Risk management** - Integrated prop firm rules
4. **Proper logging** - Comprehensive logging
5. **Notifications** - Telegram alerts
6. **Docker support** - Easy deployment

Customize the strategy, risk parameters, and add your own components as needed.

---

*This concludes the complete trading bot documentation suite.*
