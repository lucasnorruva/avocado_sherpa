# 11 - Execution Algorithms

> **TWAP, VWAP, Iceberg orders, and smart order routing for optimal execution**

---

## Overview

Execution algorithms help minimize market impact when entering or exiting positions. For larger orders, how you execute can be as important as what you trade.

---

## Why Execution Matters

### Market Impact

When you place a large order:
1. **Immediate impact** - Your order moves the price
2. **Information leakage** - Others see your intent
3. **Slippage** - You get worse prices than expected

```python
def estimate_market_impact(order_size, avg_volume, volatility, spread):
    """
    Estimate market impact of an order

    Based on square-root market impact model:
    Impact ≈ σ × √(Q/V) × spread_factor

    Where:
    σ = volatility
    Q = order size
    V = average volume
    """
    volume_ratio = order_size / avg_volume
    impact = volatility * np.sqrt(volume_ratio) * (spread / 2)
    return impact


# Example:
# Order: 10 BTC, Avg Volume: 1000 BTC, Volatility: 2%, Spread: 0.1%
# Impact ≈ 0.02 × √(10/1000) × 0.05 = 0.0001 = 0.01%
```

---

## Time-Weighted Average Price (TWAP)

TWAP splits an order into equal parts executed at regular intervals.

```python
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict
import math

class TWAPExecutor:
    """
    Time-Weighted Average Price execution

    Splits order into equal slices executed over time
    """

    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        self.active_executions = {}

    async def execute(self, symbol: str, side: str, total_amount: float,
                      duration_minutes: int, num_slices: int = None,
                      order_type: str = 'limit', limit_offset: float = 0.001):
        """
        Execute TWAP order

        Args:
            symbol: Trading pair
            side: 'buy' or 'sell'
            total_amount: Total amount to execute
            duration_minutes: Time to complete execution
            num_slices: Number of child orders (default: 1 per minute)
            order_type: 'market' or 'limit'
            limit_offset: Price offset for limit orders (0.1% default)
        """
        if num_slices is None:
            num_slices = duration_minutes

        slice_amount = total_amount / num_slices
        interval_seconds = (duration_minutes * 60) / num_slices

        execution_id = f"twap_{symbol}_{datetime.now().timestamp()}"
        self.active_executions[execution_id] = {
            'status': 'running',
            'symbol': symbol,
            'side': side,
            'total_amount': total_amount,
            'filled_amount': 0,
            'slices_completed': 0,
            'slices_total': num_slices,
            'avg_price': 0,
            'child_orders': []
        }

        filled_value = 0

        for i in range(num_slices):
            # Check if cancelled
            if self.active_executions[execution_id]['status'] == 'cancelled':
                break

            try:
                # Get current price for limit order
                ticker = await self.exchange.fetch_ticker(symbol)
                current_price = ticker['last']

                if order_type == 'limit':
                    if side == 'buy':
                        price = current_price * (1 + limit_offset)
                    else:
                        price = current_price * (1 - limit_offset)

                    order = await self.exchange.create_limit_order(
                        symbol, side, slice_amount, price
                    )
                else:
                    order = await self.exchange.create_market_order(
                        symbol, side, slice_amount
                    )

                # Track execution
                self.active_executions[execution_id]['child_orders'].append(order)
                self.active_executions[execution_id]['filled_amount'] += order.get('filled', slice_amount)
                self.active_executions[execution_id]['slices_completed'] += 1

                # Update average price
                if order.get('average'):
                    filled_value += order['filled'] * order['average']
                    total_filled = self.active_executions[execution_id]['filled_amount']
                    self.active_executions[execution_id]['avg_price'] = filled_value / total_filled

            except Exception as e:
                print(f"TWAP slice {i+1} failed: {e}")

            # Wait for next slice (except for last one)
            if i < num_slices - 1:
                await asyncio.sleep(interval_seconds)

        self.active_executions[execution_id]['status'] = 'completed'
        return self.active_executions[execution_id]

    def cancel(self, execution_id: str):
        """Cancel TWAP execution"""
        if execution_id in self.active_executions:
            self.active_executions[execution_id]['status'] = 'cancelled'

    def get_status(self, execution_id: str):
        """Get execution status"""
        return self.active_executions.get(execution_id)
```

---

## Volume-Weighted Average Price (VWAP)

VWAP executes more during high-volume periods to minimize impact.

```python
class VWAPExecutor:
    """
    Volume-Weighted Average Price execution

    Executes more during high-volume periods
    """

    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        self.active_executions = {}

    def calculate_volume_profile(self, historical_volume: pd.Series, num_buckets: int):
        """
        Calculate expected volume distribution

        Args:
            historical_volume: Historical volume data (hourly/15min)
            num_buckets: Number of execution buckets
        """
        # Resample to buckets
        bucket_size = len(historical_volume) // num_buckets
        volume_buckets = []

        for i in range(num_buckets):
            start = i * bucket_size
            end = start + bucket_size
            bucket_volume = historical_volume.iloc[start:end].sum()
            volume_buckets.append(bucket_volume)

        # Normalize to percentages
        total_volume = sum(volume_buckets)
        volume_profile = [v / total_volume for v in volume_buckets]

        return volume_profile

    async def execute(self, symbol: str, side: str, total_amount: float,
                      duration_minutes: int, historical_volume: pd.Series = None,
                      num_buckets: int = 10):
        """
        Execute VWAP order

        Args:
            symbol: Trading pair
            side: 'buy' or 'sell'
            total_amount: Total amount to execute
            duration_minutes: Time to complete
            historical_volume: Historical volume for profile
            num_buckets: Number of execution buckets
        """
        # Calculate volume profile
        if historical_volume is not None:
            volume_profile = self.calculate_volume_profile(historical_volume, num_buckets)
        else:
            # Default: assume uniform (falls back to TWAP)
            volume_profile = [1.0 / num_buckets] * num_buckets

        # Calculate slice amounts based on volume profile
        slice_amounts = [total_amount * pct for pct in volume_profile]
        interval_seconds = (duration_minutes * 60) / num_buckets

        execution_id = f"vwap_{symbol}_{datetime.now().timestamp()}"
        self.active_executions[execution_id] = {
            'status': 'running',
            'symbol': symbol,
            'side': side,
            'total_amount': total_amount,
            'filled_amount': 0,
            'avg_price': 0,
            'volume_profile': volume_profile,
            'child_orders': []
        }

        filled_value = 0

        for i, slice_amount in enumerate(slice_amounts):
            if self.active_executions[execution_id]['status'] == 'cancelled':
                break

            if slice_amount < self.exchange.get_min_order_size(symbol):
                continue

            try:
                # Use market orders for VWAP (want to hit volume windows)
                order = await self.exchange.create_market_order(
                    symbol, side, slice_amount
                )

                self.active_executions[execution_id]['child_orders'].append(order)
                self.active_executions[execution_id]['filled_amount'] += order.get('filled', slice_amount)

                if order.get('average'):
                    filled_value += order['filled'] * order['average']
                    total_filled = self.active_executions[execution_id]['filled_amount']
                    self.active_executions[execution_id]['avg_price'] = filled_value / total_filled

            except Exception as e:
                print(f"VWAP bucket {i+1} failed: {e}")

            if i < len(slice_amounts) - 1:
                await asyncio.sleep(interval_seconds)

        self.active_executions[execution_id]['status'] = 'completed'
        return self.active_executions[execution_id]


class AdaptiveVWAPExecutor(VWAPExecutor):
    """
    Adaptive VWAP that adjusts based on real-time volume
    """

    async def execute_adaptive(self, symbol: str, side: str, total_amount: float,
                               duration_minutes: int, participation_rate: float = 0.1):
        """
        Execute with participation rate targeting

        Aims to be X% of market volume (e.g., 10%)
        """
        execution_id = f"adaptive_vwap_{symbol}_{datetime.now().timestamp()}"
        self.active_executions[execution_id] = {
            'status': 'running',
            'symbol': symbol,
            'side': side,
            'total_amount': total_amount,
            'filled_amount': 0,
            'avg_price': 0,
            'participation_rate': participation_rate
        }

        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        check_interval = 30  # Check every 30 seconds
        last_volume = 0

        while datetime.now() < end_time:
            if self.active_executions[execution_id]['status'] == 'cancelled':
                break

            remaining = total_amount - self.active_executions[execution_id]['filled_amount']
            if remaining <= 0:
                break

            try:
                # Get recent volume
                ticker = await self.exchange.fetch_ticker(symbol)
                current_volume = ticker.get('quoteVolume', 0)
                volume_delta = current_volume - last_volume if last_volume > 0 else 0
                last_volume = current_volume

                # Calculate slice based on participation rate
                if volume_delta > 0:
                    target_slice = volume_delta * participation_rate
                    slice_amount = min(target_slice, remaining)

                    if slice_amount >= self.exchange.get_min_order_size(symbol):
                        order = await self.exchange.create_market_order(
                            symbol, side, slice_amount
                        )
                        self.active_executions[execution_id]['filled_amount'] += order.get('filled', 0)

            except Exception as e:
                print(f"Adaptive VWAP error: {e}")

            await asyncio.sleep(check_interval)

        self.active_executions[execution_id]['status'] = 'completed'
        return self.active_executions[execution_id]
```

---

## Iceberg Orders

Hide large order size by showing only a small portion.

```python
class IcebergExecutor:
    """
    Iceberg order execution

    Shows only a small portion of the order at a time
    """

    def __init__(self, exchange_connector):
        self.exchange = exchange_connector
        self.active_orders = {}

    async def execute(self, symbol: str, side: str, total_amount: float,
                      display_amount: float, price: float,
                      price_variance: float = 0.0001):
        """
        Execute iceberg order

        Args:
            symbol: Trading pair
            side: 'buy' or 'sell'
            total_amount: Total amount to execute
            display_amount: Amount to show (tip of iceberg)
            price: Limit price
            price_variance: Small price adjustment between slices
        """
        execution_id = f"iceberg_{symbol}_{datetime.now().timestamp()}"
        self.active_orders[execution_id] = {
            'status': 'running',
            'symbol': symbol,
            'side': side,
            'total_amount': total_amount,
            'filled_amount': 0,
            'display_amount': display_amount,
            'active_order': None
        }

        remaining = total_amount

        while remaining > 0:
            if self.active_orders[execution_id]['status'] == 'cancelled':
                break

            slice_amount = min(display_amount, remaining)

            # Slight price variance to avoid detection
            variance = np.random.uniform(-price_variance, price_variance)
            slice_price = price * (1 + variance)

            try:
                order = await self.exchange.create_limit_order(
                    symbol, side, slice_amount, slice_price
                )
                self.active_orders[execution_id]['active_order'] = order

                # Wait for fill
                while True:
                    await asyncio.sleep(1)
                    status = await self.exchange.fetch_order(order['id'], symbol)

                    if status['status'] == 'closed':
                        self.active_orders[execution_id]['filled_amount'] += status['filled']
                        remaining -= status['filled']
                        break
                    elif status['status'] == 'canceled':
                        break

                    # Check if order is stale (price moved away)
                    ticker = await self.exchange.fetch_ticker(symbol)
                    if side == 'buy' and ticker['last'] < price * 0.999:
                        # Price dropped, update order
                        await self.exchange.cancel_order(order['id'], symbol)
                        break
                    elif side == 'sell' and ticker['last'] > price * 1.001:
                        # Price rose, update order
                        await self.exchange.cancel_order(order['id'], symbol)
                        break

            except Exception as e:
                print(f"Iceberg slice error: {e}")
                await asyncio.sleep(5)

        self.active_orders[execution_id]['status'] = 'completed'
        return self.active_orders[execution_id]
```

---

## Smart Order Router (SOR)

Route orders to the best venue or split across venues.

```python
class SmartOrderRouter:
    """
    Smart Order Router for multi-venue execution

    In crypto, this could route between different exchanges
    or between spot and futures markets
    """

    def __init__(self, exchanges: Dict[str, object]):
        """
        Args:
            exchanges: Dict of exchange_id -> connector
        """
        self.exchanges = exchanges

    async def get_best_prices(self, symbol: str):
        """Get best prices from all venues"""
        prices = {}

        for exchange_id, exchange in self.exchanges.items():
            try:
                ticker = await exchange.fetch_ticker(symbol)
                orderbook = await exchange.fetch_orderbook(symbol, limit=5)

                prices[exchange_id] = {
                    'bid': orderbook['bids'][0][0] if orderbook['bids'] else None,
                    'ask': orderbook['asks'][0][0] if orderbook['asks'] else None,
                    'bid_volume': orderbook['bids'][0][1] if orderbook['bids'] else 0,
                    'ask_volume': orderbook['asks'][0][1] if orderbook['asks'] else 0,
                    'spread': (orderbook['asks'][0][0] - orderbook['bids'][0][0]) if orderbook['bids'] and orderbook['asks'] else float('inf')
                }
            except Exception as e:
                print(f"Error fetching from {exchange_id}: {e}")

        return prices

    async def find_best_venue(self, symbol: str, side: str, amount: float):
        """
        Find best venue for execution

        Considers price, available liquidity, and spread
        """
        prices = await self.get_best_prices(symbol)

        best_venue = None
        best_price = float('inf') if side == 'buy' else 0

        for exchange_id, price_info in prices.items():
            if side == 'buy':
                if price_info['ask'] and price_info['ask'] < best_price:
                    if price_info['ask_volume'] >= amount * 0.5:  # At least 50% liquidity
                        best_price = price_info['ask']
                        best_venue = exchange_id
            else:
                if price_info['bid'] and price_info['bid'] > best_price:
                    if price_info['bid_volume'] >= amount * 0.5:
                        best_price = price_info['bid']
                        best_venue = exchange_id

        return best_venue, best_price

    async def split_order(self, symbol: str, side: str, amount: float):
        """
        Split order across multiple venues

        Optimizes for best overall execution
        """
        prices = await self.get_best_prices(symbol)
        allocations = {}
        remaining = amount

        # Sort venues by price
        if side == 'buy':
            sorted_venues = sorted(
                prices.items(),
                key=lambda x: x[1]['ask'] if x[1]['ask'] else float('inf')
            )
            price_key = 'ask'
            volume_key = 'ask_volume'
        else:
            sorted_venues = sorted(
                prices.items(),
                key=lambda x: x[1]['bid'] if x[1]['bid'] else 0,
                reverse=True
            )
            price_key = 'bid'
            volume_key = 'bid_volume'

        # Allocate to venues
        for exchange_id, price_info in sorted_venues:
            if remaining <= 0:
                break

            if price_info[price_key] is None:
                continue

            available = price_info[volume_key]
            allocation = min(remaining, available * 0.8)  # Take 80% of available

            if allocation > 0:
                allocations[exchange_id] = {
                    'amount': allocation,
                    'price': price_info[price_key]
                }
                remaining -= allocation

        return allocations

    async def execute_smart(self, symbol: str, side: str, amount: float,
                            strategy: str = 'best_venue'):
        """
        Execute order using smart routing

        Strategies:
        - 'best_venue': Send to single best venue
        - 'split': Split across venues
        """
        if strategy == 'best_venue':
            venue, price = await self.find_best_venue(symbol, side, amount)
            if venue:
                return await self.exchanges[venue].create_market_order(
                    symbol, side, amount
                )
        elif strategy == 'split':
            allocations = await self.split_order(symbol, side, amount)
            results = []

            for exchange_id, alloc in allocations.items():
                try:
                    order = await self.exchanges[exchange_id].create_market_order(
                        symbol, side, alloc['amount']
                    )
                    results.append({
                        'exchange': exchange_id,
                        'order': order
                    })
                except Exception as e:
                    print(f"SOR execution failed on {exchange_id}: {e}")

            return results

        return None
```

---

## Execution Analysis

### Measuring Execution Quality

```python
class ExecutionAnalyzer:
    """Analyze execution quality"""

    def calculate_slippage(self, expected_price: float, actual_price: float,
                          side: str) -> float:
        """
        Calculate slippage

        Slippage = difference between expected and actual price
        Positive = worse execution
        """
        if side == 'buy':
            slippage = (actual_price - expected_price) / expected_price
        else:
            slippage = (expected_price - actual_price) / expected_price

        return slippage * 100  # Return as percentage

    def calculate_vwap_deviation(self, execution_price: float,
                                 market_vwap: float) -> float:
        """
        Compare execution to market VWAP

        Negative = beat VWAP (good)
        Positive = worse than VWAP (bad)
        """
        return (execution_price - market_vwap) / market_vwap * 100

    def calculate_implementation_shortfall(self, decision_price: float,
                                           execution_price: float,
                                           amount: float) -> float:
        """
        Implementation shortfall

        Measures total cost of execution including:
        - Market impact
        - Timing cost
        - Opportunity cost
        """
        shortfall = (execution_price - decision_price) * amount
        return shortfall

    def analyze_execution(self, orders: List[Dict], market_data: pd.DataFrame):
        """
        Comprehensive execution analysis
        """
        if not orders:
            return None

        # Calculate overall metrics
        total_amount = sum(o.get('filled', 0) for o in orders)
        total_value = sum(o.get('filled', 0) * o.get('average', 0) for o in orders)
        avg_price = total_value / total_amount if total_amount > 0 else 0

        # Market VWAP during execution
        execution_start = min(o['timestamp'] for o in orders)
        execution_end = max(o['timestamp'] for o in orders)

        mask = (market_data.index >= execution_start) & (market_data.index <= execution_end)
        market_slice = market_data[mask]

        if len(market_slice) > 0:
            market_vwap = (market_slice['close'] * market_slice['volume']).sum() / market_slice['volume'].sum()
        else:
            market_vwap = avg_price

        # Price at decision time
        decision_price = market_data['close'].iloc[0]

        return {
            'total_amount': total_amount,
            'total_value': total_value,
            'avg_price': avg_price,
            'market_vwap': market_vwap,
            'vwap_deviation': self.calculate_vwap_deviation(avg_price, market_vwap),
            'implementation_shortfall': self.calculate_implementation_shortfall(
                decision_price, avg_price, total_amount
            ),
            'num_orders': len(orders),
            'execution_time': (execution_end - execution_start).total_seconds()
        }
```

---

## Choosing the Right Algorithm

| Situation | Recommended Algorithm |
|-----------|----------------------|
| Small order (<0.1% of volume) | Market order |
| Medium order, not urgent | TWAP |
| Medium order, want to match market | VWAP |
| Large order, hide size | Iceberg |
| Multi-exchange | Smart order router |
| Very large, time flexible | Participation rate |

### Decision Framework

```python
def select_execution_algorithm(order_size: float, avg_volume: float,
                               urgency: str, market_impact_concern: bool):
    """
    Select appropriate execution algorithm

    Args:
        order_size: Size of order
        avg_volume: Average market volume
        urgency: 'low', 'medium', 'high'
        market_impact_concern: Whether to minimize market impact
    """
    size_ratio = order_size / avg_volume

    if size_ratio < 0.001:  # < 0.1% of volume
        return 'market_order'

    if urgency == 'high':
        if size_ratio < 0.01:
            return 'market_order'
        else:
            return 'aggressive_twap'  # Fast TWAP

    if market_impact_concern:
        if size_ratio < 0.05:
            return 'vwap'
        else:
            return 'iceberg'

    if urgency == 'low':
        return 'participation'  # Match market volume

    return 'twap'  # Default
```

---

## Summary

Execution algorithms help:
1. **Reduce market impact** - Hide your intentions
2. **Get better prices** - Avoid moving the market
3. **Manage timing** - Execute at optimal times
4. **Route efficiently** - Use best venues

For prop firm trading, good execution can be the difference between profit and loss on tight-margin strategies.

---

*Next: [12-advanced-backtesting.md](./12-advanced-backtesting.md) - Walk-forward optimization, regime analysis*
