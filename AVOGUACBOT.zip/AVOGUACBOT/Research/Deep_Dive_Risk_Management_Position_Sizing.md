# Deep Dive: Risk Management & Position Sizing
## Kelly Criterion, Stop-Loss Strategies, and Capital Preservation

---

## Table of Contents

1. [Position Sizing Fundamentals](#position-sizing-fundamentals)
2. [The Kelly Criterion](#the-kelly-criterion)
3. [Stop-Loss Strategies](#stop-loss-strategies)
4. [Volatility-Based Risk Management](#volatility-based-risk-management)
5. [Portfolio-Level Risk Controls](#portfolio-level-risk-controls)
6. [Bot-Specific Risk Parameters](#bot-specific-risk-parameters)

---

## Position Sizing Fundamentals

### Why Position Sizing Matters

"Even the best trading strategies can fail without effective risk management."

Position sizing is one of the most important—but often overlooked—elements of successful crypto trading. Mastering how much capital to allocate to each trade can mean the difference between sustained profitability and premature losses.

### Basic Position Size Formula

```
Position Size = (Account Balance × Risk %) ÷ (Entry Price - Stop Loss Price)
```

**Example:**
```
Account Balance: $10,000
Risk per Trade: 2% ($200)
Entry Price: $50,000 (BTC)
Stop Loss: $48,000

Position Size = $200 ÷ ($50,000 - $48,000)
Position Size = $200 ÷ $2,000
Position Size = 0.1 BTC
Position Value = $5,000 (50% of account)
```

### Risk Percentage Guidelines

| Trader Type | Risk per Trade | Rationale |
|-------------|---------------|-----------|
| Conservative | 0.5-1% | Capital preservation priority |
| Moderate | 1-2% | Balanced growth and safety |
| Aggressive | 2-3% | Higher growth, accepts drawdowns |
| Professional | 0.25-1% | Strict institutional limits |

**Key Principle:** Professional traders typically risk 1-3% of their account per trade. This ensures you can survive multiple losing trades while preserving capital.

### Position Sizing Calculator

```python
def calculate_position_size(
    account_balance: float,
    risk_percent: float,
    entry_price: float,
    stop_loss_price: float,
    leverage: float = 1.0
) -> dict:
    """
    Calculate optimal position size based on risk parameters

    Returns position size, value, and risk amount
    """
    risk_amount = account_balance * (risk_percent / 100)
    price_risk = abs(entry_price - stop_loss_price)
    risk_per_unit = price_risk / entry_price

    # Base position size
    position_size = risk_amount / price_risk

    # Adjust for leverage
    position_value = position_size * entry_price
    margin_required = position_value / leverage

    return {
        'position_size': position_size,
        'position_value': position_value,
        'margin_required': margin_required,
        'risk_amount': risk_amount,
        'risk_per_unit_percent': risk_per_unit * 100
    }
```

---

## The Kelly Criterion

### Background

The Kelly Criterion was developed by John Kelly Jr. at Bell Labs in 1956. It's a formula that determines the optimal bet size to maximize long-term growth rate, used by professional gamblers, hedge funds, and institutional traders worldwide.

### The Kelly Formula

**Standard Formula:**
```
K% = W - (1 - W) / R
```

**Where:**
- K% = Kelly percentage (optimal bet size)
- W = Win rate (as decimal)
- R = Win/Loss ratio (average win / average loss)

**Alternative Formula:**
```
Kelly % = (W × R − L) / R
```

**Where:**
- W = Win rate (as decimal)
- L = Loss rate (1 − W)
- R = Reward/Risk ratio

### Kelly Criterion Calculator

```python
def kelly_criterion(win_rate: float, win_loss_ratio: float) -> dict:
    """
    Calculate Kelly optimal bet size and variants

    Args:
        win_rate: Probability of winning (0-1)
        win_loss_ratio: Average win / Average loss

    Returns:
        Full Kelly, Half Kelly, Quarter Kelly percentages
    """
    # Full Kelly calculation
    loss_rate = 1 - win_rate
    kelly_full = win_rate - (loss_rate / win_loss_ratio)

    # Cap at 100% and floor at 0%
    kelly_full = max(0, min(1, kelly_full))

    return {
        'full_kelly': kelly_full * 100,
        'half_kelly': (kelly_full / 2) * 100,
        'quarter_kelly': (kelly_full / 4) * 100,
        'recommended': (kelly_full / 4) * 100  # Quarter Kelly recommended
    }
```

### Kelly Criterion Examples

| Scenario | Win Rate | Win/Loss Ratio | Full Kelly | Recommended |
|----------|----------|----------------|------------|-------------|
| Strong edge | 60% | 1.5:1 | 33% | 8% |
| Moderate edge | 55% | 1.5:1 | 25% | 6% |
| Slight edge | 52% | 1.2:1 | 12% | 3% |
| Scalping | 65% | 0.8:1 | 21% | 5% |

### Why Use Fractional Kelly?

**Full Kelly Problems:**
- Can drop account 50-70% during losing streaks
- Psychologically devastating drawdowns
- Assumes perfect knowledge of probabilities

**Professional Recommendations:**
- **Half Kelly (50%):** Reduced volatility, still good growth
- **Quarter Kelly (25%):** Conservative, recommended for most traders
- **Tenth Kelly (10%):** Ultra-conservative for money managers

**Money Manager Rule:** For professional investors, 0.10x-0.15x of Kelly-optimal investment size is recommended because a 30% drawdown that's tolerable personally could spell doom professionally.

### Kelly with Stop-Loss Integration

```python
def risk_constrained_kelly(
    win_rate: float,
    avg_win: float,
    avg_loss: float,
    max_risk_percent: float = 2.0
) -> float:
    """
    Kelly criterion constrained by maximum risk per trade

    Combines theoretical Kelly with practical risk limits
    """
    win_loss_ratio = avg_win / avg_loss
    kelly_percent = kelly_criterion(win_rate, win_loss_ratio)['quarter_kelly']

    # Cap at max risk
    return min(kelly_percent, max_risk_percent)
```

---

## Stop-Loss Strategies

### Types of Stop-Losses

#### 1. Fixed Percentage Stop
```python
stop_loss_price = entry_price * (1 - stop_percent)  # For long
```

**Pros:** Simple, consistent
**Cons:** Doesn't account for market structure

#### 2. ATR-Based Stop (Volatility-Adjusted)
```python
def atr_stop_loss(entry_price: float, atr: float, multiplier: float = 2.0) -> float:
    """
    Stop loss based on Average True Range

    Higher volatility = wider stop
    """
    stop_distance = atr * multiplier
    return entry_price - stop_distance  # For long position
```

**Pros:** Adapts to market conditions
**Cons:** More complex to calculate

#### 3. Structure-Based Stop
Place stops beyond recent swing points or key support/resistance levels.

```python
def structure_stop_loss(entry_price: float, recent_low: float, buffer_percent: float = 0.5) -> float:
    """
    Stop below recent swing low with buffer
    """
    return recent_low * (1 - buffer_percent / 100)
```

**Pros:** Respects market structure
**Cons:** May require wider stops

#### 4. Time-Based Stop
Exit if trade hasn't moved favorably within specified time.

```python
def check_time_stop(entry_time: datetime, max_duration_hours: int = 24) -> bool:
    """
    Exit if trade exceeds maximum duration without target
    """
    return (datetime.now() - entry_time).total_seconds() / 3600 > max_duration_hours
```

### Stop-Loss Best Practices

**DO:**
- Place stops beyond recent swing points
- Use volatility-based thresholds (ATR)
- Account for typical spread when setting stops
- Consider partial position exits at multiple levels

**DON'T:**
- Place stops at obvious round numbers (easily hunted)
- Use arbitrary percentages without market context
- Set stops too tight in volatile markets
- Move stops further away from entry (adding risk)

### Trailing Stop Implementation

```python
class TrailingStop:
    def __init__(self, initial_stop: float, trail_percent: float):
        self.stop_price = initial_stop
        self.trail_percent = trail_percent
        self.highest_price = 0

    def update(self, current_price: float) -> float:
        """
        Update trailing stop based on price movement
        """
        if current_price > self.highest_price:
            self.highest_price = current_price
            # Trail stop up
            new_stop = current_price * (1 - self.trail_percent / 100)
            self.stop_price = max(self.stop_price, new_stop)

        return self.stop_price

    def is_triggered(self, current_price: float) -> bool:
        return current_price <= self.stop_price
```

---

## Volatility-Based Risk Management

### Adjusting for Market Conditions

**Crypto Volatility Profiles:**
| Asset Type | Annualized Volatility | Risk Adjustment |
|------------|----------------------|-----------------|
| Bitcoin | 50-80% | Baseline |
| Large-cap alts | 80-120% | 0.7x position |
| Mid-cap alts | 100-150% | 0.5x position |
| Small-cap alts | 150-300% | 0.25x position |

### Volatility-Adjusted Position Sizing

```python
def volatility_adjusted_position(
    base_position_size: float,
    current_volatility: float,
    target_volatility: float = 0.02  # 2% daily target
) -> float:
    """
    Scale position size inversely to volatility

    Higher volatility = smaller position
    """
    vol_ratio = target_volatility / current_volatility
    adjusted_size = base_position_size * vol_ratio

    # Cap adjustment between 0.25x and 2x
    return base_position_size * max(0.25, min(2.0, vol_ratio))
```

### Risk Parity Approach

Allocate capital so each position contributes equally to portfolio risk:

```python
def risk_parity_allocation(assets: dict, total_capital: float) -> dict:
    """
    Allocate capital inversely proportional to volatility

    assets: {symbol: volatility}
    """
    inverse_vols = {k: 1/v for k, v in assets.items()}
    total_inverse = sum(inverse_vols.values())

    allocations = {}
    for symbol, inv_vol in inverse_vols.items():
        weight = inv_vol / total_inverse
        allocations[symbol] = total_capital * weight

    return allocations
```

---

## Portfolio-Level Risk Controls

### Maximum Exposure Limits

| Risk Parameter | Conservative | Moderate | Aggressive |
|----------------|--------------|----------|------------|
| Max single position | 10% | 20% | 30% |
| Max sector exposure | 25% | 40% | 50% |
| Max correlated assets | 30% | 50% | 70% |
| Max total exposure | 80% | 100% | 150% (leveraged) |

### Correlation-Based Risk Management

```python
def correlation_adjusted_exposure(
    new_position: dict,
    existing_positions: list,
    correlation_matrix: pd.DataFrame,
    max_correlated_exposure: float = 0.30
) -> bool:
    """
    Check if new position would exceed correlated exposure limits
    """
    total_correlated_exposure = 0

    for position in existing_positions:
        corr = correlation_matrix.loc[new_position['symbol'], position['symbol']]
        if corr > 0.7:  # Highly correlated
            total_correlated_exposure += position['exposure']

    return (total_correlated_exposure + new_position['exposure']) <= max_correlated_exposure
```

### Drawdown Controls

```python
class DrawdownController:
    def __init__(self, max_daily_dd: float = 0.03, max_total_dd: float = 0.10):
        self.max_daily_dd = max_daily_dd
        self.max_total_dd = max_total_dd
        self.peak_equity = 0
        self.daily_start_equity = 0

    def update(self, current_equity: float) -> dict:
        self.peak_equity = max(self.peak_equity, current_equity)
        total_dd = (self.peak_equity - current_equity) / self.peak_equity
        daily_dd = (self.daily_start_equity - current_equity) / self.daily_start_equity

        return {
            'total_drawdown': total_dd,
            'daily_drawdown': daily_dd,
            'should_stop_daily': daily_dd >= self.max_daily_dd,
            'should_stop_total': total_dd >= self.max_total_dd,
            'risk_level': self._calculate_risk_level(total_dd)
        }

    def _calculate_risk_level(self, dd: float) -> str:
        if dd < 0.05: return 'LOW'
        elif dd < 0.08: return 'MEDIUM'
        elif dd < 0.10: return 'HIGH'
        else: return 'CRITICAL'
```

### Circuit Breakers

```python
class TradingCircuitBreaker:
    """
    Automatic trading halt on adverse conditions
    """
    def __init__(self):
        self.rules = {
            'max_daily_loss': 0.05,           # 5% daily loss
            'max_consecutive_losses': 5,       # 5 losses in a row
            'max_volatility_spike': 3.0,       # 3x normal volatility
            'min_liquidity_ratio': 0.5,        # 50% of normal liquidity
        }
        self.consecutive_losses = 0
        self.daily_pnl = 0

    def check_conditions(self, trade_result: dict, market_data: dict) -> dict:
        # Update tracking
        if trade_result['pnl'] < 0:
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0

        self.daily_pnl += trade_result['pnl']

        # Check all conditions
        triggered = []

        if abs(self.daily_pnl) >= self.rules['max_daily_loss']:
            triggered.append('daily_loss_limit')

        if self.consecutive_losses >= self.rules['max_consecutive_losses']:
            triggered.append('consecutive_losses')

        if market_data.get('volatility_ratio', 1) >= self.rules['max_volatility_spike']:
            triggered.append('volatility_spike')

        return {
            'should_halt': len(triggered) > 0,
            'triggers': triggered,
            'action': 'HALT_TRADING' if triggered else 'CONTINUE'
        }
```

---

## Bot-Specific Risk Parameters

### Grid Bot Risk Settings

```python
grid_risk_params = {
    'max_grid_investment': 0.30,      # Max 30% of account in one grid
    'stop_loss_percent': 0.15,        # Close grid if asset drops 15%
    'take_profit_percent': 0.25,      # Close grid on 25% profit
    'max_open_grids': 3,              # Maximum concurrent grids
    'rebalance_threshold': 0.10,      # Rebalance if 10% off target
}
```

### DCA Bot Risk Settings

```python
dca_risk_params = {
    'max_safety_orders': 6,           # Maximum averaging orders
    'safety_order_step': 0.02,        # 2% between safety orders
    'safety_order_multiplier': 1.5,   # Size increase per order
    'max_position_size': 0.20,        # Max 20% in single DCA
    'stop_loss_percent': 0.25,        # Hard stop at 25% loss
}
```

### Arbitrage Bot Risk Settings

```python
arb_risk_params = {
    'min_profit_threshold': 0.003,    # Minimum 0.3% profit per arb
    'max_execution_time': 10,         # Max 10 seconds to complete
    'max_position_per_exchange': 0.10, # Max 10% on single exchange
    'slippage_buffer': 0.001,         # 0.1% slippage allowance
    'max_concurrent_arbs': 3,         # Maximum parallel arbitrages
}
```

### Scalping Bot Risk Settings

```python
scalping_risk_params = {
    'max_trade_size': 0.02,           # Max 2% per scalp
    'stop_loss_percent': 0.005,       # 0.5% stop loss
    'take_profit_percent': 0.003,     # 0.3% take profit
    'max_daily_trades': 50,           # Cap daily trade count
    'max_daily_loss': 0.03,           # 3% daily loss limit
    'cooldown_after_loss': 300,       # 5 min cooldown after loss
}
```

---

## Quick Reference Card

### Position Sizing Checklist

- [ ] Calculate position size based on stop-loss distance
- [ ] Risk no more than 1-2% per trade
- [ ] Adjust for asset volatility
- [ ] Check correlation with existing positions
- [ ] Verify total portfolio exposure limits
- [ ] Account for fees and slippage in calculations

### Risk Management Checklist

- [ ] Daily loss limit set and monitored
- [ ] Maximum drawdown threshold defined
- [ ] Circuit breakers implemented
- [ ] Stop-losses on all positions
- [ ] Correlation limits enforced
- [ ] Volatility adjustment active
- [ ] Emergency liquidation plan ready

### Kelly Criterion Quick Guide

| Win Rate | R = 1.0 | R = 1.5 | R = 2.0 |
|----------|---------|---------|---------|
| 50% | 0% | 17% | 25% |
| 55% | 10% | 25% | 33% |
| 60% | 20% | 33% | 40% |
| 65% | 30% | 42% | 48% |

*Always use Quarter Kelly (divide by 4) in practice*

---

## Resources

- [Kelly Criterion Calculator](https://www.backtestbase.com/education/how-much-risk-per-trade)
- [Position Size Calculator](https://infinityalgo.com/tools/calculators/position-size-calculator)
- [Risk-Constrained Kelly Criterion](https://blog.quantinsti.com/risk-constrained-kelly-criterion/)
- [Position Sizing Strategies for Crypto](https://flipster.io/blog/position-sizing-strategies-for-crypto-trading)
- [Framework for Cryptocurrency Trading (CAIA)](https://caia.org/blog/2025/07/14/framework-cryptocurrency-trading)

---

*Document compiled: February 2026*
*For research and educational purposes*
