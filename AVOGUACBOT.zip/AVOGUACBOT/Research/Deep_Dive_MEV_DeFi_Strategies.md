# Deep Dive: MEV & DeFi Bot Strategies
## Maximal Extractable Value, Flash Loans, and On-Chain Arbitrage

---

## Table of Contents

1. [Understanding MEV](#understanding-mev)
2. [MEV Strategy Types](#mev-strategy-types)
3. [Flash Loan Arbitrage](#flash-loan-arbitrage)
4. [Technical Implementation](#technical-implementation)
5. [Protection Mechanisms](#protection-mechanisms)
6. [Sentiment and On-Chain Trading](#sentiment-and-on-chain-trading)

---

## Understanding MEV

### What is Maximal Extractable Value?

Maximal Extractable Value (MEV), formerly called Miner Extractable Value, refers to the profit that can be extracted by reordering, including, or excluding transactions within a block.

**Key Insight:** With Ethereum now using validators instead of miners, and bots making it possible for anyone to engage with MEV strategies, the name evolved to incorporate these wider possibilities.

### MEV Market Size

| Metric | Value |
|--------|-------|
| Total MEV profits (2019-2022) | >$675 million (Ethereum only) |
| Total MEV including BSC, Solana | >$1 billion |
| Realized Extractable Value (post-PoS) | >416k ETH (~$500 million) |
| Largest single MEV extraction | $1.9 million (Solana, Jan 2024) |

### How MEV Works

```
┌────────────────────────────────────────────────────────────┐
│                     MEMPOOL                                 │
│  [Pending transactions waiting to be included in blocks]   │
├────────────────────────────────────────────────────────────┤
│                          │                                  │
│                          ▼                                  │
│  ┌──────────────────────────────────────────────┐          │
│  │         MEV BOT MONITORING                    │          │
│  │  • Scans for profitable opportunities         │          │
│  │  • Detects arbitrage, liquidations            │          │
│  │  • Identifies vulnerable transactions         │          │
│  └──────────────────────────────────────────────┘          │
│                          │                                  │
│            ┌─────────────┼─────────────┐                   │
│            ▼             ▼             ▼                   │
│     ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│     │Arbitrage │  │Sandwich  │  │Liquidation│              │
│     │  Bot     │  │  Attack  │  │   Bot    │              │
│     └──────────┘  └──────────┘  └──────────┘              │
│                          │                                  │
│                          ▼                                  │
│  ┌──────────────────────────────────────────────┐          │
│  │         BLOCK BUILDER / VALIDATOR             │          │
│  │  Orders transactions for maximum profit       │          │
│  └──────────────────────────────────────────────┘          │
└────────────────────────────────────────────────────────────┘
```

---

## MEV Strategy Types

### 1. DEX Arbitrage

The simplest and most well-known MEV opportunity.

**How it works:**
1. Price difference exists between DEXes (e.g., Uniswap vs SushiSwap)
2. Bot buys on cheaper exchange
3. Bot sells on more expensive exchange
4. Profit = price difference - gas fees

**Example:**
```
ETH price on Uniswap: $3,000
ETH price on SushiSwap: $3,015

Action:
1. Buy 10 ETH on Uniswap: -$30,000
2. Sell 10 ETH on SushiSwap: +$30,150
3. Gas cost: ~$50
4. Net profit: $100
```

**Implementation Pseudocode:**
```python
async def find_dex_arbitrage(token_pair: str, dexes: list) -> dict:
    prices = {}
    for dex in dexes:
        prices[dex] = await get_price(dex, token_pair)

    best_buy = min(prices, key=prices.get)
    best_sell = max(prices, key=prices.get)

    spread = (prices[best_sell] - prices[best_buy]) / prices[best_buy]

    if spread > MIN_PROFIT_THRESHOLD:
        return {
            'buy_on': best_buy,
            'sell_on': best_sell,
            'spread': spread,
            'estimated_profit': calculate_profit(spread, trade_size)
        }
    return None
```

### 2. Sandwich Attacks

**Most profitable but controversial MEV strategy.**

**How it works:**
1. Detect large pending swap in mempool
2. Execute buy order BEFORE the large swap (front-run)
3. Large swap executes, pushing price up
4. Execute sell order AFTER the large swap (back-run)
5. Profit from the price movement caused by the victim's trade

**Example:**
```
Victim's pending order: Buy 100 ETH on Uniswap

Sandwich attack:
1. Front-run: Buy 50 ETH at $3,000 = $150,000
2. Victim's order: Buys 100 ETH, pushes price to $3,050
3. Back-run: Sell 50 ETH at $3,040 = $152,000
4. Profit: $2,000 (minus gas ~$100)
```

**Notable Example:** In H1 2023, an Ethereum bot made ~$34 million in three months using sandwich attacks, causing transaction fees to exceed $25 in May.

### 3. Frontrunning

**Generalized frontrunning approach:**
1. Monitor mempool for profitable transactions
2. Copy the transaction's code
3. Replace addresses with frontrunner's address
4. Submit modified transaction with higher gas
5. Execute before original transaction

**Common targets:**
- Large DEX trades
- NFT mints
- Token launches
- Liquidations

### 4. Liquidation Bots

**Target:** DeFi lending protocols (Aave, Compound, MakerDAO)

**How it works:**
1. Monitor positions approaching liquidation threshold
2. When position becomes undercollateralized, trigger liquidation
3. Receive liquidation bonus (typically 5-15%)

**Example:**
```
User position:
- Collateral: 10 ETH ($30,000)
- Borrowed: 20,000 USDC
- Collateral ratio: 150%
- Liquidation threshold: 125%

If ETH drops to $2,600:
- Collateral value: $26,000
- Collateral ratio: 130% → approaching liquidation

Liquidation bot action:
- Repay portion of debt
- Receive collateral + bonus
- Profit: 5-15% of liquidated amount
```

### 5. Backrunning

**Lower risk than frontrunning:**
- Wait for large trade to execute
- Trade immediately after to capture resulting price movement
- Common after large whale purchases

---

## Flash Loan Arbitrage

### What are Flash Loans?

Flash loans allow borrowing large amounts without collateral, provided the loan is repaid within the same transaction block.

**Key Properties:**
- No collateral required
- Must repay in same transaction
- If repayment fails, entire transaction reverts
- Enables capital-efficient arbitrage

### Flash Loan Arbitrage Flow

```
┌──────────────────────────────────────────────────────────┐
│               SINGLE ATOMIC TRANSACTION                   │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  1. Borrow 1,000 ETH from Aave (flash loan)              │
│                        ↓                                  │
│  2. Swap ETH → USDC on Uniswap (cheaper)                 │
│                        ↓                                  │
│  3. Swap USDC → ETH on SushiSwap (more ETH)             │
│                        ↓                                  │
│  4. Repay 1,000 ETH + 0.09% fee to Aave                 │
│                        ↓                                  │
│  5. Keep profit (excess ETH)                             │
│                                                           │
│  If profit < fee → Transaction reverts, no loss          │
└──────────────────────────────────────────────────────────┘
```

### Flash Loan Providers

| Protocol | Chain | Fee | Max Loan |
|----------|-------|-----|----------|
| Aave | Multi-chain | 0.09% | Pool liquidity |
| dYdX | Ethereum | 0% | Pool liquidity |
| Uniswap V3 | Multi-chain | 0.3% swap fee | Pool liquidity |
| Balancer | Multi-chain | 0% | Pool liquidity |

### Implementation Example

```solidity
// Simplified flash loan arbitrage contract
contract FlashLoanArbitrage {
    function executeArbitrage(
        address loanToken,
        uint256 loanAmount,
        address dexA,
        address dexB
    ) external {
        // 1. Take flash loan
        IERC20(loanToken).flashLoan(
            this,
            loanToken,
            loanAmount,
            abi.encode(dexA, dexB)
        );
    }

    function executeOperation(
        address token,
        uint256 amount,
        uint256 fee,
        bytes calldata params
    ) external returns (bool) {
        (address dexA, address dexB) = abi.decode(params, (address, address));

        // 2. Execute arbitrage
        uint256 amountOut = swapOnDex(dexA, token, amount);
        uint256 finalAmount = swapOnDex(dexB, intermediateToken, amountOut);

        // 3. Repay loan + fee
        require(finalAmount >= amount + fee, "Unprofitable");
        IERC20(token).transfer(msg.sender, amount + fee);

        // 4. Keep profit
        uint256 profit = finalAmount - amount - fee;

        return true;
    }
}
```

---

## Technical Implementation

### MEV Bot Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    MEV BOT SYSTEM                        │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌────────────────┐    ┌────────────────┐               │
│  │ Mempool        │    │ Block          │               │
│  │ Monitor        │───►│ Builder        │               │
│  │ (WebSocket)    │    │ Integration    │               │
│  └────────────────┘    └────────────────┘               │
│          │                     │                        │
│          ▼                     ▼                        │
│  ┌────────────────┐    ┌────────────────┐               │
│  │ Opportunity    │    │ Transaction    │               │
│  │ Detector       │───►│ Builder        │               │
│  └────────────────┘    └────────────────┘               │
│          │                     │                        │
│          ▼                     ▼                        │
│  ┌────────────────┐    ┌────────────────┐               │
│  │ Profit         │    │ Flashbots      │               │
│  │ Calculator     │───►│ Bundle         │               │
│  └────────────────┘    └────────────────┘               │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

### Essential Components

**1. Mempool Monitoring:**
```python
from web3 import Web3

async def monitor_mempool(w3: Web3):
    pending_filter = w3.eth.filter('pending')

    while True:
        pending_txs = pending_filter.get_new_entries()
        for tx_hash in pending_txs:
            tx = w3.eth.get_transaction(tx_hash)
            opportunity = analyze_transaction(tx)

            if opportunity and opportunity['profit'] > MIN_PROFIT:
                await execute_mev_strategy(opportunity)
```

**2. Gas Price Optimization:**
```python
def calculate_optimal_gas(base_fee: int, priority_fee: int, profit: int) -> int:
    """
    Calculate maximum gas price that maintains profitability
    """
    max_gas_cost = profit * 0.9  # Keep 10% minimum profit
    estimated_gas = 200000  # Typical arbitrage gas

    max_gas_price = max_gas_cost / estimated_gas

    return min(max_gas_price, base_fee + priority_fee * 2)
```

**3. Bundle Submission (Flashbots):**
```python
from flashbots import Flashbots

async def submit_bundle(signed_txs: list, target_block: int):
    flashbots = Flashbots(w3, signer)

    bundle = {
        "signedTransactions": signed_txs,
        "blockNumber": target_block
    }

    response = await flashbots.send_bundle(bundle)
    return response
```

### Competition Dynamics

**Economics of MEV Competition:**
- Searchers willing to pay up to 100% of MEV to validators
- Highly competitive opportunities: 90%+ goes to gas fees
- Only the fastest bot wins
- Priority Gas Auctions (PGA) drive up costs

**Implication:** Ethereum mainnet is extremely competitive. Elite bots often capture 99%+ of opportunities, leaving little for newcomers.

---

## Protection Mechanisms

### Flashbots Protect

**Purpose:** Allow users to send transactions directly to validators, bypassing the public mempool.

**How it works:**
1. User submits transaction to Flashbots RPC
2. Transaction goes directly to block builders
3. MEV bots cannot see transaction in mempool
4. Protection from sandwich attacks

**Integration:**
```javascript
// Using Flashbots Protect RPC
const provider = new ethers.providers.JsonRpcProvider(
    "https://rpc.flashbots.net"
);
```

### Other Protection Methods

| Method | Protection Level | Trade-off |
|--------|-----------------|-----------|
| Flashbots Protect | High | Slower inclusion |
| Private mempools | High | Trust in operator |
| MEV Share | Medium | Share extracted value |
| Cowswap (batch auctions) | High | Slower execution |
| Intent-based systems | High | Complexity |

### User Protection Tips

1. **Use private RPCs:** Flashbots, MEV Blocker
2. **Limit slippage:** Set tight slippage tolerance
3. **Avoid large trades:** Break into smaller pieces
4. **Use DEX aggregators:** Often have built-in protection
5. **Check transaction simulation:** Preview actual output

---

## Sentiment and On-Chain Trading

### Combining Data Sources

**Multi-Source Analysis:**
```
┌─────────────────────────────────────────────────────────┐
│              SENTIMENT + ON-CHAIN FUSION                 │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌───────────┐   ┌───────────┐   ┌───────────┐         │
│  │ Social    │   │ On-Chain  │   │ Market    │         │
│  │ Sentiment │   │ Metrics   │   │ Data      │         │
│  └─────┬─────┘   └─────┬─────┘   └─────┬─────┘         │
│        │               │               │                │
│        ▼               ▼               ▼                │
│  ┌─────────────────────────────────────────────┐       │
│  │           FUSION MODEL                       │       │
│  │  • NLP sentiment scores                      │       │
│  │  • Whale wallet tracking                     │       │
│  │  • Exchange flow analysis                    │       │
│  │  • Network activity metrics                  │       │
│  └─────────────────────────────────────────────┘       │
│                        │                                │
│                        ▼                                │
│  ┌─────────────────────────────────────────────┐       │
│  │           TRADING SIGNALS                    │       │
│  └─────────────────────────────────────────────┘       │
└─────────────────────────────────────────────────────────┘
```

### Social Media Analysis

**Platform Characteristics:**

| Platform | Best For | Response Time |
|----------|----------|---------------|
| Twitter/X | Real-time news, whale alerts | Seconds-minutes |
| TikTok | Retail sentiment, meme coins | Hours-days |
| Reddit | Community sentiment | Hours |
| Discord/Telegram | Alpha, insider info | Variable |

**Research Finding:** Twitter sentiment exerts more frequent and reactive impact on trading volume due to real-time news function.

### NLP Models for Crypto Sentiment

**Best Performing Models:**
| Model | F1 Score | Use Case |
|-------|----------|----------|
| RoBERTa | 0.85 | General sentiment |
| FinBERT | 0.82 | Financial text |
| CryptoBERT | 0.80 | Crypto-specific |
| GPT-4 | 0.83 | Complex context |

### Whale Monitoring

**Key Whale Indicators:**
```python
whale_signals = {
    'large_exchange_deposit': 'Potential sell pressure',
    'large_exchange_withdrawal': 'Accumulation signal',
    'dormant_wallet_activation': 'Early whale movement',
    'whale_to_whale_transfer': 'OTC or repositioning',
    'smart_money_accumulation': 'Follow the smart money'
}
```

**Tools:**
- Whale Alert
- Nansen
- Santiment
- Glassnode

### On-Chain Metrics for Trading

**Key Metrics:**

| Metric | Bullish Signal | Bearish Signal |
|--------|---------------|----------------|
| Exchange reserves | Decreasing | Increasing |
| Active addresses | Increasing | Decreasing |
| MVRV ratio | < 1 (undervalued) | > 3 (overvalued) |
| SOPR | > 1 (profit taking) | < 1 (capitulation) |
| NVT ratio | Low | High |

### Implementation Example

```python
class SentimentOnChainTrader:
    def __init__(self):
        self.sentiment_analyzer = load_model('roberta-crypto')
        self.on_chain_client = SantimentClient(API_KEY)

    async def generate_signal(self, asset: str) -> dict:
        # Get sentiment data
        tweets = await fetch_recent_tweets(asset, limit=100)
        sentiment = self.sentiment_analyzer.predict(tweets)

        # Get on-chain data
        on_chain = await self.on_chain_client.get_metrics(asset)

        # Combine signals
        combined_score = (
            0.3 * sentiment['score'] +
            0.3 * self.normalize_exchange_flow(on_chain['exchange_flow']) +
            0.2 * self.normalize_active_addresses(on_chain['active_addresses']) +
            0.2 * self.normalize_whale_activity(on_chain['whale_txs'])
        )

        return {
            'asset': asset,
            'signal': 'BUY' if combined_score > 0.6 else 'SELL' if combined_score < 0.4 else 'HOLD',
            'confidence': abs(combined_score - 0.5) * 2,
            'components': {
                'sentiment': sentiment,
                'on_chain': on_chain
            }
        }
```

---

## Resources

### MEV Resources
- [Ethereum.org MEV Documentation](https://ethereum.org/developers/docs/mev/)
- [Flashbots Documentation](https://docs.flashbots.net/)
- [MEV Bot Guide (Blocknative)](https://www.blocknative.com/blog/mev-and-creating-a-basic-arbitrage-bot-on-ethereum-mainnet)
- [2025 Guide to MEV (Arkham)](https://info.arkm.com/research/beginners-guide-to-mev)

### Sentiment Analysis Resources
- [Santiment Platform](https://app.santiment.net/)
- [LunarCrush](https://lunarcrush.com/)
- [Nansen Analytics](https://www.nansen.ai/)
- [CoinGecko Sentiment Trading Strategy](https://www.coingecko.com/learn/crypto-sentiment-analysis-trading-strategy)

### Academic Papers
- [LLMs and NLP Models in Cryptocurrency Sentiment Analysis](https://www.mdpi.com/2504-2289/8/6/63)
- [From Whales to Waves: Social Media Sentiment in Crypto Markets](https://www.sciencedirect.com/science/article/pii/S0890838925001325)
- [Enhancing Cryptocurrency Sentiment Analysis with Multimodal Features](https://arxiv.org/html/2508.15825v1)

---

*Document compiled: February 2026*
*For research and educational purposes*
