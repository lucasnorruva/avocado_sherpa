# Deep Dive: Statistical Arbitrage & Pairs Trading
## Cointegration, Mean Reversion, and Quantitative Strategies

---

## Table of Contents

1. [Statistical Arbitrage Overview](#statistical-arbitrage-overview)
2. [Pairs Trading Fundamentals](#pairs-trading-fundamentals)
3. [Cointegration Analysis](#cointegration-analysis)
4. [Z-Score Trading System](#z-score-trading-system)
5. [Implementation Guide](#implementation-guide)
6. [Performance and Research Findings](#performance-and-research-findings)

---

## Statistical Arbitrage Overview

### Definition

Statistical arbitrage (stat arb) is a quantitative trading strategy that seeks to exploit inefficiencies or temporary mispricings between related financial instruments. Unlike pure arbitrage, stat arb carries risk because it relies on statistical relationships that may temporarily break down.

### Key Concepts

**Statistical Arbitrage vs. Pure Arbitrage:**

| Aspect | Pure Arbitrage | Statistical Arbitrage |
|--------|---------------|----------------------|
| Risk | Risk-free | Contains risk |
| Mechanism | Price discrepancy | Statistical relationship |
| Duration | Instant | Hours to days |
| Capital | High | Moderate |
| Competition | Extreme | High |

### Types of Statistical Arbitrage

1. **Pairs Trading:** Trading two correlated/cointegrated assets
2. **Index Arbitrage:** Trading index vs. components
3. **ETF Arbitrage:** Trading ETF vs. underlying
4. **Cross-Asset Arbitrage:** Exploiting relationships across asset classes
5. **Factor-Based Arbitrage:** Long/short based on factor exposures

---

## Pairs Trading Fundamentals

### The Core Idea

Pairs trading involves:
1. Finding two assets that move together historically
2. When they diverge, short the outperformer and long the underperformer
3. Profit when they converge back to their normal relationship

### Crypto Pairs Examples

**Common Cointegrated Pairs:**
- BTC / ETH (largest cryptos, correlated fundamentals)
- LTC / BCH (Bitcoin forks)
- LINK / UNI (DeFi blue chips)
- Stablecoin pairs (USDT / USDC / DAI)

### Mathematical Framework

**Spread Calculation:**
```
Spread = Price_A - β × Price_B
```

Where β is the hedge ratio calculated from regression:
```
Price_A = α + β × Price_B + ε
```

**Trading Rules:**
- Long spread when spread < -threshold
- Short spread when spread > +threshold
- Close when spread returns to mean

---

## Cointegration Analysis

### What is Cointegration?

Cointegration describes a long-run equilibrium relationship between two non-stationary time series. When two assets are cointegrated, their prices may wander, but the spread between them is stationary (mean-reverting).

**Key Insight:** Correlation ≠ Cointegration
- Highly correlated series may NOT be cointegrated
- Cointegrated series may have LOW correlation
- Cointegration is about the RELATIONSHIP, not direction

### Testing for Cointegration

#### Engle-Granger Two-Step Method

```python
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller

def engle_granger_cointegration(series_a: pd.Series, series_b: pd.Series) -> dict:
    """
    Test for cointegration using Engle-Granger two-step method

    Returns hedge ratio, residuals, and test statistics
    """
    # Step 1: Regress series_a on series_b
    X = sm.add_constant(series_b)
    model = sm.OLS(series_a, X).fit()

    # Extract hedge ratio (beta)
    hedge_ratio = model.params[1]
    intercept = model.params[0]

    # Calculate spread (residuals)
    spread = series_a - hedge_ratio * series_b - intercept

    # Step 2: Test residuals for stationarity
    adf_result = adfuller(spread)

    return {
        'hedge_ratio': hedge_ratio,
        'intercept': intercept,
        'spread': spread,
        'adf_statistic': adf_result[0],
        'p_value': adf_result[1],
        'is_cointegrated': adf_result[1] < 0.05,  # 5% significance
        'critical_values': adf_result[4]
    }
```

#### Johansen Test

For multiple time series (more robust):

```python
from statsmodels.tsa.vector_ar.vecm import coint_johansen

def johansen_cointegration(data: pd.DataFrame, det_order: int = 0, k_ar_diff: int = 1) -> dict:
    """
    Johansen test for cointegration of multiple series
    """
    result = coint_johansen(data, det_order, k_ar_diff)

    return {
        'eigenvalues': result.eig,
        'trace_stats': result.lr1,
        'trace_crit_values': result.cvt,
        'max_eig_stats': result.lr2,
        'max_eig_crit_values': result.cvm,
        'num_cointegrating_relations': sum(result.lr1 > result.cvt[:, 1])
    }
```

### Augmented Dickey-Fuller (ADF) Test

**Purpose:** Determine if a time series is stationary.

**Null Hypothesis:** There is a unit root (series is non-stationary)

**Interpretation:**
- p-value < 0.05: Reject null → Series is stationary
- p-value > 0.05: Cannot reject → Series may be non-stationary

**Critical Values (5% significance):**
- Test statistic < -2.86 → Stationary

---

## Z-Score Trading System

### Z-Score Calculation

The Z-score measures how far the current spread is from its historical mean in standard deviation units.

```python
def calculate_zscore(spread: pd.Series, lookback: int = 20) -> pd.Series:
    """
    Calculate rolling Z-score of spread
    """
    mean = spread.rolling(window=lookback).mean()
    std = spread.rolling(window=lookback).std()

    zscore = (spread - mean) / std

    return zscore
```

### Trading Rules

**Standard Z-Score Trading:**

| Z-Score | Signal | Rationale |
|---------|--------|-----------|
| > +2.0 | Short spread | Spread too high, expect reversion |
| > +1.5 | Reduce long / start short | Early warning |
| -1.5 to +1.5 | Hold / close | Near equilibrium |
| < -1.5 | Reduce short / start long | Early warning |
| < -2.0 | Long spread | Spread too low, expect reversion |

### Complete Pairs Trading System

```python
class PairsTradingStrategy:
    def __init__(
        self,
        entry_zscore: float = 2.0,
        exit_zscore: float = 0.5,
        stop_zscore: float = 4.0,
        lookback: int = 20
    ):
        self.entry_zscore = entry_zscore
        self.exit_zscore = exit_zscore
        self.stop_zscore = stop_zscore
        self.lookback = lookback
        self.position = 0  # 1 = long spread, -1 = short spread

    def calculate_hedge_ratio(self, price_a: pd.Series, price_b: pd.Series) -> float:
        """Calculate dynamic hedge ratio using rolling regression"""
        X = sm.add_constant(price_b[-self.lookback:])
        model = sm.OLS(price_a[-self.lookback:], X).fit()
        return model.params[1]

    def calculate_spread(self, price_a: float, price_b: float, hedge_ratio: float) -> float:
        """Calculate current spread"""
        return price_a - hedge_ratio * price_b

    def generate_signal(self, zscore: float) -> dict:
        """Generate trading signal based on Z-score"""
        signal = {
            'action': 'HOLD',
            'position_change': 0,
            'reason': ''
        }

        # Entry signals
        if self.position == 0:
            if zscore > self.entry_zscore:
                signal = {
                    'action': 'SHORT_SPREAD',
                    'position_change': -1,
                    'reason': f'Z-score {zscore:.2f} > entry threshold'
                }
            elif zscore < -self.entry_zscore:
                signal = {
                    'action': 'LONG_SPREAD',
                    'position_change': 1,
                    'reason': f'Z-score {zscore:.2f} < -entry threshold'
                }

        # Exit signals
        elif self.position == 1:  # Long spread
            if zscore > -self.exit_zscore:
                signal = {
                    'action': 'CLOSE_LONG',
                    'position_change': -1,
                    'reason': 'Z-score returned to mean'
                }
            elif zscore < -self.stop_zscore:
                signal = {
                    'action': 'STOP_LOSS',
                    'position_change': -1,
                    'reason': 'Stop loss triggered'
                }

        elif self.position == -1:  # Short spread
            if zscore < self.exit_zscore:
                signal = {
                    'action': 'CLOSE_SHORT',
                    'position_change': 1,
                    'reason': 'Z-score returned to mean'
                }
            elif zscore > self.stop_zscore:
                signal = {
                    'action': 'STOP_LOSS',
                    'position_change': 1,
                    'reason': 'Stop loss triggered'
                }

        return signal

    def execute_trade(self, signal: dict, price_a: float, price_b: float, hedge_ratio: float, capital: float):
        """Execute pairs trade"""
        if signal['action'] == 'HOLD':
            return None

        # Calculate position sizes
        # For $1 of spread exposure:
        # Long spread = Long A, Short B
        # Short spread = Short A, Long B

        position_value = capital * 0.5  # Use 50% of capital

        if signal['action'] in ['SHORT_SPREAD', 'LONG_SPREAD']:
            size_a = position_value / price_a
            size_b = (position_value * hedge_ratio) / price_b

            trades = []
            if signal['action'] == 'SHORT_SPREAD':
                trades.append({'asset': 'A', 'side': 'SELL', 'size': size_a})
                trades.append({'asset': 'B', 'side': 'BUY', 'size': size_b})
            else:
                trades.append({'asset': 'A', 'side': 'BUY', 'size': size_a})
                trades.append({'asset': 'B', 'side': 'SELL', 'size': size_b})

            self.position += signal['position_change']
            return trades

        # Close positions
        self.position = 0
        return [{'action': 'CLOSE_ALL'}]
```

---

## Implementation Guide

### Step-by-Step Process

#### 1. Pair Selection

```python
def find_cointegrated_pairs(price_data: pd.DataFrame, significance: float = 0.05) -> list:
    """
    Scan all pairs for cointegration

    price_data: DataFrame with assets as columns
    Returns list of cointegrated pairs
    """
    assets = price_data.columns
    n = len(assets)
    cointegrated_pairs = []

    for i in range(n):
        for j in range(i+1, n):
            result = engle_granger_cointegration(
                price_data[assets[i]],
                price_data[assets[j]]
            )

            if result['p_value'] < significance:
                cointegrated_pairs.append({
                    'asset_a': assets[i],
                    'asset_b': assets[j],
                    'hedge_ratio': result['hedge_ratio'],
                    'p_value': result['p_value'],
                    'half_life': calculate_half_life(result['spread'])
                })

    return sorted(cointegrated_pairs, key=lambda x: x['p_value'])
```

#### 2. Half-Life Calculation

The half-life indicates how quickly the spread reverts to the mean.

```python
def calculate_half_life(spread: pd.Series) -> float:
    """
    Calculate mean reversion half-life using Ornstein-Uhlenbeck process
    """
    spread_lag = spread.shift(1).dropna()
    spread_diff = spread.diff().dropna()

    # Align series
    spread_lag = spread_lag[1:]

    # Regress spread change on lagged spread
    X = sm.add_constant(spread_lag)
    model = sm.OLS(spread_diff, X).fit()

    # Half-life formula
    lambda_param = -model.params[1]

    if lambda_param <= 0:
        return float('inf')  # Not mean-reverting

    half_life = np.log(2) / lambda_param

    return half_life
```

**Interpretation:**
- Half-life < 5 days: Fast mean reversion, good for trading
- Half-life 5-20 days: Moderate, suitable for swing trading
- Half-life > 20 days: Slow reversion, may not be practical

#### 3. Risk Management

```python
class PairsRiskManager:
    def __init__(
        self,
        max_position_size: float = 0.20,
        max_pairs: int = 5,
        max_correlation: float = 0.7,
        stop_loss_zscore: float = 4.0
    ):
        self.max_position_size = max_position_size
        self.max_pairs = max_pairs
        self.max_correlation = max_correlation
        self.stop_loss_zscore = stop_loss_zscore
        self.active_pairs = []

    def can_add_pair(self, new_pair: dict) -> bool:
        """Check if new pair can be added to portfolio"""
        if len(self.active_pairs) >= self.max_pairs:
            return False

        # Check correlation with existing pairs
        for existing in self.active_pairs:
            correlation = self.calculate_pair_correlation(new_pair, existing)
            if abs(correlation) > self.max_correlation:
                return False

        return True

    def calculate_position_size(self, pair: dict, account_value: float) -> float:
        """Calculate position size for pair trade"""
        base_size = account_value * self.max_position_size

        # Adjust for volatility
        spread_vol = pair['spread'].std()
        vol_adjustment = 0.02 / spread_vol  # Target 2% daily vol

        return base_size * min(vol_adjustment, 1.0)
```

---

## Performance and Research Findings

### Academic Research Results

#### Pairs Trading in Cryptocurrency Markets (EUR Thesis)
**Key Findings:**
- Pairs trading consistently outperforms conventional approaches
- Generates significant risk-adjusted excess returns
- Maintains low market exposure (market neutral)

#### Statistical Arbitrage with High Correlation (Springer)
**Dataset:** 81,000+ data points
**Backtesting Results:**
- Win rate: **100%** in backtesting
- Live trading win rate: **79-100%**
- Excess returns: **-0.4% to +8.1%** vs benchmark

#### Trading Games Study (Wiley, 2025)
**Finding:** Pairs trading strategies consistently beat passive strategies in bullish crypto markets when using:
- Dynamic risk management
- Adaptive trailing stop-loss
- Volatility filtering mechanisms

### Realistic Performance Expectations

| Metric | Conservative | Moderate | Aggressive |
|--------|--------------|----------|------------|
| Annual return | 10-20% | 20-40% | 40-80% |
| Sharpe ratio | 0.8-1.2 | 1.2-2.0 | 1.5-2.5 |
| Max drawdown | 5-10% | 10-20% | 20-35% |
| Win rate | 55-65% | 60-70% | 65-75% |

### Risk Factors

1. **Liquidity Risk:** Insufficient liquidity can lead to partial fills or slippage
2. **Transaction Costs:** High fees can significantly reduce profits
3. **Regime Change:** Cointegration relationships can break down
4. **Execution Risk:** Timing differences between legs
5. **Model Risk:** Historical relationships may not persist

### Best Practices from Research

1. **Use multiple testing methods:** Combine Engle-Granger and Johansen tests
2. **Rolling window analysis:** Recalculate hedge ratios periodically
3. **Out-of-sample validation:** Always test on unseen data
4. **Position sizing:** Risk no more than 2% per pair trade
5. **Diversification:** Trade multiple uncorrelated pairs

---

## Code Resources

### Complete Implementation

```python
# Full pairs trading system implementation
class CryptoPairsTrader:
    def __init__(self, exchange_client, config: dict):
        self.exchange = exchange_client
        self.config = config
        self.pairs = []
        self.positions = {}

    async def scan_for_pairs(self, symbols: list, lookback_days: int = 60):
        """Scan symbols for cointegrated pairs"""
        # Fetch historical data
        price_data = await self.fetch_prices(symbols, lookback_days)

        # Find cointegrated pairs
        self.pairs = find_cointegrated_pairs(
            price_data,
            significance=self.config.get('significance', 0.05)
        )

        # Filter by half-life
        self.pairs = [
            p for p in self.pairs
            if self.config['min_half_life'] <= p['half_life'] <= self.config['max_half_life']
        ]

        return self.pairs

    async def run_strategy(self):
        """Main trading loop"""
        while True:
            for pair in self.pairs[:self.config['max_pairs']]:
                # Get current prices
                price_a = await self.get_price(pair['asset_a'])
                price_b = await self.get_price(pair['asset_b'])

                # Calculate current spread and z-score
                spread = price_a - pair['hedge_ratio'] * price_b
                zscore = (spread - pair['spread'].mean()) / pair['spread'].std()

                # Generate signal
                strategy = PairsTradingStrategy(**self.config['strategy_params'])
                strategy.position = self.positions.get(pair['id'], 0)

                signal = strategy.generate_signal(zscore)

                # Execute if signal
                if signal['action'] != 'HOLD':
                    await self.execute_pairs_trade(pair, signal, price_a, price_b)

            await asyncio.sleep(self.config['interval_seconds'])
```

---

## Resources

### Academic Papers
- [Pairs Trading Strategies in Cryptocurrency Markets (MDPI)](https://www.mdpi.com/2673-4591/38/1/74)
- [Profiting Off High Correlation Using Statistical Arbitrage (Springer)](https://link.springer.com/chapter/10.1007/978-3-031-68974-1_16)
- [Trading Games in Bullish Crypto Market (Wiley)](https://onlinelibrary.wiley.com/doi/full/10.1002/fut.70018)
- [Advanced Statistical Arbitrage with Reinforcement Learning (arXiv)](https://arxiv.org/html/2403.12180v1)

### Implementation Guides
- [Definitive Guide to Pairs Trading (Hudson & Thames)](https://hudsonthames.org/definitive-guide-to-pairs-trading/)
- [Pairs Trading Basics (QuantInsti)](https://blog.quantinsti.com/pairs-trading-basics/)
- [3 Statistical Arbitrage Strategies in Crypto (CoinAPI)](https://www.coinapi.io/blog/3-statistical-arbitrage-strategies-in-crypto)
- [Statistical Arbitrage Strategies and Risks (dYdX)](https://www.dydx.xyz/crypto-learning/statistical-arbitrage)

### Tools and Libraries
- **statsmodels:** Cointegration tests, regression
- **numpy/pandas:** Data manipulation
- **scipy:** Statistical tests
- **ccxt:** Exchange connectivity

---

*Document compiled: February 2026*
*For research and educational purposes*
